/**
 */
package plc;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Seq Operator</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link plc.SeqOperator#getType <em>Type</em>}</li>
 *   <li>{@link plc.SeqOperator#getSignal <em>Signal</em>}</li>
 *   <li>{@link plc.SeqOperator#getOperator <em>Operator</em>}</li>
 * </ul>
 *
 * @see plc.PlcPackage#getSeqOperator()
 * @model
 * @generated
 */
public interface SeqOperator extends EObject {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see #setType(String)
	 * @see plc.PlcPackage#getSeqOperator_Type()
	 * @model
	 * @generated
	 */
	String getType();

	/**
	 * Sets the value of the '{@link plc.SeqOperator#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see #getType()
	 * @generated
	 */
	void setType(String value);

	/**
	 * Returns the value of the '<em><b>Signal</b></em>' reference list.
	 * The list contents are of type {@link plc.Signal}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Signal</em>' reference list.
	 * @see plc.PlcPackage#getSeqOperator_Signal()
	 * @model
	 * @generated
	 */
	EList<Signal> getSignal();

	/**
	 * Returns the value of the '<em><b>Operator</b></em>' reference list.
	 * The list contents are of type {@link plc.SeqOperator}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operator</em>' reference list.
	 * @see plc.PlcPackage#getSeqOperator_Operator()
	 * @model
	 * @generated
	 */
	EList<SeqOperator> getOperator();

} // SeqOperator
