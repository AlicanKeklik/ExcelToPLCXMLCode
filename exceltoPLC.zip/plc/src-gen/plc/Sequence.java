/**
 */
package plc;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sequence</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link plc.Sequence#getSettings <em>Settings</em>}</li>
 *   <li>{@link plc.Sequence#getSignal <em>Signal</em>}</li>
 *   <li>{@link plc.Sequence#getTransitionsteps <em>Transitionsteps</em>}</li>
 *   <li>{@link plc.Sequence#getAttribute <em>Attribute</em>}</li>
 * </ul>
 *
 * @see plc.PlcPackage#getSequence()
 * @model
 * @generated
 */
public interface Sequence extends EObject {
	/**
	 * Returns the value of the '<em><b>Settings</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Settings</em>' attribute.
	 * @see #setSettings(String)
	 * @see plc.PlcPackage#getSequence_Settings()
	 * @model
	 * @generated
	 */
	String getSettings();

	/**
	 * Sets the value of the '{@link plc.Sequence#getSettings <em>Settings</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Settings</em>' attribute.
	 * @see #getSettings()
	 * @generated
	 */
	void setSettings(String value);

	/**
	 * Returns the value of the '<em><b>Attribute</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attribute</em>' containment reference.
	 * @see #setAttribute(attribute)
	 * @see plc.PlcPackage#getSequence_Attribute()
	 * @model containment="true" required="true"
	 * @generated
	 */
	attribute getAttribute();

	/**
	 * Sets the value of the '{@link plc.Sequence#getAttribute <em>Attribute</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Attribute</em>' containment reference.
	 * @see #getAttribute()
	 * @generated
	 */
	void setAttribute(attribute value);

	/**
	 * Returns the value of the '<em><b>Transitionsteps</b></em>' containment reference list.
	 * The list contents are of type {@link plc.TransitionSteps}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transitionsteps</em>' containment reference list.
	 * @see plc.PlcPackage#getSequence_Transitionsteps()
	 * @model containment="true"
	 * @generated
	 */
	EList<TransitionSteps> getTransitionsteps();

	/**
	 * Returns the value of the '<em><b>Signal</b></em>' reference list.
	 * The list contents are of type {@link plc.Signal}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Signal</em>' reference list.
	 * @see plc.PlcPackage#getSequence_Signal()
	 * @model
	 * @generated
	 */
	EList<Signal> getSignal();

} // Sequence
