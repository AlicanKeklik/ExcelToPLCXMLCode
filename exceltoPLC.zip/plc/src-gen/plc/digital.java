/**
 */
package plc;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>digital</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link plc.digital#getSettings <em>Settings</em>}</li>
 *   <li>{@link plc.digital#getAttributefordigital <em>Attributefordigital</em>}</li>
 *   <li>{@link plc.digital#getSignal <em>Signal</em>}</li>
 *   <li>{@link plc.digital#getİnputpinfordigital <em>İnputpinfordigital</em>}</li>
 *   <li>{@link plc.digital#getOutputpin <em>Outputpin</em>}</li>
 * </ul>
 *
 * @see plc.PlcPackage#getdigital()
 * @model
 * @generated
 */
public interface digital extends EObject {
	/**
	 * Returns the value of the '<em><b>Settings</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Settings</em>' attribute.
	 * @see #setSettings(String)
	 * @see plc.PlcPackage#getdigital_Settings()
	 * @model
	 * @generated
	 */
	String getSettings();

	/**
	 * Sets the value of the '{@link plc.digital#getSettings <em>Settings</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Settings</em>' attribute.
	 * @see #getSettings()
	 * @generated
	 */
	void setSettings(String value);

	/**
	 * Returns the value of the '<em><b>Attributefordigital</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attributefordigital</em>' containment reference.
	 * @see #setAttributefordigital(attribute)
	 * @see plc.PlcPackage#getdigital_Attributefordigital()
	 * @model containment="true"
	 * @generated
	 */
	attribute getAttributefordigital();

	/**
	 * Sets the value of the '{@link plc.digital#getAttributefordigital <em>Attributefordigital</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Attributefordigital</em>' containment reference.
	 * @see #getAttributefordigital()
	 * @generated
	 */
	void setAttributefordigital(attribute value);

	/**
	 * Returns the value of the '<em><b>Signal</b></em>' reference list.
	 * The list contents are of type {@link plc.Signal}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Signal</em>' reference list.
	 * @see plc.PlcPackage#getdigital_Signal()
	 * @model
	 * @generated
	 */
	EList<Signal> getSignal();

	/**
	 * Returns the value of the '<em><b>İnputpinfordigital</b></em>' containment reference list.
	 * The list contents are of type {@link plc.InputPin}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>İnputpinfordigital</em>' containment reference list.
	 * @see plc.PlcPackage#getdigital_İnputpinfordigital()
	 * @model containment="true"
	 * @generated
	 */
	EList<InputPin> getİnputpinfordigital();

	/**
	 * Returns the value of the '<em><b>Outputpin</b></em>' containment reference list.
	 * The list contents are of type {@link plc.OutputPin}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Outputpin</em>' containment reference list.
	 * @see plc.PlcPackage#getdigital_Outputpin()
	 * @model containment="true"
	 * @generated
	 */
	EList<OutputPin> getOutputpin();

} // digital
