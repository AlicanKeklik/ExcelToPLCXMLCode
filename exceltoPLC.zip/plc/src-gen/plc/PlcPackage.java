/**
 */
package plc;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see plc.PlcFactory
 * @model kind="package"
 * @generated
 */
public interface PlcPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "plc";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/plc";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "plc";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	PlcPackage eINSTANCE = plc.impl.PlcPackageImpl.init();

	/**
	 * The meta object id for the '{@link plc.impl.MotorImpl <em>Motor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see plc.impl.MotorImpl
	 * @see plc.impl.PlcPackageImpl#getMotor()
	 * @generated
	 */
	int MOTOR = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR__NAME = 0;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR__DESCRİPTİON = 1;

	/**
	 * The feature id for the '<em><b>Attribute</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR__ATTRİBUTE = 2;

	/**
	 * The feature id for the '<em><b>Signal</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR__SİGNAL = 3;

	/**
	 * The feature id for the '<em><b>İnputpin</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR__İNPUTPİN = 4;

	/**
	 * The feature id for the '<em><b>Outputpin</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR__OUTPUTPİN = 5;

	/**
	 * The number of structural features of the '<em>Motor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR_FEATURE_COUNT = 6;

	/**
	 * The operation id for the '<em>Add Motor</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR___ADD_MOTOR = 0;

	/**
	 * The operation id for the '<em>Add Signal</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR___ADD_SİGNAL = 1;

	/**
	 * The number of operations of the '<em>Motor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR_OPERATION_COUNT = 2;

	/**
	 * The meta object id for the '{@link plc.impl.SignalImpl <em>Signal</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see plc.impl.SignalImpl
	 * @see plc.impl.PlcPackageImpl#getSignal()
	 * @generated
	 */
	int SİGNAL = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNAL__NAME = 0;

	/**
	 * The feature id for the '<em><b>Signal Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNAL__SİGNAL_TYPE = 1;

	/**
	 * The feature id for the '<em><b>Function Block Ref</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNAL__FUNCTİON_BLOCK_REF = 2;

	/**
	 * The feature id for the '<em><b>Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNAL__ID_NBR = 3;

	/**
	 * The number of structural features of the '<em>Signal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNAL_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Signal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNAL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link plc.impl.AnalogImpl <em>Analog</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see plc.impl.AnalogImpl
	 * @see plc.impl.PlcPackageImpl#getAnalog()
	 * @generated
	 */
	int ANALOG = 2;

	/**
	 * The feature id for the '<em><b>Settings</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALOG__SETTİNGS = 0;

	/**
	 * The feature id for the '<em><b>Signal</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALOG__SİGNAL = 1;

	/**
	 * The feature id for the '<em><b>İnputpinforanalog</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALOG__İNPUTPİNFORANALOG = 2;

	/**
	 * The feature id for the '<em><b>Attributeforanalog</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALOG__ATTRİBUTEFORANALOG = 3;

	/**
	 * The feature id for the '<em><b>Outputpin</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALOG__OUTPUTPİN = 4;

	/**
	 * The number of structural features of the '<em>Analog</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALOG_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Analog</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALOG_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link plc.impl.attributeImpl <em>attribute</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see plc.impl.attributeImpl
	 * @see plc.impl.PlcPackageImpl#getattribute()
	 * @generated
	 */
	int ATTRİBUTE = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRİBUTE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRİBUTE__DESCRİPTİON = 1;

	/**
	 * The feature id for the '<em><b>Library Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRİBUTE__LİBRARY_NAME = 2;

	/**
	 * The number of structural features of the '<em>attribute</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRİBUTE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>attribute</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRİBUTE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link plc.impl.digitalImpl <em>digital</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see plc.impl.digitalImpl
	 * @see plc.impl.PlcPackageImpl#getdigital()
	 * @generated
	 */
	int DİGİTAL = 4;

	/**
	 * The feature id for the '<em><b>Settings</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DİGİTAL__SETTİNGS = 0;

	/**
	 * The feature id for the '<em><b>Attributefordigital</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DİGİTAL__ATTRİBUTEFORDİGİTAL = 1;

	/**
	 * The feature id for the '<em><b>Signal</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DİGİTAL__SİGNAL = 2;

	/**
	 * The feature id for the '<em><b>İnputpinfordigital</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DİGİTAL__İNPUTPİNFORDİGİTAL = 3;

	/**
	 * The feature id for the '<em><b>Outputpin</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DİGİTAL__OUTPUTPİN = 4;

	/**
	 * The number of structural features of the '<em>digital</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DİGİTAL_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>digital</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DİGİTAL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link plc.impl.SequencesImpl <em>Sequences</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see plc.impl.SequencesImpl
	 * @see plc.impl.PlcPackageImpl#getSequences()
	 * @generated
	 */
	int SEQUENCES = 5;

	/**
	 * The feature id for the '<em><b>Settings</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQUENCES__SETTİNGS = 0;

	/**
	 * The feature id for the '<em><b>Signal</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQUENCES__SİGNAL = 1;

	/**
	 * The feature id for the '<em><b>Transitionsteps</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQUENCES__TRANSİTİONSTEPS = 2;

	/**
	 * The feature id for the '<em><b>Attribute</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQUENCES__ATTRİBUTE = 3;

	/**
	 * The number of structural features of the '<em>Sequences</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQUENCES_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Sequences</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQUENCES_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link plc.impl.PlcDataImpl <em>Data</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see plc.impl.PlcDataImpl
	 * @see plc.impl.PlcPackageImpl#getPlcData()
	 * @generated
	 */
	int PLC_DATA = 6;

	/**
	 * The feature id for the '<em><b>Sequence</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLC_DATA__SEQUENCE = 0;

	/**
	 * The feature id for the '<em><b>Digital</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLC_DATA__DİGİTAL = 1;

	/**
	 * The feature id for the '<em><b>Analog</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLC_DATA__ANALOG = 2;

	/**
	 * The feature id for the '<em><b>Motor</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLC_DATA__MOTOR = 3;

	/**
	 * The feature id for the '<em><b>Signal</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLC_DATA__SİGNAL = 4;

	/**
	 * The number of structural features of the '<em>Data</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLC_DATA_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Data</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLC_DATA_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link plc.impl.InputPinImpl <em>Input Pin</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see plc.impl.InputPinImpl
	 * @see plc.impl.PlcPackageImpl#getInputPin()
	 * @generated
	 */
	int INPUT_PİN = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_PİN__NAME = 0;

	/**
	 * The feature id for the '<em><b>Signal Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_PİN__SİGNAL_TYPE = 1;

	/**
	 * The feature id for the '<em><b>Signal</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_PİN__SİGNAL = 2;

	/**
	 * The feature id for the '<em><b>Operator</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_PİN__OPERATOR = 3;

	/**
	 * The number of structural features of the '<em>Input Pin</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_PİN_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Input Pin</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_PİN_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link plc.impl.OperatorImpl <em>Operator</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see plc.impl.OperatorImpl
	 * @see plc.impl.PlcPackageImpl#getOperator()
	 * @generated
	 */
	int OPERATOR = 8;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATOR__TYPE = 0;

	/**
	 * The feature id for the '<em><b>Signal</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATOR__SİGNAL = 1;

	/**
	 * The feature id for the '<em><b>Operator</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATOR__OPERATOR = 2;

	/**
	 * The number of structural features of the '<em>Operator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATOR_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Operator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link plc.impl.TransitionStepsImpl <em>Transition Steps</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see plc.impl.TransitionStepsImpl
	 * @see plc.impl.PlcPackageImpl#getTransitionSteps()
	 * @generated
	 */
	int TRANSİTİON_STEPS = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSİTİON_STEPS__NAME = 0;

	/**
	 * The feature id for the '<em><b>Signal</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSİTİON_STEPS__SİGNAL = 1;

	/**
	 * The feature id for the '<em><b>Operator</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSİTİON_STEPS__OPERATOR = 2;

	/**
	 * The number of structural features of the '<em>Transition Steps</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSİTİON_STEPS_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Transition Steps</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSİTİON_STEPS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link plc.impl.SeqOperatorImpl <em>Seq Operator</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see plc.impl.SeqOperatorImpl
	 * @see plc.impl.PlcPackageImpl#getSeqOperator()
	 * @generated
	 */
	int SEQ_OPERATOR = 10;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQ_OPERATOR__TYPE = 0;

	/**
	 * The feature id for the '<em><b>Signal</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQ_OPERATOR__SİGNAL = 1;

	/**
	 * The feature id for the '<em><b>Operator</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQ_OPERATOR__OPERATOR = 2;

	/**
	 * The number of structural features of the '<em>Seq Operator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQ_OPERATOR_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Seq Operator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQ_OPERATOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link plc.impl.OutputPinImpl <em>Output Pin</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see plc.impl.OutputPinImpl
	 * @see plc.impl.PlcPackageImpl#getOutputPin()
	 * @generated
	 */
	int OUTPUT_PİN = 11;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_PİN__NAME = 0;

	/**
	 * The feature id for the '<em><b>Signal Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_PİN__SİGNAL_TYPE = 1;

	/**
	 * The feature id for the '<em><b>Signal</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_PİN__SİGNAL = 2;

	/**
	 * The number of structural features of the '<em>Output Pin</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_PİN_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Output Pin</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_PİN_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link plc.BlockType <em>Block Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see plc.BlockType
	 * @see plc.impl.PlcPackageImpl#getBlockType()
	 * @generated
	 */
	int BLOCK_TYPE = 12;

	/**
	 * Returns the meta object for class '{@link plc.Motor <em>Motor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Motor</em>'.
	 * @see plc.Motor
	 * @generated
	 */
	EClass getMotor();

	/**
	 * Returns the meta object for the attribute '{@link plc.Motor#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see plc.Motor#getName()
	 * @see #getMotor()
	 * @generated
	 */
	EAttribute getMotor_Name();

	/**
	 * Returns the meta object for the attribute '{@link plc.Motor#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see plc.Motor#getDescription()
	 * @see #getMotor()
	 * @generated
	 */
	EAttribute getMotor_Description();

	/**
	 * Returns the meta object for the containment reference '{@link plc.Motor#getAttribute <em>Attribute</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Attribute</em>'.
	 * @see plc.Motor#getAttribute()
	 * @see #getMotor()
	 * @generated
	 */
	EReference getMotor_Attribute();

	/**
	 * Returns the meta object for the reference list '{@link plc.Motor#getSignal <em>Signal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Signal</em>'.
	 * @see plc.Motor#getSignal()
	 * @see #getMotor()
	 * @generated
	 */
	EReference getMotor_Signal();

	/**
	 * Returns the meta object for the containment reference list '{@link plc.Motor#getİnputpin <em>İnputpin</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>İnputpin</em>'.
	 * @see plc.Motor#getİnputpin()
	 * @see #getMotor()
	 * @generated
	 */
	EReference getMotor_İnputpin();

	/**
	 * Returns the meta object for the containment reference list '{@link plc.Motor#getOutputpin <em>Outputpin</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Outputpin</em>'.
	 * @see plc.Motor#getOutputpin()
	 * @see #getMotor()
	 * @generated
	 */
	EReference getMotor_Outputpin();

	/**
	 * Returns the meta object for the '{@link plc.Motor#addMotor() <em>Add Motor</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Add Motor</em>' operation.
	 * @see plc.Motor#addMotor()
	 * @generated
	 */
	EOperation getMotor__AddMotor();

	/**
	 * Returns the meta object for the '{@link plc.Motor#addSignal() <em>Add Signal</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Add Signal</em>' operation.
	 * @see plc.Motor#addSignal()
	 * @generated
	 */
	EOperation getMotor__AddSignal();

	/**
	 * Returns the meta object for class '{@link plc.Signal <em>Signal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Signal</em>'.
	 * @see plc.Signal
	 * @generated
	 */
	EClass getSignal();

	/**
	 * Returns the meta object for the attribute '{@link plc.Signal#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see plc.Signal#getName()
	 * @see #getSignal()
	 * @generated
	 */
	EAttribute getSignal_Name();

	/**
	 * Returns the meta object for the attribute '{@link plc.Signal#getSignalType <em>Signal Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Signal Type</em>'.
	 * @see plc.Signal#getSignalType()
	 * @see #getSignal()
	 * @generated
	 */
	EAttribute getSignal_SignalType();

	/**
	 * Returns the meta object for the attribute '{@link plc.Signal#getFunctionBlockRef <em>Function Block Ref</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Function Block Ref</em>'.
	 * @see plc.Signal#getFunctionBlockRef()
	 * @see #getSignal()
	 * @generated
	 */
	EAttribute getSignal_FunctionBlockRef();

	/**
	 * Returns the meta object for the attribute '{@link plc.Signal#getIdNbr <em>Id Nbr</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id Nbr</em>'.
	 * @see plc.Signal#getIdNbr()
	 * @see #getSignal()
	 * @generated
	 */
	EAttribute getSignal_IdNbr();

	/**
	 * Returns the meta object for class '{@link plc.Analog <em>Analog</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Analog</em>'.
	 * @see plc.Analog
	 * @generated
	 */
	EClass getAnalog();

	/**
	 * Returns the meta object for the containment reference '{@link plc.Analog#getAttributeforanalog <em>Attributeforanalog</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Attributeforanalog</em>'.
	 * @see plc.Analog#getAttributeforanalog()
	 * @see #getAnalog()
	 * @generated
	 */
	EReference getAnalog_Attributeforanalog();

	/**
	 * Returns the meta object for the containment reference list '{@link plc.Analog#getOutputpin <em>Outputpin</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Outputpin</em>'.
	 * @see plc.Analog#getOutputpin()
	 * @see #getAnalog()
	 * @generated
	 */
	EReference getAnalog_Outputpin();

	/**
	 * Returns the meta object for the attribute '{@link plc.Analog#getSettings <em>Settings</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Settings</em>'.
	 * @see plc.Analog#getSettings()
	 * @see #getAnalog()
	 * @generated
	 */
	EAttribute getAnalog_Settings();

	/**
	 * Returns the meta object for the reference list '{@link plc.Analog#getSignal <em>Signal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Signal</em>'.
	 * @see plc.Analog#getSignal()
	 * @see #getAnalog()
	 * @generated
	 */
	EReference getAnalog_Signal();

	/**
	 * Returns the meta object for the containment reference list '{@link plc.Analog#getİnputpinforanalog <em>İnputpinforanalog</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>İnputpinforanalog</em>'.
	 * @see plc.Analog#getİnputpinforanalog()
	 * @see #getAnalog()
	 * @generated
	 */
	EReference getAnalog_İnputpinforanalog();

	/**
	 * Returns the meta object for class '{@link plc.attribute <em>attribute</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>attribute</em>'.
	 * @see plc.attribute
	 * @generated
	 */
	EClass getattribute();

	/**
	 * Returns the meta object for the attribute '{@link plc.attribute#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see plc.attribute#getName()
	 * @see #getattribute()
	 * @generated
	 */
	EAttribute getattribute_Name();

	/**
	 * Returns the meta object for the attribute '{@link plc.attribute#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see plc.attribute#getDescription()
	 * @see #getattribute()
	 * @generated
	 */
	EAttribute getattribute_Description();

	/**
	 * Returns the meta object for the attribute '{@link plc.attribute#getLibraryName <em>Library Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Library Name</em>'.
	 * @see plc.attribute#getLibraryName()
	 * @see #getattribute()
	 * @generated
	 */
	EAttribute getattribute_LibraryName();

	/**
	 * Returns the meta object for class '{@link plc.digital <em>digital</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>digital</em>'.
	 * @see plc.digital
	 * @generated
	 */
	EClass getdigital();

	/**
	 * Returns the meta object for the attribute '{@link plc.digital#getSettings <em>Settings</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Settings</em>'.
	 * @see plc.digital#getSettings()
	 * @see #getdigital()
	 * @generated
	 */
	EAttribute getdigital_Settings();

	/**
	 * Returns the meta object for the containment reference '{@link plc.digital#getAttributefordigital <em>Attributefordigital</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Attributefordigital</em>'.
	 * @see plc.digital#getAttributefordigital()
	 * @see #getdigital()
	 * @generated
	 */
	EReference getdigital_Attributefordigital();

	/**
	 * Returns the meta object for the reference list '{@link plc.digital#getSignal <em>Signal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Signal</em>'.
	 * @see plc.digital#getSignal()
	 * @see #getdigital()
	 * @generated
	 */
	EReference getdigital_Signal();

	/**
	 * Returns the meta object for the containment reference list '{@link plc.digital#getİnputpinfordigital <em>İnputpinfordigital</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>İnputpinfordigital</em>'.
	 * @see plc.digital#getİnputpinfordigital()
	 * @see #getdigital()
	 * @generated
	 */
	EReference getdigital_İnputpinfordigital();

	/**
	 * Returns the meta object for the containment reference list '{@link plc.digital#getOutputpin <em>Outputpin</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Outputpin</em>'.
	 * @see plc.digital#getOutputpin()
	 * @see #getdigital()
	 * @generated
	 */
	EReference getdigital_Outputpin();

	/**
	 * Returns the meta object for class '{@link plc.Sequences <em>Sequences</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sequences</em>'.
	 * @see plc.Sequences
	 * @generated
	 */
	EClass getSequences();

	/**
	 * Returns the meta object for the attribute '{@link plc.Sequences#getSettings <em>Settings</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Settings</em>'.
	 * @see plc.Sequences#getSettings()
	 * @see #getSequences()
	 * @generated
	 */
	EAttribute getSequences_Settings();

	/**
	 * Returns the meta object for the reference list '{@link plc.Sequences#getSignal <em>Signal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Signal</em>'.
	 * @see plc.Sequences#getSignal()
	 * @see #getSequences()
	 * @generated
	 */
	EReference getSequences_Signal();

	/**
	 * Returns the meta object for the containment reference list '{@link plc.Sequences#getTransitionsteps <em>Transitionsteps</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Transitionsteps</em>'.
	 * @see plc.Sequences#getTransitionsteps()
	 * @see #getSequences()
	 * @generated
	 */
	EReference getSequences_Transitionsteps();

	/**
	 * Returns the meta object for the containment reference '{@link plc.Sequences#getAttribute <em>Attribute</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Attribute</em>'.
	 * @see plc.Sequences#getAttribute()
	 * @see #getSequences()
	 * @generated
	 */
	EReference getSequences_Attribute();

	/**
	 * Returns the meta object for class '{@link plc.PlcData <em>Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Data</em>'.
	 * @see plc.PlcData
	 * @generated
	 */
	EClass getPlcData();

	/**
	 * Returns the meta object for the containment reference list '{@link plc.PlcData#getSequence <em>Sequence</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Sequence</em>'.
	 * @see plc.PlcData#getSequence()
	 * @see #getPlcData()
	 * @generated
	 */
	EReference getPlcData_Sequence();

	/**
	 * Returns the meta object for the containment reference list '{@link plc.PlcData#getDigital <em>Digital</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Digital</em>'.
	 * @see plc.PlcData#getDigital()
	 * @see #getPlcData()
	 * @generated
	 */
	EReference getPlcData_Digital();

	/**
	 * Returns the meta object for the containment reference list '{@link plc.PlcData#getAnalog <em>Analog</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Analog</em>'.
	 * @see plc.PlcData#getAnalog()
	 * @see #getPlcData()
	 * @generated
	 */
	EReference getPlcData_Analog();

	/**
	 * Returns the meta object for the containment reference list '{@link plc.PlcData#getMotor <em>Motor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Motor</em>'.
	 * @see plc.PlcData#getMotor()
	 * @see #getPlcData()
	 * @generated
	 */
	EReference getPlcData_Motor();

	/**
	 * Returns the meta object for the containment reference list '{@link plc.PlcData#getSignal <em>Signal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Signal</em>'.
	 * @see plc.PlcData#getSignal()
	 * @see #getPlcData()
	 * @generated
	 */
	EReference getPlcData_Signal();

	/**
	 * Returns the meta object for class '{@link plc.InputPin <em>Input Pin</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Input Pin</em>'.
	 * @see plc.InputPin
	 * @generated
	 */
	EClass getInputPin();

	/**
	 * Returns the meta object for the attribute '{@link plc.InputPin#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see plc.InputPin#getName()
	 * @see #getInputPin()
	 * @generated
	 */
	EAttribute getInputPin_Name();

	/**
	 * Returns the meta object for the attribute '{@link plc.InputPin#getSignalType <em>Signal Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Signal Type</em>'.
	 * @see plc.InputPin#getSignalType()
	 * @see #getInputPin()
	 * @generated
	 */
	EAttribute getInputPin_SignalType();

	/**
	 * Returns the meta object for the reference list '{@link plc.InputPin#getSignal <em>Signal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Signal</em>'.
	 * @see plc.InputPin#getSignal()
	 * @see #getInputPin()
	 * @generated
	 */
	EReference getInputPin_Signal();

	/**
	 * Returns the meta object for the containment reference list '{@link plc.InputPin#getOperator <em>Operator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Operator</em>'.
	 * @see plc.InputPin#getOperator()
	 * @see #getInputPin()
	 * @generated
	 */
	EReference getInputPin_Operator();

	/**
	 * Returns the meta object for class '{@link plc.Operator <em>Operator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Operator</em>'.
	 * @see plc.Operator
	 * @generated
	 */
	EClass getOperator();

	/**
	 * Returns the meta object for the attribute '{@link plc.Operator#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see plc.Operator#getType()
	 * @see #getOperator()
	 * @generated
	 */
	EAttribute getOperator_Type();

	/**
	 * Returns the meta object for the reference list '{@link plc.Operator#getSignal <em>Signal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Signal</em>'.
	 * @see plc.Operator#getSignal()
	 * @see #getOperator()
	 * @generated
	 */
	EReference getOperator_Signal();

	/**
	 * Returns the meta object for the reference list '{@link plc.Operator#getOperator <em>Operator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Operator</em>'.
	 * @see plc.Operator#getOperator()
	 * @see #getOperator()
	 * @generated
	 */
	EReference getOperator_Operator();

	/**
	 * Returns the meta object for class '{@link plc.TransitionSteps <em>Transition Steps</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Transition Steps</em>'.
	 * @see plc.TransitionSteps
	 * @generated
	 */
	EClass getTransitionSteps();

	/**
	 * Returns the meta object for the attribute '{@link plc.TransitionSteps#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see plc.TransitionSteps#getName()
	 * @see #getTransitionSteps()
	 * @generated
	 */
	EAttribute getTransitionSteps_Name();

	/**
	 * Returns the meta object for the reference list '{@link plc.TransitionSteps#getSignal <em>Signal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Signal</em>'.
	 * @see plc.TransitionSteps#getSignal()
	 * @see #getTransitionSteps()
	 * @generated
	 */
	EReference getTransitionSteps_Signal();

	/**
	 * Returns the meta object for the containment reference list '{@link plc.TransitionSteps#getOperator <em>Operator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Operator</em>'.
	 * @see plc.TransitionSteps#getOperator()
	 * @see #getTransitionSteps()
	 * @generated
	 */
	EReference getTransitionSteps_Operator();

	/**
	 * Returns the meta object for class '{@link plc.SeqOperator <em>Seq Operator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Seq Operator</em>'.
	 * @see plc.SeqOperator
	 * @generated
	 */
	EClass getSeqOperator();

	/**
	 * Returns the meta object for the attribute '{@link plc.SeqOperator#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see plc.SeqOperator#getType()
	 * @see #getSeqOperator()
	 * @generated
	 */
	EAttribute getSeqOperator_Type();

	/**
	 * Returns the meta object for the reference list '{@link plc.SeqOperator#getSignal <em>Signal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Signal</em>'.
	 * @see plc.SeqOperator#getSignal()
	 * @see #getSeqOperator()
	 * @generated
	 */
	EReference getSeqOperator_Signal();

	/**
	 * Returns the meta object for the reference list '{@link plc.SeqOperator#getOperator <em>Operator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Operator</em>'.
	 * @see plc.SeqOperator#getOperator()
	 * @see #getSeqOperator()
	 * @generated
	 */
	EReference getSeqOperator_Operator();

	/**
	 * Returns the meta object for class '{@link plc.OutputPin <em>Output Pin</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Output Pin</em>'.
	 * @see plc.OutputPin
	 * @generated
	 */
	EClass getOutputPin();

	/**
	 * Returns the meta object for the attribute '{@link plc.OutputPin#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see plc.OutputPin#getName()
	 * @see #getOutputPin()
	 * @generated
	 */
	EAttribute getOutputPin_Name();

	/**
	 * Returns the meta object for the attribute '{@link plc.OutputPin#getSignalType <em>Signal Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Signal Type</em>'.
	 * @see plc.OutputPin#getSignalType()
	 * @see #getOutputPin()
	 * @generated
	 */
	EAttribute getOutputPin_SignalType();

	/**
	 * Returns the meta object for the reference list '{@link plc.OutputPin#getSignal <em>Signal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Signal</em>'.
	 * @see plc.OutputPin#getSignal()
	 * @see #getOutputPin()
	 * @generated
	 */
	EReference getOutputPin_Signal();

	/**
	 * Returns the meta object for enum '{@link plc.BlockType <em>Block Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Block Type</em>'.
	 * @see plc.BlockType
	 * @generated
	 */
	EEnum getBlockType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	PlcFactory getPlcFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link plc.impl.MotorImpl <em>Motor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see plc.impl.MotorImpl
		 * @see plc.impl.PlcPackageImpl#getMotor()
		 * @generated
		 */
		EClass MOTOR = eINSTANCE.getMotor();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOTOR__NAME = eINSTANCE.getMotor_Name();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOTOR__DESCRİPTİON = eINSTANCE.getMotor_Description();

		/**
		 * The meta object literal for the '<em><b>Attribute</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOTOR__ATTRİBUTE = eINSTANCE.getMotor_Attribute();

		/**
		 * The meta object literal for the '<em><b>Signal</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOTOR__SİGNAL = eINSTANCE.getMotor_Signal();

		/**
		 * The meta object literal for the '<em><b>İnputpin</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOTOR__İNPUTPİN = eINSTANCE.getMotor_İnputpin();

		/**
		 * The meta object literal for the '<em><b>Outputpin</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOTOR__OUTPUTPİN = eINSTANCE.getMotor_Outputpin();

		/**
		 * The meta object literal for the '<em><b>Add Motor</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation MOTOR___ADD_MOTOR = eINSTANCE.getMotor__AddMotor();

		/**
		 * The meta object literal for the '<em><b>Add Signal</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation MOTOR___ADD_SİGNAL = eINSTANCE.getMotor__AddSignal();

		/**
		 * The meta object literal for the '{@link plc.impl.SignalImpl <em>Signal</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see plc.impl.SignalImpl
		 * @see plc.impl.PlcPackageImpl#getSignal()
		 * @generated
		 */
		EClass SİGNAL = eINSTANCE.getSignal();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SİGNAL__NAME = eINSTANCE.getSignal_Name();

		/**
		 * The meta object literal for the '<em><b>Signal Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SİGNAL__SİGNAL_TYPE = eINSTANCE.getSignal_SignalType();

		/**
		 * The meta object literal for the '<em><b>Function Block Ref</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SİGNAL__FUNCTİON_BLOCK_REF = eINSTANCE.getSignal_FunctionBlockRef();

		/**
		 * The meta object literal for the '<em><b>Id Nbr</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SİGNAL__ID_NBR = eINSTANCE.getSignal_IdNbr();

		/**
		 * The meta object literal for the '{@link plc.impl.AnalogImpl <em>Analog</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see plc.impl.AnalogImpl
		 * @see plc.impl.PlcPackageImpl#getAnalog()
		 * @generated
		 */
		EClass ANALOG = eINSTANCE.getAnalog();

		/**
		 * The meta object literal for the '<em><b>Settings</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANALOG__SETTİNGS = eINSTANCE.getAnalog_Settings();

		/**
		 * The meta object literal for the '<em><b>Signal</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ANALOG__SİGNAL = eINSTANCE.getAnalog_Signal();

		/**
		 * The meta object literal for the '<em><b>İnputpinforanalog</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ANALOG__İNPUTPİNFORANALOG = eINSTANCE.getAnalog_İnputpinforanalog();

		/**
		 * The meta object literal for the '<em><b>Attributeforanalog</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ANALOG__ATTRİBUTEFORANALOG = eINSTANCE.getAnalog_Attributeforanalog();

		/**
		 * The meta object literal for the '<em><b>Outputpin</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ANALOG__OUTPUTPİN = eINSTANCE.getAnalog_Outputpin();

		/**
		 * The meta object literal for the '{@link plc.impl.attributeImpl <em>attribute</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see plc.impl.attributeImpl
		 * @see plc.impl.PlcPackageImpl#getattribute()
		 * @generated
		 */
		EClass ATTRİBUTE = eINSTANCE.getattribute();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRİBUTE__NAME = eINSTANCE.getattribute_Name();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRİBUTE__DESCRİPTİON = eINSTANCE.getattribute_Description();

		/**
		 * The meta object literal for the '<em><b>Library Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRİBUTE__LİBRARY_NAME = eINSTANCE.getattribute_LibraryName();

		/**
		 * The meta object literal for the '{@link plc.impl.digitalImpl <em>digital</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see plc.impl.digitalImpl
		 * @see plc.impl.PlcPackageImpl#getdigital()
		 * @generated
		 */
		EClass DİGİTAL = eINSTANCE.getdigital();

		/**
		 * The meta object literal for the '<em><b>Settings</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DİGİTAL__SETTİNGS = eINSTANCE.getdigital_Settings();

		/**
		 * The meta object literal for the '<em><b>Attributefordigital</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DİGİTAL__ATTRİBUTEFORDİGİTAL = eINSTANCE.getdigital_Attributefordigital();

		/**
		 * The meta object literal for the '<em><b>Signal</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DİGİTAL__SİGNAL = eINSTANCE.getdigital_Signal();

		/**
		 * The meta object literal for the '<em><b>İnputpinfordigital</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DİGİTAL__İNPUTPİNFORDİGİTAL = eINSTANCE.getdigital_İnputpinfordigital();

		/**
		 * The meta object literal for the '<em><b>Outputpin</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DİGİTAL__OUTPUTPİN = eINSTANCE.getdigital_Outputpin();

		/**
		 * The meta object literal for the '{@link plc.impl.SequencesImpl <em>Sequences</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see plc.impl.SequencesImpl
		 * @see plc.impl.PlcPackageImpl#getSequences()
		 * @generated
		 */
		EClass SEQUENCES = eINSTANCE.getSequences();

		/**
		 * The meta object literal for the '<em><b>Settings</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEQUENCES__SETTİNGS = eINSTANCE.getSequences_Settings();

		/**
		 * The meta object literal for the '<em><b>Signal</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEQUENCES__SİGNAL = eINSTANCE.getSequences_Signal();

		/**
		 * The meta object literal for the '<em><b>Transitionsteps</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEQUENCES__TRANSİTİONSTEPS = eINSTANCE.getSequences_Transitionsteps();

		/**
		 * The meta object literal for the '<em><b>Attribute</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEQUENCES__ATTRİBUTE = eINSTANCE.getSequences_Attribute();

		/**
		 * The meta object literal for the '{@link plc.impl.PlcDataImpl <em>Data</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see plc.impl.PlcDataImpl
		 * @see plc.impl.PlcPackageImpl#getPlcData()
		 * @generated
		 */
		EClass PLC_DATA = eINSTANCE.getPlcData();

		/**
		 * The meta object literal for the '<em><b>Sequence</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLC_DATA__SEQUENCE = eINSTANCE.getPlcData_Sequence();

		/**
		 * The meta object literal for the '<em><b>Digital</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLC_DATA__DİGİTAL = eINSTANCE.getPlcData_Digital();

		/**
		 * The meta object literal for the '<em><b>Analog</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLC_DATA__ANALOG = eINSTANCE.getPlcData_Analog();

		/**
		 * The meta object literal for the '<em><b>Motor</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLC_DATA__MOTOR = eINSTANCE.getPlcData_Motor();

		/**
		 * The meta object literal for the '<em><b>Signal</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLC_DATA__SİGNAL = eINSTANCE.getPlcData_Signal();

		/**
		 * The meta object literal for the '{@link plc.impl.InputPinImpl <em>Input Pin</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see plc.impl.InputPinImpl
		 * @see plc.impl.PlcPackageImpl#getInputPin()
		 * @generated
		 */
		EClass INPUT_PİN = eINSTANCE.getInputPin();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INPUT_PİN__NAME = eINSTANCE.getInputPin_Name();

		/**
		 * The meta object literal for the '<em><b>Signal Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INPUT_PİN__SİGNAL_TYPE = eINSTANCE.getInputPin_SignalType();

		/**
		 * The meta object literal for the '<em><b>Signal</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INPUT_PİN__SİGNAL = eINSTANCE.getInputPin_Signal();

		/**
		 * The meta object literal for the '<em><b>Operator</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INPUT_PİN__OPERATOR = eINSTANCE.getInputPin_Operator();

		/**
		 * The meta object literal for the '{@link plc.impl.OperatorImpl <em>Operator</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see plc.impl.OperatorImpl
		 * @see plc.impl.PlcPackageImpl#getOperator()
		 * @generated
		 */
		EClass OPERATOR = eINSTANCE.getOperator();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OPERATOR__TYPE = eINSTANCE.getOperator_Type();

		/**
		 * The meta object literal for the '<em><b>Signal</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OPERATOR__SİGNAL = eINSTANCE.getOperator_Signal();

		/**
		 * The meta object literal for the '<em><b>Operator</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OPERATOR__OPERATOR = eINSTANCE.getOperator_Operator();

		/**
		 * The meta object literal for the '{@link plc.impl.TransitionStepsImpl <em>Transition Steps</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see plc.impl.TransitionStepsImpl
		 * @see plc.impl.PlcPackageImpl#getTransitionSteps()
		 * @generated
		 */
		EClass TRANSİTİON_STEPS = eINSTANCE.getTransitionSteps();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSİTİON_STEPS__NAME = eINSTANCE.getTransitionSteps_Name();

		/**
		 * The meta object literal for the '<em><b>Signal</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSİTİON_STEPS__SİGNAL = eINSTANCE.getTransitionSteps_Signal();

		/**
		 * The meta object literal for the '<em><b>Operator</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSİTİON_STEPS__OPERATOR = eINSTANCE.getTransitionSteps_Operator();

		/**
		 * The meta object literal for the '{@link plc.impl.SeqOperatorImpl <em>Seq Operator</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see plc.impl.SeqOperatorImpl
		 * @see plc.impl.PlcPackageImpl#getSeqOperator()
		 * @generated
		 */
		EClass SEQ_OPERATOR = eINSTANCE.getSeqOperator();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEQ_OPERATOR__TYPE = eINSTANCE.getSeqOperator_Type();

		/**
		 * The meta object literal for the '<em><b>Signal</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEQ_OPERATOR__SİGNAL = eINSTANCE.getSeqOperator_Signal();

		/**
		 * The meta object literal for the '<em><b>Operator</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEQ_OPERATOR__OPERATOR = eINSTANCE.getSeqOperator_Operator();

		/**
		 * The meta object literal for the '{@link plc.impl.OutputPinImpl <em>Output Pin</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see plc.impl.OutputPinImpl
		 * @see plc.impl.PlcPackageImpl#getOutputPin()
		 * @generated
		 */
		EClass OUTPUT_PİN = eINSTANCE.getOutputPin();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OUTPUT_PİN__NAME = eINSTANCE.getOutputPin_Name();

		/**
		 * The meta object literal for the '<em><b>Signal Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OUTPUT_PİN__SİGNAL_TYPE = eINSTANCE.getOutputPin_SignalType();

		/**
		 * The meta object literal for the '<em><b>Signal</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OUTPUT_PİN__SİGNAL = eINSTANCE.getOutputPin_Signal();

		/**
		 * The meta object literal for the '{@link plc.BlockType <em>Block Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see plc.BlockType
		 * @see plc.impl.PlcPackageImpl#getBlockType()
		 * @generated
		 */
		EEnum BLOCK_TYPE = eINSTANCE.getBlockType();

	}

} //PlcPackage
