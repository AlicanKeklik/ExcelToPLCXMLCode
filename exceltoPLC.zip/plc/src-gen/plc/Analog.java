/**
 */
package plc;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Analog</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link plc.Analog#getSettings <em>Settings</em>}</li>
 *   <li>{@link plc.Analog#getSignal <em>Signal</em>}</li>
 *   <li>{@link plc.Analog#getİnputpinforanalog <em>İnputpinforanalog</em>}</li>
 *   <li>{@link plc.Analog#getAttributeforanalog <em>Attributeforanalog</em>}</li>
 *   <li>{@link plc.Analog#getOutputpin <em>Outputpin</em>}</li>
 * </ul>
 *
 * @see plc.PlcPackage#getAnalog()
 * @model
 * @generated
 */
public interface Analog extends EObject {
	/**
	 * Returns the value of the '<em><b>Attributeforanalog</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attributeforanalog</em>' containment reference.
	 * @see #setAttributeforanalog(attribute)
	 * @see plc.PlcPackage#getAnalog_Attributeforanalog()
	 * @model containment="true"
	 * @generated
	 */
	attribute getAttributeforanalog();

	/**
	 * Sets the value of the '{@link plc.Analog#getAttributeforanalog <em>Attributeforanalog</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Attributeforanalog</em>' containment reference.
	 * @see #getAttributeforanalog()
	 * @generated
	 */
	void setAttributeforanalog(attribute value);

	/**
	 * Returns the value of the '<em><b>Outputpin</b></em>' containment reference list.
	 * The list contents are of type {@link plc.OutputPin}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Outputpin</em>' containment reference list.
	 * @see plc.PlcPackage#getAnalog_Outputpin()
	 * @model containment="true"
	 * @generated
	 */
	EList<OutputPin> getOutputpin();

	/**
	 * Returns the value of the '<em><b>Settings</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Settings</em>' attribute.
	 * @see #setSettings(String)
	 * @see plc.PlcPackage#getAnalog_Settings()
	 * @model
	 * @generated
	 */
	String getSettings();

	/**
	 * Sets the value of the '{@link plc.Analog#getSettings <em>Settings</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Settings</em>' attribute.
	 * @see #getSettings()
	 * @generated
	 */
	void setSettings(String value);

	/**
	 * Returns the value of the '<em><b>Signal</b></em>' reference list.
	 * The list contents are of type {@link plc.Signal}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Signal</em>' reference list.
	 * @see plc.PlcPackage#getAnalog_Signal()
	 * @model
	 * @generated
	 */
	EList<Signal> getSignal();

	/**
	 * Returns the value of the '<em><b>İnputpinforanalog</b></em>' containment reference list.
	 * The list contents are of type {@link plc.InputPin}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>İnputpinforanalog</em>' containment reference list.
	 * @see plc.PlcPackage#getAnalog_İnputpinforanalog()
	 * @model containment="true"
	 * @generated
	 */
	EList<InputPin> getİnputpinforanalog();

} // Analog
