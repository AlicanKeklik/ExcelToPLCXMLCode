/**
 */
package plc;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Data</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link plc.PlcData#getSequence <em>Sequence</em>}</li>
 *   <li>{@link plc.PlcData#getDigital <em>Digital</em>}</li>
 *   <li>{@link plc.PlcData#getAnalog <em>Analog</em>}</li>
 *   <li>{@link plc.PlcData#getMotor <em>Motor</em>}</li>
 *   <li>{@link plc.PlcData#getSignal <em>Signal</em>}</li>
 * </ul>
 *
 * @see plc.PlcPackage#getPlcData()
 * @model
 * @generated
 */
public interface PlcData extends EObject {
	/**
	 * Returns the value of the '<em><b>Sequence</b></em>' containment reference list.
	 * The list contents are of type {@link plc.Sequences}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sequence</em>' containment reference list.
	 * @see plc.PlcPackage#getPlcData_Sequence()
	 * @model containment="true"
	 * @generated
	 */
	EList<Sequences> getSequence();

	/**
	 * Returns the value of the '<em><b>Digital</b></em>' containment reference list.
	 * The list contents are of type {@link plc.digital}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Digital</em>' containment reference list.
	 * @see plc.PlcPackage#getPlcData_Digital()
	 * @model containment="true"
	 * @generated
	 */
	EList<digital> getDigital();

	/**
	 * Returns the value of the '<em><b>Analog</b></em>' containment reference list.
	 * The list contents are of type {@link plc.Analog}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Analog</em>' containment reference list.
	 * @see plc.PlcPackage#getPlcData_Analog()
	 * @model containment="true"
	 * @generated
	 */
	EList<Analog> getAnalog();

	/**
	 * Returns the value of the '<em><b>Motor</b></em>' containment reference list.
	 * The list contents are of type {@link plc.Motor}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Motor</em>' containment reference list.
	 * @see plc.PlcPackage#getPlcData_Motor()
	 * @model containment="true"
	 * @generated
	 */
	EList<Motor> getMotor();

	/**
	 * Returns the value of the '<em><b>Signal</b></em>' containment reference list.
	 * The list contents are of type {@link plc.Signal}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Signal</em>' containment reference list.
	 * @see plc.PlcPackage#getPlcData_Signal()
	 * @model containment="true"
	 * @generated
	 */
	EList<Signal> getSignal();

} // PlcData
