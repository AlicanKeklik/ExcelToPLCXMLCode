/**
 */
package plc;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Pin</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link plc.InputPin#getName <em>Name</em>}</li>
 *   <li>{@link plc.InputPin#getSignalType <em>Signal Type</em>}</li>
 *   <li>{@link plc.InputPin#getSignal <em>Signal</em>}</li>
 *   <li>{@link plc.InputPin#getOperator <em>Operator</em>}</li>
 * </ul>
 *
 * @see plc.PlcPackage#getInputPin()
 * @model
 * @generated
 */
public interface InputPin extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see plc.PlcPackage#getInputPin_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link plc.InputPin#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Signal Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Signal Type</em>' attribute.
	 * @see #setSignalType(String)
	 * @see plc.PlcPackage#getInputPin_SignalType()
	 * @model
	 * @generated
	 */
	String getSignalType();

	/**
	 * Sets the value of the '{@link plc.InputPin#getSignalType <em>Signal Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Signal Type</em>' attribute.
	 * @see #getSignalType()
	 * @generated
	 */
	void setSignalType(String value);

	/**
	 * Returns the value of the '<em><b>Signal</b></em>' reference list.
	 * The list contents are of type {@link plc.Signal}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Signal</em>' reference list.
	 * @see plc.PlcPackage#getInputPin_Signal()
	 * @model
	 * @generated
	 */
	EList<Signal> getSignal();

	/**
	 * Returns the value of the '<em><b>Operator</b></em>' containment reference list.
	 * The list contents are of type {@link plc.Operator}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operator</em>' containment reference list.
	 * @see plc.PlcPackage#getInputPin_Operator()
	 * @model containment="true"
	 * @generated
	 */
	EList<Operator> getOperator();

} // InputPin
