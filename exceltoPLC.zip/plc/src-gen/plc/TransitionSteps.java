/**
 */
package plc;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Transition Steps</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link plc.TransitionSteps#getName <em>Name</em>}</li>
 *   <li>{@link plc.TransitionSteps#getSignal <em>Signal</em>}</li>
 *   <li>{@link plc.TransitionSteps#getOperator <em>Operator</em>}</li>
 * </ul>
 *
 * @see plc.PlcPackage#getTransitionSteps()
 * @model
 * @generated
 */
public interface TransitionSteps extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see plc.PlcPackage#getTransitionSteps_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link plc.TransitionSteps#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Signal</b></em>' reference list.
	 * The list contents are of type {@link plc.Signal}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Signal</em>' reference list.
	 * @see plc.PlcPackage#getTransitionSteps_Signal()
	 * @model
	 * @generated
	 */
	EList<Signal> getSignal();

	/**
	 * Returns the value of the '<em><b>Operator</b></em>' containment reference list.
	 * The list contents are of type {@link plc.SeqOperator}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operator</em>' containment reference list.
	 * @see plc.PlcPackage#getTransitionSteps_Operator()
	 * @model containment="true"
	 * @generated
	 */
	EList<SeqOperator> getOperator();

} // TransitionSteps
