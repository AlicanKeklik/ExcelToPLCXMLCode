/**
 */
package plc.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;
import plc.InputPin;
import plc.Motor;
import plc.OutputPin;
import plc.PlcPackage;
import plc.Signal;
import plc.attribute;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Motor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link plc.impl.MotorImpl#getName <em>Name</em>}</li>
 *   <li>{@link plc.impl.MotorImpl#getDescription <em>Description</em>}</li>
 *   <li>{@link plc.impl.MotorImpl#getAttribute <em>Attribute</em>}</li>
 *   <li>{@link plc.impl.MotorImpl#getSignal <em>Signal</em>}</li>
 *   <li>{@link plc.impl.MotorImpl#getİnputpin <em>İnputpin</em>}</li>
 *   <li>{@link plc.impl.MotorImpl#getOutputpin <em>Outputpin</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MotorImpl extends MinimalEObjectImpl.Container implements Motor {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected static final String DESCRİPTİON_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected String description = DESCRİPTİON_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAttribute() <em>Attribute</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttribute()
	 * @generated
	 * @ordered
	 */
	protected attribute attribute;

	/**
	 * The cached value of the '{@link #getSignal() <em>Signal</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSignal()
	 * @generated
	 * @ordered
	 */
	protected EList<Signal> signal;

	/**
	 * The cached value of the '{@link #getİnputpin() <em>İnputpin</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getİnputpin()
	 * @generated
	 * @ordered
	 */
	protected EList<InputPin> inputpin;

	/**
	 * The cached value of the '{@link #getOutputpin() <em>Outputpin</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutputpin()
	 * @generated
	 * @ordered
	 */
	protected EList<OutputPin> outputpin;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MotorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PlcPackage.Literals.MOTOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PlcPackage.MOTOR__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getDescription() {
		return description;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDescription(String newDescription) {
		String oldDescription = description;
		description = newDescription;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PlcPackage.MOTOR__DESCRİPTİON, oldDescription,
					description));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public attribute getAttribute() {
		return attribute;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetAttribute(attribute newAttribute, NotificationChain msgs) {
		attribute oldAttribute = attribute;
		attribute = newAttribute;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, PlcPackage.MOTOR__ATTRİBUTE,
					oldAttribute, newAttribute);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setAttribute(attribute newAttribute) {
		if (newAttribute != attribute) {
			NotificationChain msgs = null;
			if (attribute != null)
				msgs = ((InternalEObject) attribute).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - PlcPackage.MOTOR__ATTRİBUTE, null, msgs);
			if (newAttribute != null)
				msgs = ((InternalEObject) newAttribute).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - PlcPackage.MOTOR__ATTRİBUTE, null, msgs);
			msgs = basicSetAttribute(newAttribute, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PlcPackage.MOTOR__ATTRİBUTE, newAttribute,
					newAttribute));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Signal> getSignal() {
		if (signal == null) {
			signal = new EObjectResolvingEList<Signal>(Signal.class, this, PlcPackage.MOTOR__SİGNAL);
		}
		return signal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<InputPin> getİnputpin() {
		if (inputpin == null) {
			inputpin = new EObjectContainmentEList<InputPin>(InputPin.class, this, PlcPackage.MOTOR__İNPUTPİN);
		}
		return inputpin;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<OutputPin> getOutputpin() {
		if (outputpin == null) {
			outputpin = new EObjectContainmentEList<OutputPin>(OutputPin.class, this, PlcPackage.MOTOR__OUTPUTPİN);
		}
		return outputpin;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Motor addMotor() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Signal addSignal() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */

	public void addSignal(Signal signal) {
		getSignal().add(signal);
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PlcPackage.MOTOR__ATTRİBUTE:
			return basicSetAttribute(null, msgs);
		case PlcPackage.MOTOR__İNPUTPİN:
			return ((InternalEList<?>) getİnputpin()).basicRemove(otherEnd, msgs);
		case PlcPackage.MOTOR__OUTPUTPİN:
			return ((InternalEList<?>) getOutputpin()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PlcPackage.MOTOR__NAME:
			return getName();
		case PlcPackage.MOTOR__DESCRİPTİON:
			return getDescription();
		case PlcPackage.MOTOR__ATTRİBUTE:
			return getAttribute();
		case PlcPackage.MOTOR__SİGNAL:
			return getSignal();
		case PlcPackage.MOTOR__İNPUTPİN:
			return getİnputpin();
		case PlcPackage.MOTOR__OUTPUTPİN:
			return getOutputpin();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PlcPackage.MOTOR__NAME:
			setName((String) newValue);
			return;
		case PlcPackage.MOTOR__DESCRİPTİON:
			setDescription((String) newValue);
			return;
		case PlcPackage.MOTOR__ATTRİBUTE:
			setAttribute((attribute) newValue);
			return;
		case PlcPackage.MOTOR__SİGNAL:
			getSignal().clear();
			getSignal().addAll((Collection<? extends Signal>) newValue);
			return;
		case PlcPackage.MOTOR__İNPUTPİN:
			getİnputpin().clear();
			getİnputpin().addAll((Collection<? extends InputPin>) newValue);
			return;
		case PlcPackage.MOTOR__OUTPUTPİN:
			getOutputpin().clear();
			getOutputpin().addAll((Collection<? extends OutputPin>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PlcPackage.MOTOR__NAME:
			setName(NAME_EDEFAULT);
			return;
		case PlcPackage.MOTOR__DESCRİPTİON:
			setDescription(DESCRİPTİON_EDEFAULT);
			return;
		case PlcPackage.MOTOR__ATTRİBUTE:
			setAttribute((attribute) null);
			return;
		case PlcPackage.MOTOR__SİGNAL:
			getSignal().clear();
			return;
		case PlcPackage.MOTOR__İNPUTPİN:
			getİnputpin().clear();
			return;
		case PlcPackage.MOTOR__OUTPUTPİN:
			getOutputpin().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PlcPackage.MOTOR__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case PlcPackage.MOTOR__DESCRİPTİON:
			return DESCRİPTİON_EDEFAULT == null ? description != null : !DESCRİPTİON_EDEFAULT.equals(description);
		case PlcPackage.MOTOR__ATTRİBUTE:
			return attribute != null;
		case PlcPackage.MOTOR__SİGNAL:
			return signal != null && !signal.isEmpty();
		case PlcPackage.MOTOR__İNPUTPİN:
			return inputpin != null && !inputpin.isEmpty();
		case PlcPackage.MOTOR__OUTPUTPİN:
			return outputpin != null && !outputpin.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case PlcPackage.MOTOR___ADD_MOTOR:
			return addMotor();
		case PlcPackage.MOTOR___ADD_SİGNAL:
			return addSignal();
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(", Description: ");
		result.append(description);
		result.append(')');
		return result.toString();
	}

} //MotorImpl
