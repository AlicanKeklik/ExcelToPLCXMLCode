/**
 */
package plc.impl;

import java.util.Collection;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import plc.Analog;
import plc.Motor;
import plc.PlcData;
import plc.PlcPackage;
import plc.Sequences;
import plc.Signal;
import plc.digital;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Data</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link plc.impl.PlcDataImpl#getSequence <em>Sequence</em>}</li>
 *   <li>{@link plc.impl.PlcDataImpl#getDigital <em>Digital</em>}</li>
 *   <li>{@link plc.impl.PlcDataImpl#getAnalog <em>Analog</em>}</li>
 *   <li>{@link plc.impl.PlcDataImpl#getMotor <em>Motor</em>}</li>
 *   <li>{@link plc.impl.PlcDataImpl#getSignal <em>Signal</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PlcDataImpl extends MinimalEObjectImpl.Container implements PlcData {
	/**
	 * The cached value of the '{@link #getSequence() <em>Sequence</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSequence()
	 * @generated
	 * @ordered
	 */
	protected EList<Sequences> sequence;

	/**
	 * The cached value of the '{@link #getDigital() <em>Digital</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDigital()
	 * @generated
	 * @ordered
	 */
	protected EList<digital> digital;

	/**
	 * The cached value of the '{@link #getAnalog() <em>Analog</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAnalog()
	 * @generated
	 * @ordered
	 */
	protected EList<Analog> analog;

	/**
	 * The cached value of the '{@link #getMotor() <em>Motor</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMotor()
	 * @generated
	 * @ordered
	 */
	protected EList<Motor> motor;

	/**
	 * The cached value of the '{@link #getSignal() <em>Signal</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSignal()
	 * @generated
	 * @ordered
	 */
	protected EList<Signal> signal;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PlcDataImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PlcPackage.Literals.PLC_DATA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Sequences> getSequence() {
		if (sequence == null) {
			sequence = new EObjectContainmentEList<Sequences>(Sequences.class, this, PlcPackage.PLC_DATA__SEQUENCE);
		}
		return sequence;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<digital> getDigital() {
		if (digital == null) {
			digital = new EObjectContainmentEList<digital>(digital.class, this, PlcPackage.PLC_DATA__DİGİTAL);
		}
		return digital;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Analog> getAnalog() {
		if (analog == null) {
			analog = new EObjectContainmentEList<Analog>(Analog.class, this, PlcPackage.PLC_DATA__ANALOG);
		}
		return analog;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Motor> getMotor() {
		if (motor == null) {
			motor = new EObjectContainmentEList<Motor>(Motor.class, this, PlcPackage.PLC_DATA__MOTOR);
		}
		return motor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Signal> getSignal() {
		if (signal == null) {
			signal = new EObjectContainmentEList<Signal>(Signal.class, this, PlcPackage.PLC_DATA__SİGNAL);
		}
		return signal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PlcPackage.PLC_DATA__SEQUENCE:
			return ((InternalEList<?>) getSequence()).basicRemove(otherEnd, msgs);
		case PlcPackage.PLC_DATA__DİGİTAL:
			return ((InternalEList<?>) getDigital()).basicRemove(otherEnd, msgs);
		case PlcPackage.PLC_DATA__ANALOG:
			return ((InternalEList<?>) getAnalog()).basicRemove(otherEnd, msgs);
		case PlcPackage.PLC_DATA__MOTOR:
			return ((InternalEList<?>) getMotor()).basicRemove(otherEnd, msgs);
		case PlcPackage.PLC_DATA__SİGNAL:
			return ((InternalEList<?>) getSignal()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PlcPackage.PLC_DATA__SEQUENCE:
			return getSequence();
		case PlcPackage.PLC_DATA__DİGİTAL:
			return getDigital();
		case PlcPackage.PLC_DATA__ANALOG:
			return getAnalog();
		case PlcPackage.PLC_DATA__MOTOR:
			return getMotor();
		case PlcPackage.PLC_DATA__SİGNAL:
			return getSignal();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PlcPackage.PLC_DATA__SEQUENCE:
			getSequence().clear();
			getSequence().addAll((Collection<? extends Sequences>) newValue);
			return;
		case PlcPackage.PLC_DATA__DİGİTAL:
			getDigital().clear();
			getDigital().addAll((Collection<? extends digital>) newValue);
			return;
		case PlcPackage.PLC_DATA__ANALOG:
			getAnalog().clear();
			getAnalog().addAll((Collection<? extends Analog>) newValue);
			return;
		case PlcPackage.PLC_DATA__MOTOR:
			getMotor().clear();
			getMotor().addAll((Collection<? extends Motor>) newValue);
			return;
		case PlcPackage.PLC_DATA__SİGNAL:
			getSignal().clear();
			getSignal().addAll((Collection<? extends Signal>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PlcPackage.PLC_DATA__SEQUENCE:
			getSequence().clear();
			return;
		case PlcPackage.PLC_DATA__DİGİTAL:
			getDigital().clear();
			return;
		case PlcPackage.PLC_DATA__ANALOG:
			getAnalog().clear();
			return;
		case PlcPackage.PLC_DATA__MOTOR:
			getMotor().clear();
			return;
		case PlcPackage.PLC_DATA__SİGNAL:
			getSignal().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PlcPackage.PLC_DATA__SEQUENCE:
			return sequence != null && !sequence.isEmpty();
		case PlcPackage.PLC_DATA__DİGİTAL:
			return digital != null && !digital.isEmpty();
		case PlcPackage.PLC_DATA__ANALOG:
			return analog != null && !analog.isEmpty();
		case PlcPackage.PLC_DATA__MOTOR:
			return motor != null && !motor.isEmpty();
		case PlcPackage.PLC_DATA__SİGNAL:
			return signal != null && !signal.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //PlcDataImpl
