/**
 */
package plc.impl;

import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;
import plc.InputPin;
import plc.OutputPin;
import plc.PlcPackage;
import plc.Signal;
import plc.attribute;
import plc.digital;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>digital</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link plc.impl.digitalImpl#getSettings <em>Settings</em>}</li>
 *   <li>{@link plc.impl.digitalImpl#getAttributefordigital <em>Attributefordigital</em>}</li>
 *   <li>{@link plc.impl.digitalImpl#getSignal <em>Signal</em>}</li>
 *   <li>{@link plc.impl.digitalImpl#getİnputpinfordigital <em>İnputpinfordigital</em>}</li>
 *   <li>{@link plc.impl.digitalImpl#getOutputpin <em>Outputpin</em>}</li>
 * </ul>
 *
 * @generated
 */
public class digitalImpl extends MinimalEObjectImpl.Container implements digital {
	/**
	 * The default value of the '{@link #getSettings() <em>Settings</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSettings()
	 * @generated
	 * @ordered
	 */
	protected static final String SETTİNGS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSettings() <em>Settings</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSettings()
	 * @generated
	 * @ordered
	 */
	protected String settings = SETTİNGS_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAttributefordigital() <em>Attributefordigital</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttributefordigital()
	 * @generated
	 * @ordered
	 */
	protected attribute attributefordigital;

	/**
	 * The cached value of the '{@link #getSignal() <em>Signal</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSignal()
	 * @generated
	 * @ordered
	 */
	protected EList<Signal> signal;

	/**
	 * The cached value of the '{@link #getİnputpinfordigital() <em>İnputpinfordigital</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getİnputpinfordigital()
	 * @generated
	 * @ordered
	 */
	protected EList<InputPin> inputpinfordigital;

	/**
	 * The cached value of the '{@link #getOutputpin() <em>Outputpin</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutputpin()
	 * @generated
	 * @ordered
	 */
	protected EList<OutputPin> outputpin;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected digitalImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PlcPackage.Literals.DİGİTAL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getSettings() {
		return settings;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSettings(String newSettings) {
		String oldSettings = settings;
		settings = newSettings;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PlcPackage.DİGİTAL__SETTİNGS, oldSettings, settings));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public attribute getAttributefordigital() {
		return attributefordigital;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetAttributefordigital(attribute newAttributefordigital, NotificationChain msgs) {
		attribute oldAttributefordigital = attributefordigital;
		attributefordigital = newAttributefordigital;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PlcPackage.DİGİTAL__ATTRİBUTEFORDİGİTAL, oldAttributefordigital, newAttributefordigital);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setAttributefordigital(attribute newAttributefordigital) {
		if (newAttributefordigital != attributefordigital) {
			NotificationChain msgs = null;
			if (attributefordigital != null)
				msgs = ((InternalEObject) attributefordigital).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - PlcPackage.DİGİTAL__ATTRİBUTEFORDİGİTAL, null, msgs);
			if (newAttributefordigital != null)
				msgs = ((InternalEObject) newAttributefordigital).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - PlcPackage.DİGİTAL__ATTRİBUTEFORDİGİTAL, null, msgs);
			msgs = basicSetAttributefordigital(newAttributefordigital, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PlcPackage.DİGİTAL__ATTRİBUTEFORDİGİTAL,
					newAttributefordigital, newAttributefordigital));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Signal> getSignal() {
		if (signal == null) {
			signal = new EObjectResolvingEList<Signal>(Signal.class, this, PlcPackage.DİGİTAL__SİGNAL);
		}
		return signal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<InputPin> getİnputpinfordigital() {
		if (inputpinfordigital == null) {
			inputpinfordigital = new EObjectContainmentEList<InputPin>(InputPin.class, this,
					PlcPackage.DİGİTAL__İNPUTPİNFORDİGİTAL);
		}
		return inputpinfordigital;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<OutputPin> getOutputpin() {
		if (outputpin == null) {
			outputpin = new EObjectContainmentEList<OutputPin>(OutputPin.class, this, PlcPackage.DİGİTAL__OUTPUTPİN);
		}
		return outputpin;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PlcPackage.DİGİTAL__ATTRİBUTEFORDİGİTAL:
			return basicSetAttributefordigital(null, msgs);
		case PlcPackage.DİGİTAL__İNPUTPİNFORDİGİTAL:
			return ((InternalEList<?>) getİnputpinfordigital()).basicRemove(otherEnd, msgs);
		case PlcPackage.DİGİTAL__OUTPUTPİN:
			return ((InternalEList<?>) getOutputpin()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PlcPackage.DİGİTAL__SETTİNGS:
			return getSettings();
		case PlcPackage.DİGİTAL__ATTRİBUTEFORDİGİTAL:
			return getAttributefordigital();
		case PlcPackage.DİGİTAL__SİGNAL:
			return getSignal();
		case PlcPackage.DİGİTAL__İNPUTPİNFORDİGİTAL:
			return getİnputpinfordigital();
		case PlcPackage.DİGİTAL__OUTPUTPİN:
			return getOutputpin();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PlcPackage.DİGİTAL__SETTİNGS:
			setSettings((String) newValue);
			return;
		case PlcPackage.DİGİTAL__ATTRİBUTEFORDİGİTAL:
			setAttributefordigital((attribute) newValue);
			return;
		case PlcPackage.DİGİTAL__SİGNAL:
			getSignal().clear();
			getSignal().addAll((Collection<? extends Signal>) newValue);
			return;
		case PlcPackage.DİGİTAL__İNPUTPİNFORDİGİTAL:
			getİnputpinfordigital().clear();
			getİnputpinfordigital().addAll((Collection<? extends InputPin>) newValue);
			return;
		case PlcPackage.DİGİTAL__OUTPUTPİN:
			getOutputpin().clear();
			getOutputpin().addAll((Collection<? extends OutputPin>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PlcPackage.DİGİTAL__SETTİNGS:
			setSettings(SETTİNGS_EDEFAULT);
			return;
		case PlcPackage.DİGİTAL__ATTRİBUTEFORDİGİTAL:
			setAttributefordigital((attribute) null);
			return;
		case PlcPackage.DİGİTAL__SİGNAL:
			getSignal().clear();
			return;
		case PlcPackage.DİGİTAL__İNPUTPİNFORDİGİTAL:
			getİnputpinfordigital().clear();
			return;
		case PlcPackage.DİGİTAL__OUTPUTPİN:
			getOutputpin().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PlcPackage.DİGİTAL__SETTİNGS:
			return SETTİNGS_EDEFAULT == null ? settings != null : !SETTİNGS_EDEFAULT.equals(settings);
		case PlcPackage.DİGİTAL__ATTRİBUTEFORDİGİTAL:
			return attributefordigital != null;
		case PlcPackage.DİGİTAL__SİGNAL:
			return signal != null && !signal.isEmpty();
		case PlcPackage.DİGİTAL__İNPUTPİNFORDİGİTAL:
			return inputpinfordigital != null && !inputpinfordigital.isEmpty();
		case PlcPackage.DİGİTAL__OUTPUTPİN:
			return outputpin != null && !outputpin.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Settings: ");
		result.append(settings);
		result.append(')');
		return result.toString();
	}

} //digitalImpl
