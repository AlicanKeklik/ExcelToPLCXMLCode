/**
 */
package plc.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import plc.PlcPackage;
import plc.Signal;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Signal</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link plc.impl.SignalImpl#getName <em>Name</em>}</li>
 *   <li>{@link plc.impl.SignalImpl#getSignalType <em>Signal Type</em>}</li>
 *   <li>{@link plc.impl.SignalImpl#getFunctionBlockRef <em>Function Block Ref</em>}</li>
 *   <li>{@link plc.impl.SignalImpl#getIdNbr <em>Id Nbr</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SignalImpl extends MinimalEObjectImpl.Container implements Signal {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getSignalType() <em>Signal Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSignalType()
	 * @generated
	 * @ordered
	 */
	protected static final String SİGNAL_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSignalType() <em>Signal Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSignalType()
	 * @generated
	 * @ordered
	 */
	protected String signalType = SİGNAL_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getFunctionBlockRef() <em>Function Block Ref</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFunctionBlockRef()
	 * @generated
	 * @ordered
	 */
	protected static final String FUNCTİON_BLOCK_REF_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFunctionBlockRef() <em>Function Block Ref</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFunctionBlockRef()
	 * @generated
	 * @ordered
	 */
	protected String functionBlockRef = FUNCTİON_BLOCK_REF_EDEFAULT;

	/**
	 * The default value of the '{@link #getIdNbr() <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdNbr()
	 * @generated
	 * @ordered
	 */
	protected static final int ID_NBR_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getIdNbr() <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdNbr()
	 * @generated
	 * @ordered
	 */
	protected int ıdNbr = ID_NBR_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SignalImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PlcPackage.Literals.SİGNAL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PlcPackage.SİGNAL__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getSignalType() {
		return signalType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSignalType(String newSignalType) {
		String oldSignalType = signalType;
		signalType = newSignalType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PlcPackage.SİGNAL__SİGNAL_TYPE, oldSignalType,
					signalType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getFunctionBlockRef() {
		return functionBlockRef;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setFunctionBlockRef(String newFunctionBlockRef) {
		String oldFunctionBlockRef = functionBlockRef;
		functionBlockRef = newFunctionBlockRef;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PlcPackage.SİGNAL__FUNCTİON_BLOCK_REF,
					oldFunctionBlockRef, functionBlockRef));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getIdNbr() {
		return ıdNbr;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIdNbr(int newIdNbr) {
		int oldIdNbr = ıdNbr;
		ıdNbr = newIdNbr;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PlcPackage.SİGNAL__ID_NBR, oldIdNbr, ıdNbr));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PlcPackage.SİGNAL__NAME:
			return getName();
		case PlcPackage.SİGNAL__SİGNAL_TYPE:
			return getSignalType();
		case PlcPackage.SİGNAL__FUNCTİON_BLOCK_REF:
			return getFunctionBlockRef();
		case PlcPackage.SİGNAL__ID_NBR:
			return getIdNbr();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PlcPackage.SİGNAL__NAME:
			setName((String) newValue);
			return;
		case PlcPackage.SİGNAL__SİGNAL_TYPE:
			setSignalType((String) newValue);
			return;
		case PlcPackage.SİGNAL__FUNCTİON_BLOCK_REF:
			setFunctionBlockRef((String) newValue);
			return;
		case PlcPackage.SİGNAL__ID_NBR:
			setIdNbr((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PlcPackage.SİGNAL__NAME:
			setName(NAME_EDEFAULT);
			return;
		case PlcPackage.SİGNAL__SİGNAL_TYPE:
			setSignalType(SİGNAL_TYPE_EDEFAULT);
			return;
		case PlcPackage.SİGNAL__FUNCTİON_BLOCK_REF:
			setFunctionBlockRef(FUNCTİON_BLOCK_REF_EDEFAULT);
			return;
		case PlcPackage.SİGNAL__ID_NBR:
			setIdNbr(ID_NBR_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PlcPackage.SİGNAL__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case PlcPackage.SİGNAL__SİGNAL_TYPE:
			return SİGNAL_TYPE_EDEFAULT == null ? signalType != null : !SİGNAL_TYPE_EDEFAULT.equals(signalType);
		case PlcPackage.SİGNAL__FUNCTİON_BLOCK_REF:
			return FUNCTİON_BLOCK_REF_EDEFAULT == null ? functionBlockRef != null
					: !FUNCTİON_BLOCK_REF_EDEFAULT.equals(functionBlockRef);
		case PlcPackage.SİGNAL__ID_NBR:
			return ıdNbr != ID_NBR_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(", SignalType: ");
		result.append(signalType);
		result.append(", FunctionBlockRef: ");
		result.append(functionBlockRef);
		result.append(", IdNbr: ");
		result.append(ıdNbr);
		result.append(')');
		return result.toString();
	}

} //SignalImpl
