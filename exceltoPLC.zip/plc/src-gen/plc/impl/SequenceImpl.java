/**
 */
package plc.impl;

import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;
import plc.PlcPackage;
import plc.Sequence;
import plc.Signal;
import plc.TransitionSteps;
import plc.attribute;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Sequence</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link plc.impl.SequenceImpl#getSettings <em>Settings</em>}</li>
 *   <li>{@link plc.impl.SequenceImpl#getSignal <em>Signal</em>}</li>
 *   <li>{@link plc.impl.SequenceImpl#getTransitionsteps <em>Transitionsteps</em>}</li>
 *   <li>{@link plc.impl.SequenceImpl#getAttribute <em>Attribute</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SequenceImpl extends MinimalEObjectImpl.Container implements Sequence {
	/**
	 * The default value of the '{@link #getSettings() <em>Settings</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSettings()
	 * @generated
	 * @ordered
	 */
	protected static final String SETTINGS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSettings() <em>Settings</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSettings()
	 * @generated
	 * @ordered
	 */
	protected String settings = SETTINGS_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSignal() <em>Signal</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSignal()
	 * @generated
	 * @ordered
	 */
	protected EList<Signal> signal;

	/**
	 * The cached value of the '{@link #getTransitionsteps() <em>Transitionsteps</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransitionsteps()
	 * @generated
	 * @ordered
	 */
	protected EList<TransitionSteps> transitionsteps;

	/**
	 * The cached value of the '{@link #getAttribute() <em>Attribute</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttribute()
	 * @generated
	 * @ordered
	 */
	protected attribute attribute;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SequenceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PlcPackage.Literals.SEQUENCES;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getSettings() {
		return settings;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSettings(String newSettings) {
		String oldSettings = settings;
		settings = newSettings;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PlcPackage.SEQUENCES__SETTINGS, oldSettings,
					settings));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public attribute getAttribute() {
		return attribute;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetAttribute(attribute newAttribute, NotificationChain msgs) {
		attribute oldAttribute = attribute;
		attribute = newAttribute;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PlcPackage.SEQUENCES__ATTRIBUTE, oldAttribute, newAttribute);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setAttribute(attribute newAttribute) {
		if (newAttribute != attribute) {
			NotificationChain msgs = null;
			if (attribute != null)
				msgs = ((InternalEObject) attribute).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - PlcPackage.SEQUENCES__ATTRIBUTE, null, msgs);
			if (newAttribute != null)
				msgs = ((InternalEObject) newAttribute).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - PlcPackage.SEQUENCES__ATTRIBUTE, null, msgs);
			msgs = basicSetAttribute(newAttribute, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PlcPackage.SEQUENCES__ATTRIBUTE, newAttribute,
					newAttribute));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<TransitionSteps> getTransitionsteps() {
		if (transitionsteps == null) {
			transitionsteps = new EObjectContainmentEList<TransitionSteps>(TransitionSteps.class, this,
					PlcPackage.SEQUENCES__TRANSITIONSTEPS);
		}
		return transitionsteps;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PlcPackage.SEQUENCES__TRANSITIONSTEPS:
			return ((InternalEList<?>) getTransitionsteps()).basicRemove(otherEnd, msgs);
		case PlcPackage.SEQUENCES__ATTRIBUTE:
			return basicSetAttribute(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Signal> getSignal() {
		if (signal == null) {
			signal = new EObjectResolvingEList<Signal>(Signal.class, this, PlcPackage.SEQUENCES__SIGNAL);
		}
		return signal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PlcPackage.SEQUENCES__SETTINGS:
			return getSettings();
		case PlcPackage.SEQUENCES__SIGNAL:
			return getSignal();
		case PlcPackage.SEQUENCES__TRANSITIONSTEPS:
			return getTransitionsteps();
		case PlcPackage.SEQUENCES__ATTRIBUTE:
			return getAttribute();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PlcPackage.SEQUENCES__SETTINGS:
			setSettings((String) newValue);
			return;
		case PlcPackage.SEQUENCES__SIGNAL:
			getSignal().clear();
			getSignal().addAll((Collection<? extends Signal>) newValue);
			return;
		case PlcPackage.SEQUENCES__TRANSITIONSTEPS:
			getTransitionsteps().clear();
			getTransitionsteps().addAll((Collection<? extends TransitionSteps>) newValue);
			return;
		case PlcPackage.SEQUENCES__ATTRIBUTE:
			setAttribute((attribute) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PlcPackage.SEQUENCES__SETTINGS:
			setSettings(SETTINGS_EDEFAULT);
			return;
		case PlcPackage.SEQUENCES__SIGNAL:
			getSignal().clear();
			return;
		case PlcPackage.SEQUENCES__TRANSITIONSTEPS:
			getTransitionsteps().clear();
			return;
		case PlcPackage.SEQUENCES__ATTRIBUTE:
			setAttribute((attribute) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PlcPackage.SEQUENCES__SETTINGS:
			return SETTINGS_EDEFAULT == null ? settings != null : !SETTINGS_EDEFAULT.equals(settings);
		case PlcPackage.SEQUENCES__SIGNAL:
			return signal != null && !signal.isEmpty();
		case PlcPackage.SEQUENCES__TRANSITIONSTEPS:
			return transitionsteps != null && !transitionsteps.isEmpty();
		case PlcPackage.SEQUENCES__ATTRIBUTE:
			return attribute != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Settings: ");
		result.append(settings);
		result.append(')');
		return result.toString();
	}

} //SequenceImpl
