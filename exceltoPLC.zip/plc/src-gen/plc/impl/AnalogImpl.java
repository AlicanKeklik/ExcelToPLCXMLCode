/**
 */
package plc.impl;

import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;
import plc.Analog;
import plc.InputPin;
import plc.OutputPin;
import plc.PlcPackage;
import plc.Signal;
import plc.attribute;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Analog</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link plc.impl.AnalogImpl#getSettings <em>Settings</em>}</li>
 *   <li>{@link plc.impl.AnalogImpl#getSignal <em>Signal</em>}</li>
 *   <li>{@link plc.impl.AnalogImpl#getİnputpinforanalog <em>İnputpinforanalog</em>}</li>
 *   <li>{@link plc.impl.AnalogImpl#getAttributeforanalog <em>Attributeforanalog</em>}</li>
 *   <li>{@link plc.impl.AnalogImpl#getOutputpin <em>Outputpin</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AnalogImpl extends MinimalEObjectImpl.Container implements Analog {
	/**
	 * The default value of the '{@link #getSettings() <em>Settings</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSettings()
	 * @generated
	 * @ordered
	 */
	protected static final String SETTİNGS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSettings() <em>Settings</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSettings()
	 * @generated
	 * @ordered
	 */
	protected String settings = SETTİNGS_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSignal() <em>Signal</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSignal()
	 * @generated
	 * @ordered
	 */
	protected EList<Signal> signal;

	/**
	 * The cached value of the '{@link #getİnputpinforanalog() <em>İnputpinforanalog</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getİnputpinforanalog()
	 * @generated
	 * @ordered
	 */
	protected EList<InputPin> inputpinforanalog;

	/**
	 * The cached value of the '{@link #getAttributeforanalog() <em>Attributeforanalog</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttributeforanalog()
	 * @generated
	 * @ordered
	 */
	protected attribute attributeforanalog;

	/**
	 * The cached value of the '{@link #getOutputpin() <em>Outputpin</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutputpin()
	 * @generated
	 * @ordered
	 */
	protected EList<OutputPin> outputpin;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AnalogImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PlcPackage.Literals.ANALOG;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public attribute getAttributeforanalog() {
		return attributeforanalog;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetAttributeforanalog(attribute newAttributeforanalog, NotificationChain msgs) {
		attribute oldAttributeforanalog = attributeforanalog;
		attributeforanalog = newAttributeforanalog;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PlcPackage.ANALOG__ATTRİBUTEFORANALOG, oldAttributeforanalog, newAttributeforanalog);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setAttributeforanalog(attribute newAttributeforanalog) {
		if (newAttributeforanalog != attributeforanalog) {
			NotificationChain msgs = null;
			if (attributeforanalog != null)
				msgs = ((InternalEObject) attributeforanalog).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - PlcPackage.ANALOG__ATTRİBUTEFORANALOG, null, msgs);
			if (newAttributeforanalog != null)
				msgs = ((InternalEObject) newAttributeforanalog).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - PlcPackage.ANALOG__ATTRİBUTEFORANALOG, null, msgs);
			msgs = basicSetAttributeforanalog(newAttributeforanalog, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PlcPackage.ANALOG__ATTRİBUTEFORANALOG,
					newAttributeforanalog, newAttributeforanalog));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<OutputPin> getOutputpin() {
		if (outputpin == null) {
			outputpin = new EObjectContainmentEList<OutputPin>(OutputPin.class, this, PlcPackage.ANALOG__OUTPUTPİN);
		}
		return outputpin;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PlcPackage.ANALOG__İNPUTPİNFORANALOG:
			return ((InternalEList<?>) getİnputpinforanalog()).basicRemove(otherEnd, msgs);
		case PlcPackage.ANALOG__ATTRİBUTEFORANALOG:
			return basicSetAttributeforanalog(null, msgs);
		case PlcPackage.ANALOG__OUTPUTPİN:
			return ((InternalEList<?>) getOutputpin()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getSettings() {
		return settings;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSettings(String newSettings) {
		String oldSettings = settings;
		settings = newSettings;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PlcPackage.ANALOG__SETTİNGS, oldSettings, settings));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Signal> getSignal() {
		if (signal == null) {
			signal = new EObjectResolvingEList<Signal>(Signal.class, this, PlcPackage.ANALOG__SİGNAL);
		}
		return signal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<InputPin> getİnputpinforanalog() {
		if (inputpinforanalog == null) {
			inputpinforanalog = new EObjectContainmentEList<InputPin>(InputPin.class, this,
					PlcPackage.ANALOG__İNPUTPİNFORANALOG);
		}
		return inputpinforanalog;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PlcPackage.ANALOG__SETTİNGS:
			return getSettings();
		case PlcPackage.ANALOG__SİGNAL:
			return getSignal();
		case PlcPackage.ANALOG__İNPUTPİNFORANALOG:
			return getİnputpinforanalog();
		case PlcPackage.ANALOG__ATTRİBUTEFORANALOG:
			return getAttributeforanalog();
		case PlcPackage.ANALOG__OUTPUTPİN:
			return getOutputpin();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PlcPackage.ANALOG__SETTİNGS:
			setSettings((String) newValue);
			return;
		case PlcPackage.ANALOG__SİGNAL:
			getSignal().clear();
			getSignal().addAll((Collection<? extends Signal>) newValue);
			return;
		case PlcPackage.ANALOG__İNPUTPİNFORANALOG:
			getİnputpinforanalog().clear();
			getİnputpinforanalog().addAll((Collection<? extends InputPin>) newValue);
			return;
		case PlcPackage.ANALOG__ATTRİBUTEFORANALOG:
			setAttributeforanalog((attribute) newValue);
			return;
		case PlcPackage.ANALOG__OUTPUTPİN:
			getOutputpin().clear();
			getOutputpin().addAll((Collection<? extends OutputPin>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PlcPackage.ANALOG__SETTİNGS:
			setSettings(SETTİNGS_EDEFAULT);
			return;
		case PlcPackage.ANALOG__SİGNAL:
			getSignal().clear();
			return;
		case PlcPackage.ANALOG__İNPUTPİNFORANALOG:
			getİnputpinforanalog().clear();
			return;
		case PlcPackage.ANALOG__ATTRİBUTEFORANALOG:
			setAttributeforanalog((attribute) null);
			return;
		case PlcPackage.ANALOG__OUTPUTPİN:
			getOutputpin().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PlcPackage.ANALOG__SETTİNGS:
			return SETTİNGS_EDEFAULT == null ? settings != null : !SETTİNGS_EDEFAULT.equals(settings);
		case PlcPackage.ANALOG__SİGNAL:
			return signal != null && !signal.isEmpty();
		case PlcPackage.ANALOG__İNPUTPİNFORANALOG:
			return inputpinforanalog != null && !inputpinforanalog.isEmpty();
		case PlcPackage.ANALOG__ATTRİBUTEFORANALOG:
			return attributeforanalog != null;
		case PlcPackage.ANALOG__OUTPUTPİN:
			return outputpin != null && !outputpin.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Settings: ");
		result.append(settings);
		result.append(')');
		return result.toString();
	}

} //AnalogImpl
