/**
 */
package plc;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Signal</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link plc.Signal#getName <em>Name</em>}</li>
 *   <li>{@link plc.Signal#getSignalType <em>Signal Type</em>}</li>
 *   <li>{@link plc.Signal#getFunctionBlockRef <em>Function Block Ref</em>}</li>
 *   <li>{@link plc.Signal#getIdNbr <em>Id Nbr</em>}</li>
 * </ul>
 *
 * @see plc.PlcPackage#getSignal()
 * @model
 * @generated
 */
public interface Signal extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see plc.PlcPackage#getSignal_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link plc.Signal#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Signal Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Signal Type</em>' attribute.
	 * @see #setSignalType(String)
	 * @see plc.PlcPackage#getSignal_SignalType()
	 * @model
	 * @generated
	 */
	String getSignalType();

	/**
	 * Sets the value of the '{@link plc.Signal#getSignalType <em>Signal Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Signal Type</em>' attribute.
	 * @see #getSignalType()
	 * @generated
	 */
	void setSignalType(String value);

	/**
	 * Returns the value of the '<em><b>Function Block Ref</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Function Block Ref</em>' attribute.
	 * @see #setFunctionBlockRef(String)
	 * @see plc.PlcPackage#getSignal_FunctionBlockRef()
	 * @model
	 * @generated
	 */
	String getFunctionBlockRef();

	/**
	 * Sets the value of the '{@link plc.Signal#getFunctionBlockRef <em>Function Block Ref</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Function Block Ref</em>' attribute.
	 * @see #getFunctionBlockRef()
	 * @generated
	 */
	void setFunctionBlockRef(String value);

	/**
	 * Returns the value of the '<em><b>Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id Nbr</em>' attribute.
	 * @see #setIdNbr(int)
	 * @see plc.PlcPackage#getSignal_IdNbr()
	 * @model
	 * @generated
	 */
	int getIdNbr();

	/**
	 * Sets the value of the '{@link plc.Signal#getIdNbr <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id Nbr</em>' attribute.
	 * @see #getIdNbr()
	 * @generated
	 */
	void setIdNbr(int value);

} // Signal
