/**
 */
package secondModel.provider;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

import secondModel.PopulatingSteps;
import secondModel.SecondModelFactory;
import secondModel.SecondModelPackage;

/**
 * This is the item provider adapter for a {@link secondModel.PopulatingSteps} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class PopulatingStepsItemProvider extends ItemProviderAdapter implements IEditingDomainItemProvider,
		IStructuredItemContentProvider, ITreeItemContentProvider, IItemLabelProvider, IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PopulatingStepsItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addSignalsPropertyDescriptor(object);
			addSignalNamePropertyDescriptor(object);
			addInputNamePropertyDescriptor(object);
			addIdNbrPropertyDescriptor(object);
			addNextIdNbrPropertyDescriptor(object);
			addTransitionIdNbrPropertyDescriptor(object);
			addLastTransitionIdNbrPropertyDescriptor(object);
			addLastTransitionStepNbrPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Signals feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addSignalsPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_PopulatingSteps_signals_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_PopulatingSteps_signals_feature",
								"_UI_PopulatingSteps_type"),
						SecondModelPackage.Literals.POPULATİNG_STEPS__SİGNALS, true, false, true, null, null, null));
	}

	/**
	 * This adds a property descriptor for the Signal Name feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addSignalNamePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_PopulatingSteps_SignalName_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_PopulatingSteps_SignalName_feature",
								"_UI_PopulatingSteps_type"),
						SecondModelPackage.Literals.POPULATİNG_STEPS__SİGNAL_NAME, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Input Name feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addInputNamePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_PopulatingSteps_InputName_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_PopulatingSteps_InputName_feature",
								"_UI_PopulatingSteps_type"),
						SecondModelPackage.Literals.POPULATİNG_STEPS__INPUT_NAME, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Id Nbr feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addIdNbrPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_PopulatingSteps_IdNbr_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_PopulatingSteps_IdNbr_feature",
								"_UI_PopulatingSteps_type"),
						SecondModelPackage.Literals.POPULATİNG_STEPS__ID_NBR, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Next Id Nbr feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addNextIdNbrPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_PopulatingSteps_NextIdNbr_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_PopulatingSteps_NextIdNbr_feature",
								"_UI_PopulatingSteps_type"),
						SecondModelPackage.Literals.POPULATİNG_STEPS__NEXT_ID_NBR, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Transition Id Nbr feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addTransitionIdNbrPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_PopulatingSteps_TransitionIdNbr_feature"),
				getString("_UI_PropertyDescriptor_description", "_UI_PopulatingSteps_TransitionIdNbr_feature",
						"_UI_PopulatingSteps_type"),
				SecondModelPackage.Literals.POPULATİNG_STEPS__TRANSİTİON_ID_NBR, true, false, false,
				ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Last Transition Id Nbr feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addLastTransitionIdNbrPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_PopulatingSteps_LastTransitionIdNbr_feature"),
						getString("_UI_PropertyDescriptor_description",
								"_UI_PopulatingSteps_LastTransitionIdNbr_feature", "_UI_PopulatingSteps_type"),
						SecondModelPackage.Literals.POPULATİNG_STEPS__LAST_TRANSİTİON_ID_NBR, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Last Transition Step Nbr feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addLastTransitionStepNbrPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_PopulatingSteps_LastTransitionStepNbr_feature"),
						getString("_UI_PropertyDescriptor_description",
								"_UI_PopulatingSteps_LastTransitionStepNbr_feature", "_UI_PopulatingSteps_type"),
						SecondModelPackage.Literals.POPULATİNG_STEPS__LAST_TRANSİTİON_STEP_NBR, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
	 * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
	 * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Collection<? extends EStructuralFeature> getChildrenFeatures(Object object) {
		if (childrenFeatures == null) {
			super.getChildrenFeatures(object);
			childrenFeatures.add(SecondModelPackage.Literals.POPULATİNG_STEPS__SEQOPERATOR);
		}
		return childrenFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EStructuralFeature getChildFeature(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildFeature(object, child);
	}

	/**
	 * This returns PopulatingSteps.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/PopulatingSteps"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((PopulatingSteps) object).getSignalName();
		return label == null || label.length() == 0 ? getString("_UI_PopulatingSteps_type")
				: getString("_UI_PopulatingSteps_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(PopulatingSteps.class)) {
		case SecondModelPackage.POPULATİNG_STEPS__SİGNAL_NAME:
		case SecondModelPackage.POPULATİNG_STEPS__INPUT_NAME:
		case SecondModelPackage.POPULATİNG_STEPS__ID_NBR:
		case SecondModelPackage.POPULATİNG_STEPS__NEXT_ID_NBR:
		case SecondModelPackage.POPULATİNG_STEPS__TRANSİTİON_ID_NBR:
		case SecondModelPackage.POPULATİNG_STEPS__LAST_TRANSİTİON_ID_NBR:
		case SecondModelPackage.POPULATİNG_STEPS__LAST_TRANSİTİON_STEP_NBR:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		case SecondModelPackage.POPULATİNG_STEPS__SEQOPERATOR:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add(createChildParameter(SecondModelPackage.Literals.POPULATİNG_STEPS__SEQOPERATOR,
				SecondModelFactory.eINSTANCE.createSeqOperator()));
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		return SecondModelEditPlugin.INSTANCE;
	}

}
