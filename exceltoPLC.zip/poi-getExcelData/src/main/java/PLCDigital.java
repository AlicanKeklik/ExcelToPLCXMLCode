import java.util.ArrayList;

import plc.InputPin;
import plc.Operator;
import plc.OutputPin;
import plc.PlcData;
import plc.PlcFactory;
import plc.Signal;
import plc.attribute;
import plc.digital;

public class PLCDigital {
	private PlcData plcdata;
	private digital digital = PlcFactory.eINSTANCE.createdigital();
	private int operatorsItemNum = 0;
	private boolean isOperator = false;
	private ArrayList<Operator> operators = new ArrayList<>();

	public PLCDigital(PlcData plcdata) {
		this.plcdata = plcdata;
	}

	public void setAttribute(String name, String description, String libraryUsed) {
		attribute atr = PlcFactory.eINSTANCE.createattribute();
		atr.setDescription(description);
		atr.setLibraryName(libraryUsed);
		atr.setName(name);
		digital.setAttributefordigital(atr);

	}

	public void setSignal(String signalName, String type, String belongsTo) {
		boolean namePresent = false;
		int i;
		for (i = 0; i < plcdata.getSignal().size() - 1; i++) {
			if (plcdata.getSignal().get(i).getName().equals(signalName)) {
				namePresent = true;
				break;
			} else
				namePresent = false;
		}

		if (namePresent) {
			digital.getSignal().add(plcdata.getSignal().get(i));
			for (int k = 0; k < digital.getInputpinfordigital().size(); k++) {
				if (digital.getInputpinfordigital().get(k).getName().toString().equals(belongsTo)) {
					if (isOperator) {
						operators.get(operatorsItemNum).getSignal().add(plcdata.getSignal().get(i));
					} else {
						digital.getInputpinfordigital().get(k).getSignal().add(plcdata.getSignal().get(i));
					}
				}
			}
		} else {
			Signal signal = PlcFactory.eINSTANCE.createSignal();
			signal.setName(signalName);
			signal.setFunctionBlockRef(belongsTo);
			signal.setSignalType(type);
			plcdata.getSignal().add(signal);
			digital.getSignal().add(signal);

			for (int k = 0; k < digital.getInputpinfordigital().size(); k++) {

				if (digital.getInputpinfordigital().get(k).getName().toString().equals(belongsTo)) {
					if (isOperator) {
						operators.get(operatorsItemNum).getSignal().add(signal);
					} else {
						digital.getInputpinfordigital().get(k).getSignal().add(signal);
					}

				}
			}
		}

	}

	public void setInput(String InputPin) {
		InputPin input = PlcFactory.eINSTANCE.createInputPin();
		input.setName(InputPin);

		digital.getInputpinfordigital().add(input);
	}

	public void setOutput(String InputPin) {
		OutputPin output = PlcFactory.eINSTANCE.createOutputPin();
		output.setName(InputPin);
		digital.getOutputpin().add(output);

	}

	public void adddigitalInData() {
		plcdata.getDigital().add(digital);
	}

	public void setSignal(String signalName, String type, String belongsTo, Operator currentOperator) {
		boolean namePresent = false;
		int i;
		for (i = 0; i < plcdata.getSignal().size(); i++) {
			if (plcdata.getSignal().get(i).getName().equals(signalName)) {
				namePresent = true;
				break;
			} else
				namePresent = false;
		}
		if (namePresent) {
			digital.getSignal().add(plcdata.getSignal().get(i));
			for (int k = 0; k < digital.getInputpinfordigital().size(); k++) {
				if (digital.getInputpinfordigital().get(k).getName().toString().equals(belongsTo)) {
					if (isOperator) {

						operators.get(operators.size() - 1).getSignal().add(plcdata.getSignal().get(i));

					} else {
						digital.getInputpinfordigital().get(k).getSignal().add(plcdata.getSignal().get(i));
					}
				}
			}
		} else {
			Signal signal = PlcFactory.eINSTANCE.createSignal();
			signal.setName(signalName);
			signal.setFunctionBlockRef(belongsTo);
			signal.setSignalType(type);
			plcdata.getSignal().add(signal);
			digital.getSignal().add(signal);
			for (int k = 0; k < digital.getInputpinfordigital().size(); k++) {
				if (digital.getInputpinfordigital().get(k).getName().toString().equals(belongsTo)) {
					if (isOperator) {

						operators.get(operators.size() - 1).getSignal().add(signal);

					} else {
						digital.getInputpinfordigital().get(k).getSignal().add(signal);
					}
				}
			}
		}
	}

	public void setSignal(String signalName, String type, String belongsTo, boolean isOutputpin) {
		boolean namePresent = false;
		int i;
		for (i = 0; i < plcdata.getSignal().size() - 1; i++) {
			if (plcdata.getSignal().get(i).getName().equals(signalName)) {
				namePresent = true;
				break;
			} else
				namePresent = false;
		}

		if (!isOutputpin) {
			if (namePresent) {
				digital.getSignal().add(plcdata.getSignal().get(i));

				for (int k = 0; k < digital.getInputpinfordigital().size(); k++) {

					if (digital.getInputpinfordigital().get(k).getName().toString().equals(belongsTo)) {
						digital.getInputpinfordigital().get(k).getSignal().add(plcdata.getSignal().get(i));

					}
				}
			} else {
				Signal signal = PlcFactory.eINSTANCE.createSignal();
				signal.setName(signalName);
				signal.setFunctionBlockRef(belongsTo);
				signal.setSignalType(type);
				plcdata.getSignal().add(signal);
				digital.getSignal().add(signal);

				for (int k = 0; k < digital.getInputpinfordigital().size(); k++) {

					if (digital.getInputpinfordigital().get(k).getName().toString().equals(belongsTo)) {
						if (isOperator) {
							operators.get(operatorsItemNum).getSignal().add(signal);
						} else {
							digital.getInputpinfordigital().get(k).getSignal().add(signal);
						}

					}
				}
			}
		} else {
			if (namePresent) {
				digital.getSignal().add(plcdata.getSignal().get(i));

				for (int k = 0; k < digital.getOutputpin().size(); k++) {

					if (digital.getOutputpin().get(k).getName().toString().equals(belongsTo)) {
						digital.getOutputpin().get(k).getSignal().add(plcdata.getSignal().get(i));

					}
				}
			} else {
				Signal signal = PlcFactory.eINSTANCE.createSignal();
				signal.setName(signalName);
				signal.setFunctionBlockRef(belongsTo);
				signal.setSignalType(type);
				plcdata.getSignal().add(signal);
				digital.getSignal().add(signal);

				for (int k = 0; k < digital.getOutputpin().size(); k++) {
					if (digital.getOutputpin().get(k).getName().toString().equals(belongsTo)) {
						digital.getOutputpin().get(k).getSignal().add(signal);

					}
				}
			}

		}

	}

	public void setSignalWithOperators(ArrayList<ArrayList<String>> signalsWithOperation, String type,
			String belongsTo) {
		isOperator = true;
		for (ArrayList<String> innerList : signalsWithOperation) {

			Operator currentOperator = PlcFactory.eINSTANCE.createOperator();
			ArrayList<String> signalNames = new ArrayList<>();
			operators.add(currentOperator);
			operatorsItemNum++;
			for (String value : innerList) {
				if (value.equals("AND") || value.equals("OR")) {
					currentOperator.setType(value);
				} else if (!value.contains("block")) {
					signalNames.add(value);
				}
			}
			for (String signalName : signalNames) {
				setSignal(signalName, type, belongsTo, currentOperator);
			}

			if (operatorsItemNum > 1)
				operators.get(operatorsItemNum - 2).getOperator().add(currentOperator);

			digital.getInputpinfordigital().get(digital.getInputpinfordigital().size() - 1).getOperator()
					.add(currentOperator);

		}

		isOperator = false;
		operators.clear();
		operatorsItemNum = 0;
	}
}