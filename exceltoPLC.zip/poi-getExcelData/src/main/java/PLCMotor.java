import java.util.ArrayList;
import plc.Motor;
import plc.Operator;
import plc.PlcData;
import plc.PlcFactory;
import plc.Signal;
import plc.InputPin;
import plc.attribute;
import plc.OutputPin;

public class PLCMotor {
	private PlcData plcdata;
	private Motor motor = PlcFactory.eINSTANCE.createMotor();

	private int operatorsItemNum = 0;
	private boolean isOperator = false;

	private ArrayList<Operator> operators = new ArrayList<>();

	public PLCMotor(PlcData plcdata) {
		this.plcdata = plcdata;
	}

	public void setAttribute(String name, String description, String libraryUsed) {
		attribute atr = PlcFactory.eINSTANCE.createattribute();
		atr.setDescription(description);

		atr.setName(name);
		motor.setAttribute(atr);

	}

	public void setSignal(String signalName, String type, String belongsTo, boolean isOutputpin) {
		boolean namePresent = false;
		int i;
		for (i = 0; i < plcdata.getSignal().size() - 1; i++) {
			if (plcdata.getSignal().get(i).getName().equals(signalName)) {
				namePresent = true;
				break;
			} else
				namePresent = false;
		}

		if (!isOutputpin) {
			if (namePresent) {
				motor.getSignal().add(plcdata.getSignal().get(i));

				for (int k = 0; k < motor.getInputpin().size(); k++) {

					if (motor.getInputpin().get(k).getName().toString().equals(belongsTo)) {
						motor.getInputpin().get(k).getSignal().add(plcdata.getSignal().get(i));

					}
				}
			} else {
				Signal signal = PlcFactory.eINSTANCE.createSignal();
				signal.setName(signalName);
				signal.setFunctionBlockRef(belongsTo);
				signal.setSignalType(type);
				plcdata.getSignal().add(signal);
				motor.getSignal().add(signal);

				for (int k = 0; k < motor.getInputpin().size(); k++) {

					if (motor.getInputpin().get(k).getName().toString().equals(belongsTo)) {
						if (isOperator) {
							operators.get(operatorsItemNum).getSignal().add(signal);
						} else {
							motor.getInputpin().get(k).getSignal().add(signal);
						}

					}
				}
			}
		} else {
			if (namePresent) {
				motor.getSignal().add(plcdata.getSignal().get(i));

				for (int k = 0; k < motor.getOutputpin().size(); k++) {
					if (motor.getOutputpin().get(k).getName().toString().equals(belongsTo)) {
						motor.getOutputpin().get(k).getSignal().add(plcdata.getSignal().get(i));

					}
				}
			} else {
				Signal signal = PlcFactory.eINSTANCE.createSignal();
				signal.setName(signalName);
				signal.setFunctionBlockRef(belongsTo);
				signal.setSignalType(type);
				plcdata.getSignal().add(signal);
				motor.getSignal().add(signal);

				for (int k = 0; k < motor.getOutputpin().size(); k++) {
					if (motor.getOutputpin().get(k).getName().toString().equals(belongsTo)) {
						motor.getOutputpin().get(k).getSignal().add(signal);

					}
				}
			}

		}

	}

	public void setInput(String InputPin) {
		InputPin input = PlcFactory.eINSTANCE.createInputPin();
		input.setName(InputPin);
		motor.getInputpin().add(input);

	}

	public void addMotorInData() {
		plcdata.getMotor().add(motor);

	}

	public void setOutput(String InputPin) {
		OutputPin output = PlcFactory.eINSTANCE.createOutputPin();
		output.setName(InputPin);
		motor.getOutputpin().add(output);

	}

	public void setSignal(String signalName, String type, String belongsTo, Operator currentOperator) {
		boolean namePresent = false;
		int i;

		for (i = 0; i < plcdata.getSignal().size() - 1; i++) {
			if (plcdata.getSignal().get(i).getName().equals(signalName)) {
				namePresent = true;
				break;
			} else
				namePresent = false;
		}

		if (namePresent) {
			motor.getSignal().add(plcdata.getSignal().get(i));
			for (int k = 0; k < motor.getInputpin().size(); k++) {
				if (motor.getInputpin().get(k).getName().toString().equals(belongsTo)) {
					if (isOperator) {

						operators.get(operators.size() - 1).getSignal().add(plcdata.getSignal().get(i));

					} else {
						motor.getInputpin().get(k).getSignal().add(plcdata.getSignal().get(i));
					}
				}
			}
		} else {
			Signal signal = PlcFactory.eINSTANCE.createSignal();
			signal.setName(signalName);
			signal.setFunctionBlockRef(belongsTo);
			signal.setSignalType(type);
			plcdata.getSignal().add(signal);
			motor.getSignal().add(signal);

			for (int k = 0; k < motor.getInputpin().size(); k++) {
				if (motor.getInputpin().get(k).getName().toString().equals(belongsTo)) {
					if (isOperator) {

						operators.get(operators.size() - 1).getSignal().add(signal);

					} else {
						motor.getInputpin().get(k).getSignal().add(signal);
					}
				}
			}
		}
	}

	public void setSignalWithOperators(ArrayList<ArrayList<String>> signalsWithOperation, String type,
			String belongsTo) {
		isOperator = true;

		for (ArrayList<String> innerList : signalsWithOperation) {

			Operator currentOperator = PlcFactory.eINSTANCE.createOperator();
			ArrayList<String> signalNames = new ArrayList<>();
			operators.add(currentOperator);
			operatorsItemNum++;

			for (String value : innerList) {
				if (value.equals("AND") || value.equals("OR")) {
					currentOperator.setType(value);
				} else if (!value.contains("block")) {
					signalNames.add(value);
				}
			}

			for (String signalName : signalNames) {
				setSignal(signalName, type, belongsTo, currentOperator);
			}

			if (operatorsItemNum > 1)
				operators.get(operatorsItemNum - 2).getOperator().add(currentOperator);

			motor.getInputpin().get(motor.getInputpin().size() - 1).getOperator().add(currentOperator);

		}

		isOperator = false;
		operators.clear();
		operatorsItemNum = 0;
	}
}