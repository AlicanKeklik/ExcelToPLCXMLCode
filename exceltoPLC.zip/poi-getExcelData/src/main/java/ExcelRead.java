import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

import plc.PlcData;
import plc.PlcFactory;

public class ExcelRead {
	private XSSFWorkbook workbook;
	private int countingForInnerBlock = 0;
	private ArrayList<ArrayList<String>> signalsInBlocks = new ArrayList<>();

	public void readMotorsExcel(PlcData plcdata) {
		boolean isOutputpin = false;
		// Create the inputStream for the excel
		String[] signalNames = { "SAF1", "Il1", "FB1", "A1", "MAN", "AUT", "MCCRDY", "TRIP", "A0", "FB0", "IL0", "SAF0",
				"ORD1", "CFB1", "AUTMODE", "MANMODE", "ERR", "CFB0", "ORD0" };
		XSSFCell[] signals = new XSSFCell[signalNames.length + 4];// +4 for description , name ,type and library
		String[] signalsInString = new String[signalNames.length + 4];
		// Create the inputStream for the excel
		try (FileInputStream newIn = new FileInputStream("../excel.xlsm")) {
			workbook = new XSSFWorkbook(newIn);
			// Checks if the document has any sheets
			if (workbook.getNumberOfSheets() > 0) {
				// Start text for the EMFModel has to be
				XSSFSheet sheet = workbook.getSheetAt(0);
				for (int i = 1; i <= sheet.getLastRowNum(); i++) {
					XSSFRow row = sheet.getRow(i);
					if (row != null) {

						for (int j = 0; j < signals.length; j++) {
							signals[j] = row.getCell(j);
						}
						// ExcelRead excelReader = new ExcelRead();
						PLCMotor motor = new PLCMotor(plcdata);
						// PLCMotor motor = new PLCMotor(plcdata);
						for (int j = 0; j < signalsInString.length; j++) {
							signalsInString[j] = (signals[j] != null) ? signals[j].getStringCellValue() : "";
						}
						for (int j = 0; j < signalNames.length; j++) {
							if (j > 11) {
								isOutputpin = true;
								motor.setOutput(signalNames[j]);
							} else {
								isOutputpin = false;
								motor.setInput(signalNames[j]);
							}
							if (!signalsInString[j + 4].equals("")) {
								if (signalsInString[j + 4].contains("block")) {
									countingForInnerBlock = 0;
									readBlockSheet(workbook, signalsInString[j + 4]);
									motor.setSignalWithOperators(signalsInBlocks, "BOOL", signalNames[j]);
									signalsInBlocks.clear();

								} else {
									motor.setSignal(signalsInString[j + 4], "BOOL", signalNames[j], isOutputpin);
								}

							}
						}
						motor.setAttribute(signalsInString[0], signalsInString[1], signalsInString[3]);
						motor.addMotorInData();
					}
				}

			} else {
				System.out.println("The workbook contains no sheets.");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public XSSFWorkbook getWorkbook() {
		return workbook;
	}

	public void readSequenceExcel(PlcData plcdata) {

		boolean readHeaderRow = true;
		try (FileInputStream newIn = new FileInputStream("../excel.xlsm")) {
			workbook = new XSSFWorkbook(newIn);
			ArrayList<String> signalNames = new ArrayList<>();
			// Checks if the document has any sheets
			if (workbook.getNumberOfSheets() > 0) {
				// Start text for the EMFModel has to be
				XSSFSheet sheet = workbook.getSheetAt(1);
				// //System.out.println(sheet.getLastRowNum());
				XSSFRow rowzero = sheet.getRow(0);
				if (rowzero != null) {
					if (readHeaderRow) {
						for (int j = 2; j < rowzero.getLastCellNum(); j++) {
							XSSFCell cell = rowzero.getCell(j);
							if (cell != null) {
								signalNames.add(cell.getStringCellValue());
							} else {
								break;
							}
						}
						readHeaderRow = false;
					}
				}
				XSSFCell[] signals = new XSSFCell[signalNames.size() + 2];
				String[] signalsInString = new String[signalNames.size() + 2];
				for (int i = 1; i <= sheet.getLastRowNum(); i++) {
					XSSFRow row = sheet.getRow(i);
					if (row != null) {

						for (int j = 0; j < signals.length; j++) {
							signals[j] = row.getCell(j);

						}
						
						PLCSequence seq = new PLCSequence(plcdata);
						
						for (int j = 0; j < signalsInString.length; j++) {
							if (signals[j] != null) {
								if (signals[j].getCellType() == CellType.NUMERIC) {
									// If the cell is numeric, convert it to a string
									signalsInString[j] = String.valueOf(signals[j].getNumericCellValue());
								} else if (signals[j].getCellType() == CellType.STRING) {
									// If the cell is already a string, directly retrieve it
									signalsInString[j] = signals[j].getStringCellValue();
								} else {
									// Handle other cell types as needed
									signalsInString[j] = ""; // For other types, set an empty string or handle
																// differently
								}
							} else {
								signalsInString[j] = "";
							}
						}
						for (int j = 0; j < signalNames.size(); j++) {
							if (!signalsInString[j + 2].equals("")) {
								if (signalsInString[j + 2].contains("block")) {
							
									readBlockSheet(workbook, signalsInString[j + 2]);
									seq.setTransition(signalNames.get(j));
									seq.setSignalWithOperators(signalsInBlocks, "BOOL", signalNames.get(j));

								} else {
									seq.setTransition(signalNames.get(j));
									seq.setSignal(signalsInString[j + 2], "BOOL", signalNames.get(j));
									signalsInBlocks.clear();
								}

							}
						}
						seq.setAttribute(signalsInString[0], signalsInString[1], signalsInString[3]);
						seq.addSeqInData();
					}
				}
			} else {
				System.out.println("The workbook contains no sheets.");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void readAnalogsExcel(PlcData plcdata) {
		// Create the inputStream for the excel

		String[] signalNames = { "SignalIn", "MeasuringUnit", "Hysteresis", "MeasurementRangeLow",
				"MeasurementRangeHigh", "SettingH", "SettingHH", "SettingL", "SettingLL", "EnableH", "EnableHH",
				"EnableL", "EnableLL", "AlarmOut", "SignalOut", "OutputHH", "OutputH", "OutputL", "OutputLL" };
		XSSFCell[] signals = new XSSFCell[signalNames.length + 4];
		String[] signalsInString = new String[signalNames.length + 4];
		Boolean isOutputpin = false;
		// Create the inputStream for the excel
		try (FileInputStream newIn = new FileInputStream("../excel.xlsm")) {
			workbook = new XSSFWorkbook(newIn);
			// Checks if the document has any sheets
			if (workbook.getNumberOfSheets() > 0) {
				// Start text for the EMFModel has to be
				XSSFSheet sheet = workbook.getSheetAt(2);
				for (int i = 1; i <= sheet.getLastRowNum(); i++) {
					XSSFRow row = sheet.getRow(i);
					if (row != null) {

						for (int j = 0; j < signals.length; j++) {
							signals[j] = row.getCell(j);
						}

						PLCAnalog analog = new PLCAnalog(plcdata);

						for (int j = 0; j < signalsInString.length; j++) {

							if (signals[j] != null) {
								if (signals[j].getCellType() == CellType.NUMERIC) {
									// If the cell is numeric, convert it to a string
									signalsInString[j] = String.valueOf(signals[j].getNumericCellValue());
								} else if (signals[j].getCellType() == CellType.STRING) {
									// If the cell is already a string, directly retrieve it
									signalsInString[j] = signals[j].getStringCellValue();
								} else {
									// Handle other cell types as needed
									signalsInString[j] = "";
								}
							} else {
								// Handle null cells as needed
								signalsInString[j] = "";
							}
						}
						for (int j = 0; j < signalNames.length; j++) {
							if (j > signalNames.length - 7) {
								isOutputpin = true;
								analog.setOutput(signalNames[j]);
							} else {
								isOutputpin = false;
								analog.setInput(signalNames[j]);
							}

						
							if (!signalsInString[j + 4].equals("")) {
								if (signalsInString[j + 4].contains("block")) {
									countingForInnerBlock = 0;
									readBlockSheet(workbook, signalsInString[j + 4]);
									analog.setSignalWithOperators(signalsInBlocks, "BOOL", signalNames[j]);
									signalsInBlocks.clear();
								} else {
									if (j == 0) {
										analog.setSignal(signalsInString[j + 4], "REAL", signalNames[j], isOutputpin);
									} else if (j == 1) {
										analog.setSignal(signalsInString[j + 4], "string", signalNames[j], isOutputpin);
									} else if (j >= 2 && j <= 8) {
										analog.setSignal(signalsInString[j + 4], "REAL", signalNames[j], isOutputpin);
									} else if (j >= 9 && j <= 13) {
										analog.setSignal(signalsInString[j + 4], "BOOL", signalNames[j], isOutputpin);
									} else if (j == 14) {
										analog.setSignal(signalsInString[j + 4], "REAL", signalNames[j], isOutputpin);
									} else {
										analog.setSignal(signalsInString[j + 4], "BOOL", signalNames[j], isOutputpin);
									}
								}
							}
						}
						analog.setAttribute(signalsInString[0], signalsInString[1], signalsInString[3]);
						analog.addAnalogInData();
					}
				}
			} else {
				System.out.println("The workbook contains no sheets.");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void readDigitalExcel(PlcData plcdata) {

		String[] signalNames = { "AlarmText", "SignalIn", "EnableAlarm", "InvertSignal", "DelayTimeAlarm", "DelayTime",
				"Out", "AlarmOut" };
		XSSFCell[] signals = new XSSFCell[signalNames.length + 4];
		String[] signalsInString = new String[signalNames.length + 4];
		Boolean isOutputpin = false;
		// Create the inputStream for the excel
		try (FileInputStream newIn = new FileInputStream("../excel.xlsm")) {
			workbook = new XSSFWorkbook(newIn);
			// Checks if the document has any sheets
			if (workbook.getNumberOfSheets() > 0) {
				// Start text for the EMFModel has to be
				XSSFSheet sheet = workbook.getSheetAt(3);
				for (int i = 1; i <= sheet.getLastRowNum(); i++) {
					XSSFRow row = sheet.getRow(i);
					if (row != null) {

						for (int j = 0; j < signals.length; j++) {
							signals[j] = row.getCell(j);
						}
						PLCDigital digital = new PLCDigital(plcdata);
						for (int j = 0; j < signalsInString.length; j++) {

							if (signals[j] != null) {
								if (signals[j].getCellType() == CellType.NUMERIC) {
									// If the cell is numeric, convert it to a string
									signalsInString[j] = String.valueOf(signals[j].getNumericCellValue());
								} else if (signals[j].getCellType() == CellType.STRING) {
									// If the cell is already a string, directly retrieve it
									signalsInString[j] = signals[j].getStringCellValue();
								} else {
									// Handle other cell types as needed
									signalsInString[j] = ""; // For other types, set an empty string or handle
								}
							} else {
								// Handle null cells as needed
								signalsInString[j] = "";
							}
						}
						for (int j = 0; j < signalNames.length; j++) {

							if (j > signalNames.length - 3) {
								isOutputpin = true;
								digital.setOutput(signalNames[j]);
							} else {
								isOutputpin = false;
								digital.setInput(signalNames[j]);
							}

							if (!signalsInString[j + 4].equals("")) {
								if (signalsInString[j + 4].contains("block")) {
									countingForInnerBlock = 0;
									readBlockSheet(workbook, signalsInString[j + 4]);
									digital.setSignalWithOperators(signalsInBlocks, "BOOL", signalNames[j]);
									signalsInBlocks.clear();

								} else {
									if (j == 0) {
										digital.setSignal(signalsInString[j + 4], "string", signalNames[j],
												isOutputpin);
									} else if (j >= 1 && j <= 3) {
										digital.setSignal(signalsInString[j + 4], "BOOL", signalNames[j], isOutputpin);
									} else if (j >= 4 && j <= 5) {
										digital.setSignal(signalsInString[j + 4], "REAL", signalNames[j], isOutputpin);
									} else {
										digital.setSignal(signalsInString[j + 4], "BOOL", signalNames[j], isOutputpin);
									}

								}

							}
						}
						digital.setAttribute(signalsInString[0], signalsInString[1], signalsInString[3]);
						digital.adddigitalInData();
					}
				}

			} else {
				System.out.println("The workbook contains no sheets.");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void readBlockSheet(XSSFWorkbook workbook, String blockName) {
		ArrayList<String> blockContent = new ArrayList<>();
		signalsInBlocks.add(blockContent);
		XSSFSheet blockSheet = findBlockSheet(workbook, "Blocks");

		if (blockSheet != null) {
			int blockRow = findRowByBlockName(blockSheet, blockName);
			if (blockRow != -1) {
				XSSFRow blockRowData = blockSheet.getRow(blockRow);

				for (int i = 0; i < blockRowData.getLastCellNum(); i++) {
					XSSFCell cell = blockRowData.getCell(i, XSSFRow.MissingCellPolicy.CREATE_NULL_AS_BLANK);
					cell.setCellType(CellType.STRING);
					if (cell.getStringCellValue().contains("block") && (i > 1)) {
						// if call inner block
						countingForInnerBlock++;
						readBlockSheet(workbook, cell.getStringCellValue());

					} else {

						signalsInBlocks.get(countingForInnerBlock).add(cell.getStringCellValue());

					}

				}
			} else {
				System.out.println("Block name not found in the Blocks sheet.");
			}
		} else {
			System.out.println("Blocks sheet not found.");
		}
		if (countingForInnerBlock > 0) {
			countingForInnerBlock--;
		}

	}

	private int findRowByBlockName(XSSFSheet sheet, String blockName) {
		for (int i = 1; i <= sheet.getLastRowNum(); i++) {
			XSSFRow row = sheet.getRow(i);
			if (row != null) {
				XSSFCell cell = row.getCell(0, XSSFRow.MissingCellPolicy.CREATE_NULL_AS_BLANK);
				cell.setCellType(CellType.STRING);
				String currentBlockName = cell.getStringCellValue().trim();
				if (blockName.equalsIgnoreCase(currentBlockName)) {
					return i;
				}
			}
		}
		return -1;
	}

	private XSSFSheet findBlockSheet(XSSFWorkbook workbook, String blockName) {
		for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
			XSSFSheet sheet = workbook.getSheetAt(i);
			if (sheet.getSheetName().equalsIgnoreCase(blockName)) {
				return sheet;
			}
		}
		return null; // Block sheet not found
	}

	public static void main(String[] args) {
		ExcelRead reader = new ExcelRead();
		PlcData plcdata = PlcFactory.eINSTANCE.createPlcData();
		reader.readMotorsExcel(plcdata);
		reader.readSequenceExcel(plcdata);
		reader.readAnalogsExcel(plcdata);
		reader.readDigitalExcel(plcdata);

		save(plcdata, "../inputModel/Output.plc");
		System.out.println("all read all good!");
	}

	public static void save(PlcData data, String path) {
		ResourceSet rs = new ResourceSetImpl();
		String[] fileextensions = new String[] { "plc" };

		for (String extension : fileextensions) {
			rs.getResourceFactoryRegistry().getExtensionToFactoryMap().put(extension, new XMIResourceFactoryImpl());
		}
		URI uri = URI.createFileURI(path);
		Resource plcresource = rs.createResource(uri);

		plcresource.getContents().add(data);
		try {
			plcresource.save(null);
		} catch (IOException e) {
			System.out.println("IO exception while saving....");
			throw new RuntimeException(e);
		}

	}
}