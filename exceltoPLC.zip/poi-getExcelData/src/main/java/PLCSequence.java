import java.util.ArrayList;

import plc.PlcData;
import plc.PlcFactory;
import plc.SeqOperator;
import plc.Sequences;
import plc.Signal;
import plc.TransitionSteps;
import plc.attribute;

public class PLCSequence {
	private PlcData plcdata;
	private Sequences seq = PlcFactory.eINSTANCE.createSequences();
	private int operatorsItemNum = 0;
	private ArrayList<SeqOperator> operators = new ArrayList<SeqOperator>();
	private boolean isOperator = false;
	private SeqOperator operator;

	public PLCSequence(PlcData plcdata) {
		this.plcdata = plcdata;
	}

	public void setAttribute(String name, String description, String libraryUsed) {
		attribute atr = PlcFactory.eINSTANCE.createattribute();
		atr.setDescription(description);
		atr.setName(name);
		seq.setAttribute(atr);

	}

	public void setSignal(String signalName, String type, String belongsTo) {
		boolean namePresent = false;
		int i;

		for (i = 0; i < plcdata.getSignal().size() - 1; i++) {
			if (plcdata.getSignal().get(i).getName().equals(signalName)) {
				namePresent = true;
				break;
			} else
				namePresent = false;
		}

		if (namePresent) {
			seq.getSignal().add(plcdata.getSignal().get(i));
			for (int k = 0; k < seq.getTransitionsteps().size(); k++) {

				if (seq.getTransitionsteps().get(k).getName().toString().equals(belongsTo)) {
					if (isOperator) {
						operator.getSignal().add(plcdata.getSignal().get(i));
					} else {
						seq.getTransitionsteps().get(k).getSignal().add(plcdata.getSignal().get(i));
					}
				}
			}
		} else {
			Signal signal = PlcFactory.eINSTANCE.createSignal();
			signal.setName(signalName);
			signal.setFunctionBlockRef(belongsTo);
			plcdata.getSignal().add(signal);
			seq.getSignal().add(signal);

			for (int k = 0; k < seq.getTransitionsteps().size(); k++) {

				if (seq.getTransitionsteps().get(k).getName().toString().equals(belongsTo)) {
					if (isOperator) {
						operator.getSignal().add(signal);
					} else {
						seq.getTransitionsteps().get(k).getSignal().add(signal);
					}

				}
			}
		}

	}

	public void setTransition(String transitionName) {
		TransitionSteps step = PlcFactory.eINSTANCE.createTransitionSteps();
		step.setName(transitionName);
		seq.getTransitionsteps().add(step);

	}

	public void addSeqInData() {
		plcdata.getSequence().add(seq);

	}

	public void setSignal(String signalName, String type, String belongsTo, SeqOperator currentOperator) {
		boolean namePresent = false;
		int i;

		for (i = 0; i < plcdata.getSignal().size() - 1; i++) {
			if (plcdata.getSignal().get(i).getName().equals(signalName)) {
				namePresent = true;
				break;
			} else
				namePresent = false;
		}

		if (namePresent) {
			seq.getSignal().add(plcdata.getSignal().get(i));
			for (int k = 0; k < seq.getTransitionsteps().size(); k++) {
				if (seq.getTransitionsteps().get(k).getName().toString().equals(belongsTo)) {
					if (isOperator) {

						operators.get(operators.size() - 1).getSignal().add(plcdata.getSignal().get(i));

					} else {
						seq.getTransitionsteps().get(k).getSignal().add(plcdata.getSignal().get(i));
					}
				}
			}
		} else {
			Signal signal = PlcFactory.eINSTANCE.createSignal();
			signal.setName(signalName);
			signal.setFunctionBlockRef(belongsTo);
			plcdata.getSignal().add(signal);
			seq.getSignal().add(signal);

			for (int k = 0; k < seq.getTransitionsteps().size(); k++) {
				if (seq.getTransitionsteps().get(k).getName().toString().equals(belongsTo)) {
					if (isOperator) {

						operators.get(operators.size() - 1).getSignal().add(signal);

					} else {
						seq.getTransitionsteps().get(k).getSignal().add(signal);
					}
				}
			}
		}
	}

	public void setSignalWithOperators(ArrayList<ArrayList<String>> signalsWithOperation, String type,
			String belongsTo) {
		isOperator = true;

		for (ArrayList<String> innerList : signalsWithOperation) {

			SeqOperator currentOperator = PlcFactory.eINSTANCE.createSeqOperator();
			ArrayList<String> signalNames = new ArrayList<>();
			operators.add(currentOperator);
			operatorsItemNum++;

			for (String value : innerList) {
				if (value.equals("AND") || value.equals("OR")) {
					currentOperator.setType(value);
				} else if (!value.contains("block")) {
					signalNames.add(value);
				}
			}

			for (String signalName : signalNames) {
				setSignal(signalName, type, belongsTo, currentOperator);
			}

			if (operatorsItemNum > 1)
				operators.get(operatorsItemNum - 2).getOperator().add(currentOperator);
				seq.getTransitionsteps().get(seq.getTransitionsteps().size() - 1).getOperator().add(currentOperator);
		}

		isOperator = false;
		operators.clear();
		operatorsItemNum = 0;
	}
}