/**
 */
package secondModel;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Seq Signal ID</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link secondModel.SeqSignalID#getIdNbr <em>Id Nbr</em>}</li>
 *   <li>{@link secondModel.SeqSignalID#getSeqoperatorsignals <em>Seqoperatorsignals</em>}</li>
 * </ul>
 *
 * @see secondModel.SecondModelPackage#getSeqSignalID()
 * @model
 * @generated
 */
public interface SeqSignalID extends EObject {
	/**
	 * Returns the value of the '<em><b>Id Nbr</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id Nbr</em>' attribute list.
	 * @see secondModel.SecondModelPackage#getSeqSignalID_IdNbr()
	 * @model upper="100"
	 * @generated
	 */
	EList<String> getIdNbr();

	/**
	 * Returns the value of the '<em><b>Seqoperatorsignals</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Seqoperatorsignals</em>' reference.
	 * @see #setSeqoperatorsignals(Signals)
	 * @see secondModel.SecondModelPackage#getSeqSignalID_Seqoperatorsignals()
	 * @model required="true"
	 * @generated
	 */
	Signals getSeqoperatorsignals();

	/**
	 * Sets the value of the '{@link secondModel.SeqSignalID#getSeqoperatorsignals <em>Seqoperatorsignals</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Seqoperatorsignals</em>' reference.
	 * @see #getSeqoperatorsignals()
	 * @generated
	 */
	void setSeqoperatorsignals(Signals value);

} // SeqSignalID
