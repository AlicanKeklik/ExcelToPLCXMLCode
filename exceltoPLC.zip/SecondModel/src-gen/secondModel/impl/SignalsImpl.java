/**
 */
package secondModel.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import secondModel.SecondModelPackage;
import secondModel.Signals;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Signals</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link secondModel.impl.SignalsImpl#getName <em>Name</em>}</li>
 *   <li>{@link secondModel.impl.SignalsImpl#getSignalType <em>Signal Type</em>}</li>
 *   <li>{@link secondModel.impl.SignalsImpl#getIdNbr <em>Id Nbr</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SignalsImpl extends MinimalEObjectImpl.Container implements Signals {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getSignalType() <em>Signal Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSignalType()
	 * @generated
	 * @ordered
	 */
	protected static final String SİGNAL_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSignalType() <em>Signal Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSignalType()
	 * @generated
	 * @ordered
	 */
	protected String signalType = SİGNAL_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getIdNbr() <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdNbr()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_NBR_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getIdNbr() <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdNbr()
	 * @generated
	 * @ordered
	 */
	protected String ıdNbr = ID_NBR_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SignalsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SecondModelPackage.Literals.SİGNALS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.SİGNALS__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getSignalType() {
		return signalType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSignalType(String newSignalType) {
		String oldSignalType = signalType;
		signalType = newSignalType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.SİGNALS__SİGNAL_TYPE,
					oldSignalType, signalType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getIdNbr() {
		return ıdNbr;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIdNbr(String newIdNbr) {
		String oldIdNbr = ıdNbr;
		ıdNbr = newIdNbr;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.SİGNALS__ID_NBR, oldIdNbr, ıdNbr));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case SecondModelPackage.SİGNALS__NAME:
			return getName();
		case SecondModelPackage.SİGNALS__SİGNAL_TYPE:
			return getSignalType();
		case SecondModelPackage.SİGNALS__ID_NBR:
			return getIdNbr();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case SecondModelPackage.SİGNALS__NAME:
			setName((String) newValue);
			return;
		case SecondModelPackage.SİGNALS__SİGNAL_TYPE:
			setSignalType((String) newValue);
			return;
		case SecondModelPackage.SİGNALS__ID_NBR:
			setIdNbr((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case SecondModelPackage.SİGNALS__NAME:
			setName(NAME_EDEFAULT);
			return;
		case SecondModelPackage.SİGNALS__SİGNAL_TYPE:
			setSignalType(SİGNAL_TYPE_EDEFAULT);
			return;
		case SecondModelPackage.SİGNALS__ID_NBR:
			setIdNbr(ID_NBR_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case SecondModelPackage.SİGNALS__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case SecondModelPackage.SİGNALS__SİGNAL_TYPE:
			return SİGNAL_TYPE_EDEFAULT == null ? signalType != null : !SİGNAL_TYPE_EDEFAULT.equals(signalType);
		case SecondModelPackage.SİGNALS__ID_NBR:
			return ID_NBR_EDEFAULT == null ? ıdNbr != null : !ID_NBR_EDEFAULT.equals(ıdNbr);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", SignalType: ");
		result.append(signalType);
		result.append(", IdNbr: ");
		result.append(ıdNbr);
		result.append(')');
		return result.toString();
	}

} //SignalsImpl
