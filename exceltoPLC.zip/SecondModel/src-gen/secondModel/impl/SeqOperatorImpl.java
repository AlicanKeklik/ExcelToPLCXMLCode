/**
 */
package secondModel.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import secondModel.SecondModelPackage;
import secondModel.SeqOperator;
import secondModel.SeqSignalID;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Seq Operator</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link secondModel.impl.SeqOperatorImpl#getOperatorType <em>Operator Type</em>}</li>
 *   <li>{@link secondModel.impl.SeqOperatorImpl#getIdNbr <em>Id Nbr</em>}</li>
 *   <li>{@link secondModel.impl.SeqOperatorImpl#getSeqoperatorwithinoperator <em>Seqoperatorwithinoperator</em>}</li>
 *   <li>{@link secondModel.impl.SeqOperatorImpl#getSeqsignalid <em>Seqsignalid</em>}</li>
 *   <li>{@link secondModel.impl.SeqOperatorImpl#getConcatOperator <em>Concat Operator</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SeqOperatorImpl extends MinimalEObjectImpl.Container implements SeqOperator {
	/**
	 * The default value of the '{@link #getOperatorType() <em>Operator Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOperatorType()
	 * @generated
	 * @ordered
	 */
	protected static final String OPERATOR_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOperatorType() <em>Operator Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOperatorType()
	 * @generated
	 * @ordered
	 */
	protected String operatorType = OPERATOR_TYPE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getIdNbr() <em>Id Nbr</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdNbr()
	 * @generated
	 * @ordered
	 */
	protected EList<String> ıdNbr;

	/**
	 * The cached value of the '{@link #getSeqoperatorwithinoperator() <em>Seqoperatorwithinoperator</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSeqoperatorwithinoperator()
	 * @generated
	 * @ordered
	 */
	protected EList<SeqOperator> seqoperatorwithinoperator;

	/**
	 * The cached value of the '{@link #getSeqsignalid() <em>Seqsignalid</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSeqsignalid()
	 * @generated
	 * @ordered
	 */
	protected EList<SeqSignalID> seqsignalid;

	/**
	 * The default value of the '{@link #getConcatOperator() <em>Concat Operator</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConcatOperator()
	 * @generated
	 * @ordered
	 */
	protected static final String CONCAT_OPERATOR_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getConcatOperator() <em>Concat Operator</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConcatOperator()
	 * @generated
	 * @ordered
	 */
	protected String concatOperator = CONCAT_OPERATOR_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SeqOperatorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SecondModelPackage.Literals.SEQ_OPERATOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getOperatorType() {
		return operatorType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setOperatorType(String newOperatorType) {
		String oldOperatorType = operatorType;
		operatorType = newOperatorType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.SEQ_OPERATOR__OPERATOR_TYPE,
					oldOperatorType, operatorType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<String> getIdNbr() {
		if (ıdNbr == null) {
			ıdNbr = new EDataTypeUniqueEList<String>(String.class, this, SecondModelPackage.SEQ_OPERATOR__ID_NBR);
		}
		return ıdNbr;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<SeqOperator> getSeqoperatorwithinoperator() {
		if (seqoperatorwithinoperator == null) {
			seqoperatorwithinoperator = new EObjectResolvingEList<SeqOperator>(SeqOperator.class, this,
					SecondModelPackage.SEQ_OPERATOR__SEQOPERATORWİTHİNOPERATOR);
		}
		return seqoperatorwithinoperator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<SeqSignalID> getSeqsignalid() {
		if (seqsignalid == null) {
			seqsignalid = new EObjectContainmentEList<SeqSignalID>(SeqSignalID.class, this,
					SecondModelPackage.SEQ_OPERATOR__SEQSİGNALİD);
		}
		return seqsignalid;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getConcatOperator() {
		return concatOperator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setConcatOperator(String newConcatOperator) {
		String oldConcatOperator = concatOperator;
		concatOperator = newConcatOperator;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.SEQ_OPERATOR__CONCAT_OPERATOR,
					oldConcatOperator, concatOperator));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case SecondModelPackage.SEQ_OPERATOR__SEQSİGNALİD:
			return ((InternalEList<?>) getSeqsignalid()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case SecondModelPackage.SEQ_OPERATOR__OPERATOR_TYPE:
			return getOperatorType();
		case SecondModelPackage.SEQ_OPERATOR__ID_NBR:
			return getIdNbr();
		case SecondModelPackage.SEQ_OPERATOR__SEQOPERATORWİTHİNOPERATOR:
			return getSeqoperatorwithinoperator();
		case SecondModelPackage.SEQ_OPERATOR__SEQSİGNALİD:
			return getSeqsignalid();
		case SecondModelPackage.SEQ_OPERATOR__CONCAT_OPERATOR:
			return getConcatOperator();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case SecondModelPackage.SEQ_OPERATOR__OPERATOR_TYPE:
			setOperatorType((String) newValue);
			return;
		case SecondModelPackage.SEQ_OPERATOR__ID_NBR:
			getIdNbr().clear();
			getIdNbr().addAll((Collection<? extends String>) newValue);
			return;
		case SecondModelPackage.SEQ_OPERATOR__SEQOPERATORWİTHİNOPERATOR:
			getSeqoperatorwithinoperator().clear();
			getSeqoperatorwithinoperator().addAll((Collection<? extends SeqOperator>) newValue);
			return;
		case SecondModelPackage.SEQ_OPERATOR__SEQSİGNALİD:
			getSeqsignalid().clear();
			getSeqsignalid().addAll((Collection<? extends SeqSignalID>) newValue);
			return;
		case SecondModelPackage.SEQ_OPERATOR__CONCAT_OPERATOR:
			setConcatOperator((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case SecondModelPackage.SEQ_OPERATOR__OPERATOR_TYPE:
			setOperatorType(OPERATOR_TYPE_EDEFAULT);
			return;
		case SecondModelPackage.SEQ_OPERATOR__ID_NBR:
			getIdNbr().clear();
			return;
		case SecondModelPackage.SEQ_OPERATOR__SEQOPERATORWİTHİNOPERATOR:
			getSeqoperatorwithinoperator().clear();
			return;
		case SecondModelPackage.SEQ_OPERATOR__SEQSİGNALİD:
			getSeqsignalid().clear();
			return;
		case SecondModelPackage.SEQ_OPERATOR__CONCAT_OPERATOR:
			setConcatOperator(CONCAT_OPERATOR_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case SecondModelPackage.SEQ_OPERATOR__OPERATOR_TYPE:
			return OPERATOR_TYPE_EDEFAULT == null ? operatorType != null : !OPERATOR_TYPE_EDEFAULT.equals(operatorType);
		case SecondModelPackage.SEQ_OPERATOR__ID_NBR:
			return ıdNbr != null && !ıdNbr.isEmpty();
		case SecondModelPackage.SEQ_OPERATOR__SEQOPERATORWİTHİNOPERATOR:
			return seqoperatorwithinoperator != null && !seqoperatorwithinoperator.isEmpty();
		case SecondModelPackage.SEQ_OPERATOR__SEQSİGNALİD:
			return seqsignalid != null && !seqsignalid.isEmpty();
		case SecondModelPackage.SEQ_OPERATOR__CONCAT_OPERATOR:
			return CONCAT_OPERATOR_EDEFAULT == null ? concatOperator != null
					: !CONCAT_OPERATOR_EDEFAULT.equals(concatOperator);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (OperatorType: ");
		result.append(operatorType);
		result.append(", IdNbr: ");
		result.append(ıdNbr);
		result.append(", concatOperator: ");
		result.append(concatOperator);
		result.append(')');
		return result.toString();
	}

} //SeqOperatorImpl
