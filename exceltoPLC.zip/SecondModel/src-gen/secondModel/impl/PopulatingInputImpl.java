/**
 */
package secondModel.impl;

import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;
import secondModel.Operator;
import secondModel.PopulatingInput;
import secondModel.SecondModelPackage;
import secondModel.Signals;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Populating Input</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link secondModel.impl.PopulatingInputImpl#getSignalName <em>Signal Name</em>}</li>
 *   <li>{@link secondModel.impl.PopulatingInputImpl#getInputName <em>Input Name</em>}</li>
 *   <li>{@link secondModel.impl.PopulatingInputImpl#getİnputsignals <em>İnputsignals</em>}</li>
 *   <li>{@link secondModel.impl.PopulatingInputImpl#getIdNbr <em>Id Nbr</em>}</li>
 *   <li>{@link secondModel.impl.PopulatingInputImpl#getOperator <em>Operator</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PopulatingInputImpl extends MinimalEObjectImpl.Container implements PopulatingInput {
	/**
	 * The default value of the '{@link #getSignalName() <em>Signal Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSignalName()
	 * @generated
	 * @ordered
	 */
	protected static final String SİGNAL_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSignalName() <em>Signal Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSignalName()
	 * @generated
	 * @ordered
	 */
	protected String signalName = SİGNAL_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getInputName() <em>Input Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInputName()
	 * @generated
	 * @ordered
	 */
	protected static final String INPUT_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getInputName() <em>Input Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInputName()
	 * @generated
	 * @ordered
	 */
	protected String ınputName = INPUT_NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getİnputsignals() <em>İnputsignals</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getİnputsignals()
	 * @generated
	 * @ordered
	 */
	protected EList<Signals> inputsignals;

	/**
	 * The default value of the '{@link #getIdNbr() <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdNbr()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_NBR_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getIdNbr() <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdNbr()
	 * @generated
	 * @ordered
	 */
	protected String ıdNbr = ID_NBR_EDEFAULT;

	/**
	 * The cached value of the '{@link #getOperator() <em>Operator</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOperator()
	 * @generated
	 * @ordered
	 */
	protected EList<Operator> operator;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PopulatingInputImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SecondModelPackage.Literals.POPULATİNG_INPUT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getSignalName() {
		return signalName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSignalName(String newSignalName) {
		String oldSignalName = signalName;
		signalName = newSignalName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.POPULATİNG_INPUT__SİGNAL_NAME,
					oldSignalName, signalName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getInputName() {
		return ınputName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInputName(String newInputName) {
		String oldInputName = ınputName;
		ınputName = newInputName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.POPULATİNG_INPUT__INPUT_NAME,
					oldInputName, ınputName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Signals> getİnputsignals() {
		if (inputsignals == null) {
			inputsignals = new EObjectResolvingEList<Signals>(Signals.class, this,
					SecondModelPackage.POPULATİNG_INPUT__İNPUTSİGNALS);
		}
		return inputsignals;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getIdNbr() {
		return ıdNbr;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIdNbr(String newIdNbr) {
		String oldIdNbr = ıdNbr;
		ıdNbr = newIdNbr;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.POPULATİNG_INPUT__ID_NBR, oldIdNbr,
					ıdNbr));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Operator> getOperator() {
		if (operator == null) {
			operator = new EObjectContainmentEList<Operator>(Operator.class, this,
					SecondModelPackage.POPULATİNG_INPUT__OPERATOR);
		}
		return operator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case SecondModelPackage.POPULATİNG_INPUT__OPERATOR:
			return ((InternalEList<?>) getOperator()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case SecondModelPackage.POPULATİNG_INPUT__SİGNAL_NAME:
			return getSignalName();
		case SecondModelPackage.POPULATİNG_INPUT__INPUT_NAME:
			return getInputName();
		case SecondModelPackage.POPULATİNG_INPUT__İNPUTSİGNALS:
			return getİnputsignals();
		case SecondModelPackage.POPULATİNG_INPUT__ID_NBR:
			return getIdNbr();
		case SecondModelPackage.POPULATİNG_INPUT__OPERATOR:
			return getOperator();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case SecondModelPackage.POPULATİNG_INPUT__SİGNAL_NAME:
			setSignalName((String) newValue);
			return;
		case SecondModelPackage.POPULATİNG_INPUT__INPUT_NAME:
			setInputName((String) newValue);
			return;
		case SecondModelPackage.POPULATİNG_INPUT__İNPUTSİGNALS:
			getİnputsignals().clear();
			getİnputsignals().addAll((Collection<? extends Signals>) newValue);
			return;
		case SecondModelPackage.POPULATİNG_INPUT__ID_NBR:
			setIdNbr((String) newValue);
			return;
		case SecondModelPackage.POPULATİNG_INPUT__OPERATOR:
			getOperator().clear();
			getOperator().addAll((Collection<? extends Operator>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case SecondModelPackage.POPULATİNG_INPUT__SİGNAL_NAME:
			setSignalName(SİGNAL_NAME_EDEFAULT);
			return;
		case SecondModelPackage.POPULATİNG_INPUT__INPUT_NAME:
			setInputName(INPUT_NAME_EDEFAULT);
			return;
		case SecondModelPackage.POPULATİNG_INPUT__İNPUTSİGNALS:
			getİnputsignals().clear();
			return;
		case SecondModelPackage.POPULATİNG_INPUT__ID_NBR:
			setIdNbr(ID_NBR_EDEFAULT);
			return;
		case SecondModelPackage.POPULATİNG_INPUT__OPERATOR:
			getOperator().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case SecondModelPackage.POPULATİNG_INPUT__SİGNAL_NAME:
			return SİGNAL_NAME_EDEFAULT == null ? signalName != null : !SİGNAL_NAME_EDEFAULT.equals(signalName);
		case SecondModelPackage.POPULATİNG_INPUT__INPUT_NAME:
			return INPUT_NAME_EDEFAULT == null ? ınputName != null : !INPUT_NAME_EDEFAULT.equals(ınputName);
		case SecondModelPackage.POPULATİNG_INPUT__İNPUTSİGNALS:
			return inputsignals != null && !inputsignals.isEmpty();
		case SecondModelPackage.POPULATİNG_INPUT__ID_NBR:
			return ID_NBR_EDEFAULT == null ? ıdNbr != null : !ID_NBR_EDEFAULT.equals(ıdNbr);
		case SecondModelPackage.POPULATİNG_INPUT__OPERATOR:
			return operator != null && !operator.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (SignalName: ");
		result.append(signalName);
		result.append(", InputName: ");
		result.append(ınputName);
		result.append(", IdNbr: ");
		result.append(ıdNbr);
		result.append(')');
		return result.toString();
	}

} //PopulatingInputImpl
