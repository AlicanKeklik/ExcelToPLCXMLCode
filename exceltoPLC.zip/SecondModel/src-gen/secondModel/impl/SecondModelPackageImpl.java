/**
 */
package secondModel.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import secondModel.AnalogBlock;
import secondModel.DigitalBlock;
import secondModel.LocalVariables;
import secondModel.MotorBlock;
import secondModel.Operator;
import secondModel.PopulatingInput;
import secondModel.PopulatingOutput;
import secondModel.PopulatingSteps;
import secondModel.SecondModelFactory;
import secondModel.SecondModelPackage;
import secondModel.SeqOperator;
import secondModel.SeqSignalID;
import secondModel.SequenceBlock;
import secondModel.SignalId;
import secondModel.Signals;
import secondModel.SignalsInput;
import secondModel.SignalsOutput;
import secondModel.TopDataClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class SecondModelPackageImpl extends EPackageImpl implements SecondModelPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass topDataClassEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass localVariablesEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass motorBlockEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass signalsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass signalsInputEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass signalsOutputEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass populatingInputEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass operatorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass signalIdEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sequenceBlockEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass populatingStepsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass seqOperatorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass seqSignalIDEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass analogBlockEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass populatingOutputEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass digitalBlockEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see secondModel.SecondModelPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private SecondModelPackageImpl() {
		super(eNS_URI, SecondModelFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link SecondModelPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static SecondModelPackage init() {
		if (isInited)
			return (SecondModelPackage) EPackage.Registry.INSTANCE.getEPackage(SecondModelPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredSecondModelPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		SecondModelPackageImpl theSecondModelPackage = registeredSecondModelPackage instanceof SecondModelPackageImpl
				? (SecondModelPackageImpl) registeredSecondModelPackage
				: new SecondModelPackageImpl();

		isInited = true;

		// Create package meta-data objects
		theSecondModelPackage.createPackageContents();

		// Initialize created meta-data
		theSecondModelPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theSecondModelPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(SecondModelPackage.eNS_URI, theSecondModelPackage);
		return theSecondModelPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTopDataClass() {
		return topDataClassEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getTopDataClass_HeaderText() {
		return (EAttribute) topDataClassEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getTopDataClass_Localvariables() {
		return (EReference) topDataClassEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getTopDataClass_Motorblock() {
		return (EReference) topDataClassEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getTopDataClass_Signals() {
		return (EReference) topDataClassEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getTopDataClass_Sequenceblock() {
		return (EReference) topDataClassEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getTopDataClass_Analogblock() {
		return (EReference) topDataClassEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getTopDataClass_Digitalblock() {
		return (EReference) topDataClassEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getLocalVariables() {
		return localVariablesEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getLocalVariables_Name() {
		return (EAttribute) localVariablesEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getLocalVariables_HardwareReference() {
		return (EAttribute) localVariablesEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getLocalVariables_Signals() {
		return (EReference) localVariablesEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getLocalVariables_Localvariablesforanalog() {
		return (EReference) localVariablesEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getLocalVariables_Localvariablesfordigital() {
		return (EReference) localVariablesEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getLocalVariables_IdNbr() {
		return (EAttribute) localVariablesEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMotorBlock() {
		return motorBlockEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getMotorBlock_Name() {
		return (EAttribute) motorBlockEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getMotorBlock_Description() {
		return (EAttribute) motorBlockEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getMotorBlock_SignalsIn() {
		return (EAttribute) motorBlockEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getMotorBlock_Signals() {
		return (EReference) motorBlockEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getMotorBlock_Type() {
		return (EAttribute) motorBlockEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getMotorBlock_Localvariables() {
		return (EReference) motorBlockEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getMotorBlock_Signalsinput() {
		return (EReference) motorBlockEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getMotorBlock_Signalsoutput() {
		return (EReference) motorBlockEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getMotorBlock_IdNbr() {
		return (EAttribute) motorBlockEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getMotorBlock_Populatinginput() {
		return (EReference) motorBlockEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getMotorBlock_Populatingoutput() {
		return (EReference) motorBlockEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSignals() {
		return signalsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSignals_Name() {
		return (EAttribute) signalsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSignals_SignalType() {
		return (EAttribute) signalsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSignals_IdNbr() {
		return (EAttribute) signalsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSignalsInput() {
		return signalsInputEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSignalsInput_Name() {
		return (EAttribute) signalsInputEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSignalsInput_IdNbr() {
		return (EAttribute) signalsInputEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSignalsOutput() {
		return signalsOutputEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSignalsOutput_Name() {
		return (EAttribute) signalsOutputEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSignalsOutput_IdNbr() {
		return (EAttribute) signalsOutputEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getPopulatingInput() {
		return populatingInputEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPopulatingInput_SignalName() {
		return (EAttribute) populatingInputEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPopulatingInput_InputName() {
		return (EAttribute) populatingInputEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getPopulatingInput_İnputsignals() {
		return (EReference) populatingInputEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPopulatingInput_IdNbr() {
		return (EAttribute) populatingInputEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getPopulatingInput_Operator() {
		return (EReference) populatingInputEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getOperator() {
		return operatorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getOperator_OperatorType() {
		return (EAttribute) operatorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getOperator_IdNbr() {
		return (EAttribute) operatorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getOperator_Signalid() {
		return (EReference) operatorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getOperator_Operatorwithinoperator() {
		return (EReference) operatorEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSignalId() {
		return signalIdEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSignalId_IdNbr() {
		return (EAttribute) signalIdEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getSignalId_Operatorsignals() {
		return (EReference) signalIdEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSequenceBlock() {
		return sequenceBlockEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSequenceBlock_Name() {
		return (EAttribute) sequenceBlockEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSequenceBlock_Description() {
		return (EAttribute) sequenceBlockEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getSequenceBlock_Populatingsteps() {
		return (EReference) sequenceBlockEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSequenceBlock_StepName() {
		return (EAttribute) sequenceBlockEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSequenceBlock_IdNbr() {
		return (EAttribute) sequenceBlockEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getPopulatingSteps() {
		return populatingStepsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getPopulatingSteps_Signals() {
		return (EReference) populatingStepsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getPopulatingSteps_Seqoperator() {
		return (EReference) populatingStepsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPopulatingSteps_SignalName() {
		return (EAttribute) populatingStepsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPopulatingSteps_InputName() {
		return (EAttribute) populatingStepsEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPopulatingSteps_IdNbr() {
		return (EAttribute) populatingStepsEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPopulatingSteps_NextIdNbr() {
		return (EAttribute) populatingStepsEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPopulatingSteps_TransitionIdNbr() {
		return (EAttribute) populatingStepsEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPopulatingSteps_LastTransitionIdNbr() {
		return (EAttribute) populatingStepsEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPopulatingSteps_LastTransitionStepNbr() {
		return (EAttribute) populatingStepsEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSeqOperator() {
		return seqOperatorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSeqOperator_OperatorType() {
		return (EAttribute) seqOperatorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSeqOperator_IdNbr() {
		return (EAttribute) seqOperatorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getSeqOperator_Seqoperatorwithinoperator() {
		return (EReference) seqOperatorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getSeqOperator_Seqsignalid() {
		return (EReference) seqOperatorEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSeqOperator_ConcatOperator() {
		return (EAttribute) seqOperatorEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSeqSignalID() {
		return seqSignalIDEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSeqSignalID_IdNbr() {
		return (EAttribute) seqSignalIDEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getSeqSignalID_Seqoperatorsignals() {
		return (EReference) seqSignalIDEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAnalogBlock() {
		return analogBlockEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getAnalogBlock_Name() {
		return (EAttribute) analogBlockEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getAnalogBlock_Description() {
		return (EAttribute) analogBlockEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAnalogBlock_Analogtosignals() {
		return (EReference) analogBlockEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAnalogBlock_Populatinginput() {
		return (EReference) analogBlockEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAnalogBlock_Populatingoutput() {
		return (EReference) analogBlockEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getAnalogBlock_BlockId() {
		return (EAttribute) analogBlockEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getAnalogBlock_SignalsIn() {
		return (EAttribute) analogBlockEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getPopulatingOutput() {
		return populatingOutputEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPopulatingOutput_SignalName() {
		return (EAttribute) populatingOutputEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPopulatingOutput_InputName() {
		return (EAttribute) populatingOutputEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getPopulatingOutput_İnputsignals() {
		return (EReference) populatingOutputEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPopulatingOutput_IdNbr() {
		return (EAttribute) populatingOutputEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDigitalBlock() {
		return digitalBlockEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getDigitalBlock_Name() {
		return (EAttribute) digitalBlockEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getDigitalBlock_Description() {
		return (EAttribute) digitalBlockEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getDigitalBlock_Digitaltosignals() {
		return (EReference) digitalBlockEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getDigitalBlock_Populatinginput() {
		return (EReference) digitalBlockEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getDigitalBlock_Populatingoutput() {
		return (EReference) digitalBlockEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getDigitalBlock_BlockId() {
		return (EAttribute) digitalBlockEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SecondModelFactory getSecondModelFactory() {
		return (SecondModelFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		topDataClassEClass = createEClass(TOP_DATA_CLASS);
		createEAttribute(topDataClassEClass, TOP_DATA_CLASS__HEADER_TEXT);
		createEReference(topDataClassEClass, TOP_DATA_CLASS__LOCALVARİABLES);
		createEReference(topDataClassEClass, TOP_DATA_CLASS__MOTORBLOCK);
		createEReference(topDataClassEClass, TOP_DATA_CLASS__SİGNALS);
		createEReference(topDataClassEClass, TOP_DATA_CLASS__SEQUENCEBLOCK);
		createEReference(topDataClassEClass, TOP_DATA_CLASS__ANALOGBLOCK);
		createEReference(topDataClassEClass, TOP_DATA_CLASS__DİGİTALBLOCK);

		localVariablesEClass = createEClass(LOCAL_VARİABLES);
		createEAttribute(localVariablesEClass, LOCAL_VARİABLES__NAME);
		createEAttribute(localVariablesEClass, LOCAL_VARİABLES__ID_NBR);
		createEAttribute(localVariablesEClass, LOCAL_VARİABLES__HARDWARE_REFERENCE);
		createEReference(localVariablesEClass, LOCAL_VARİABLES__SİGNALS);
		createEReference(localVariablesEClass, LOCAL_VARİABLES__LOCALVARİABLESFORANALOG);
		createEReference(localVariablesEClass, LOCAL_VARİABLES__LOCALVARİABLESFORDİGİTAL);

		motorBlockEClass = createEClass(MOTOR_BLOCK);
		createEAttribute(motorBlockEClass, MOTOR_BLOCK__NAME);
		createEAttribute(motorBlockEClass, MOTOR_BLOCK__DESCRİPTİON);
		createEAttribute(motorBlockEClass, MOTOR_BLOCK__SİGNALS_IN);
		createEReference(motorBlockEClass, MOTOR_BLOCK__SİGNALS);
		createEAttribute(motorBlockEClass, MOTOR_BLOCK__TYPE);
		createEReference(motorBlockEClass, MOTOR_BLOCK__LOCALVARİABLES);
		createEReference(motorBlockEClass, MOTOR_BLOCK__SİGNALSİNPUT);
		createEReference(motorBlockEClass, MOTOR_BLOCK__SİGNALSOUTPUT);
		createEAttribute(motorBlockEClass, MOTOR_BLOCK__ID_NBR);
		createEReference(motorBlockEClass, MOTOR_BLOCK__POPULATİNGİNPUT);
		createEReference(motorBlockEClass, MOTOR_BLOCK__POPULATİNGOUTPUT);

		signalsEClass = createEClass(SİGNALS);
		createEAttribute(signalsEClass, SİGNALS__NAME);
		createEAttribute(signalsEClass, SİGNALS__SİGNAL_TYPE);
		createEAttribute(signalsEClass, SİGNALS__ID_NBR);

		signalsInputEClass = createEClass(SİGNALS_INPUT);
		createEAttribute(signalsInputEClass, SİGNALS_INPUT__NAME);
		createEAttribute(signalsInputEClass, SİGNALS_INPUT__ID_NBR);

		signalsOutputEClass = createEClass(SİGNALS_OUTPUT);
		createEAttribute(signalsOutputEClass, SİGNALS_OUTPUT__NAME);
		createEAttribute(signalsOutputEClass, SİGNALS_OUTPUT__ID_NBR);

		populatingInputEClass = createEClass(POPULATİNG_INPUT);
		createEAttribute(populatingInputEClass, POPULATİNG_INPUT__SİGNAL_NAME);
		createEAttribute(populatingInputEClass, POPULATİNG_INPUT__INPUT_NAME);
		createEReference(populatingInputEClass, POPULATİNG_INPUT__İNPUTSİGNALS);
		createEAttribute(populatingInputEClass, POPULATİNG_INPUT__ID_NBR);
		createEReference(populatingInputEClass, POPULATİNG_INPUT__OPERATOR);

		operatorEClass = createEClass(OPERATOR);
		createEAttribute(operatorEClass, OPERATOR__OPERATOR_TYPE);
		createEAttribute(operatorEClass, OPERATOR__ID_NBR);
		createEReference(operatorEClass, OPERATOR__SİGNALİD);
		createEReference(operatorEClass, OPERATOR__OPERATORWİTHİNOPERATOR);

		signalIdEClass = createEClass(SİGNAL_ID);
		createEAttribute(signalIdEClass, SİGNAL_ID__ID_NBR);
		createEReference(signalIdEClass, SİGNAL_ID__OPERATORSİGNALS);

		sequenceBlockEClass = createEClass(SEQUENCE_BLOCK);
		createEAttribute(sequenceBlockEClass, SEQUENCE_BLOCK__NAME);
		createEAttribute(sequenceBlockEClass, SEQUENCE_BLOCK__DESCRİPTİON);
		createEReference(sequenceBlockEClass, SEQUENCE_BLOCK__POPULATİNGSTEPS);
		createEAttribute(sequenceBlockEClass, SEQUENCE_BLOCK__STEP_NAME);
		createEAttribute(sequenceBlockEClass, SEQUENCE_BLOCK__ID_NBR);

		populatingStepsEClass = createEClass(POPULATİNG_STEPS);
		createEReference(populatingStepsEClass, POPULATİNG_STEPS__SİGNALS);
		createEReference(populatingStepsEClass, POPULATİNG_STEPS__SEQOPERATOR);
		createEAttribute(populatingStepsEClass, POPULATİNG_STEPS__SİGNAL_NAME);
		createEAttribute(populatingStepsEClass, POPULATİNG_STEPS__INPUT_NAME);
		createEAttribute(populatingStepsEClass, POPULATİNG_STEPS__ID_NBR);
		createEAttribute(populatingStepsEClass, POPULATİNG_STEPS__NEXT_ID_NBR);
		createEAttribute(populatingStepsEClass, POPULATİNG_STEPS__TRANSİTİON_ID_NBR);
		createEAttribute(populatingStepsEClass, POPULATİNG_STEPS__LAST_TRANSİTİON_ID_NBR);
		createEAttribute(populatingStepsEClass, POPULATİNG_STEPS__LAST_TRANSİTİON_STEP_NBR);

		seqOperatorEClass = createEClass(SEQ_OPERATOR);
		createEAttribute(seqOperatorEClass, SEQ_OPERATOR__OPERATOR_TYPE);
		createEAttribute(seqOperatorEClass, SEQ_OPERATOR__ID_NBR);
		createEReference(seqOperatorEClass, SEQ_OPERATOR__SEQOPERATORWİTHİNOPERATOR);
		createEReference(seqOperatorEClass, SEQ_OPERATOR__SEQSİGNALİD);
		createEAttribute(seqOperatorEClass, SEQ_OPERATOR__CONCAT_OPERATOR);

		seqSignalIDEClass = createEClass(SEQ_SİGNAL_ID);
		createEAttribute(seqSignalIDEClass, SEQ_SİGNAL_ID__ID_NBR);
		createEReference(seqSignalIDEClass, SEQ_SİGNAL_ID__SEQOPERATORSİGNALS);

		analogBlockEClass = createEClass(ANALOG_BLOCK);
		createEAttribute(analogBlockEClass, ANALOG_BLOCK__NAME);
		createEAttribute(analogBlockEClass, ANALOG_BLOCK__DESCRİPTİON);
		createEReference(analogBlockEClass, ANALOG_BLOCK__ANALOGTOSİGNALS);
		createEReference(analogBlockEClass, ANALOG_BLOCK__POPULATİNGİNPUT);
		createEReference(analogBlockEClass, ANALOG_BLOCK__POPULATİNGOUTPUT);
		createEAttribute(analogBlockEClass, ANALOG_BLOCK__BLOCK_ID);
		createEAttribute(analogBlockEClass, ANALOG_BLOCK__SİGNALS_IN);

		populatingOutputEClass = createEClass(POPULATİNG_OUTPUT);
		createEAttribute(populatingOutputEClass, POPULATİNG_OUTPUT__SİGNAL_NAME);
		createEAttribute(populatingOutputEClass, POPULATİNG_OUTPUT__INPUT_NAME);
		createEReference(populatingOutputEClass, POPULATİNG_OUTPUT__İNPUTSİGNALS);
		createEAttribute(populatingOutputEClass, POPULATİNG_OUTPUT__ID_NBR);

		digitalBlockEClass = createEClass(DİGİTAL_BLOCK);
		createEAttribute(digitalBlockEClass, DİGİTAL_BLOCK__NAME);
		createEAttribute(digitalBlockEClass, DİGİTAL_BLOCK__DESCRİPTİON);
		createEReference(digitalBlockEClass, DİGİTAL_BLOCK__DİGİTALTOSİGNALS);
		createEReference(digitalBlockEClass, DİGİTAL_BLOCK__POPULATİNGİNPUT);
		createEReference(digitalBlockEClass, DİGİTAL_BLOCK__POPULATİNGOUTPUT);
		createEAttribute(digitalBlockEClass, DİGİTAL_BLOCK__BLOCK_ID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes

		// Initialize classes, features, and operations; add parameters
		initEClass(topDataClassEClass, TopDataClass.class, "TopDataClass", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTopDataClass_HeaderText(), ecorePackage.getEString(), "HeaderText", null, 0, 1,
				TopDataClass.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getTopDataClass_Localvariables(), this.getLocalVariables(), null, "localvariables", null, 0, -1,
				TopDataClass.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTopDataClass_Motorblock(), this.getMotorBlock(), null, "motorblock", null, 0, -1,
				TopDataClass.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTopDataClass_Signals(), this.getSignals(), null, "signals", null, 0, -1, TopDataClass.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTopDataClass_Sequenceblock(), this.getSequenceBlock(), null, "sequenceblock", null, 0, -1,
				TopDataClass.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTopDataClass_Analogblock(), this.getAnalogBlock(), null, "analogblock", null, 0, -1,
				TopDataClass.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTopDataClass_Digitalblock(), this.getDigitalBlock(), null, "digitalblock", null, 0, -1,
				TopDataClass.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(localVariablesEClass, LocalVariables.class, "LocalVariables", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getLocalVariables_Name(), ecorePackage.getEString(), "Name", null, 0, 1, LocalVariables.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getLocalVariables_IdNbr(), ecorePackage.getEInt(), "IdNbr", null, 0, 1, LocalVariables.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getLocalVariables_HardwareReference(), ecorePackage.getEString(), "hardwareReference", null, 0,
				1, LocalVariables.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getLocalVariables_Signals(), this.getSignals(), null, "signals", null, 0, -1,
				LocalVariables.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getLocalVariables_Localvariablesforanalog(), this.getAnalogBlock(), null,
				"localvariablesforanalog", null, 1, 1, LocalVariables.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getLocalVariables_Localvariablesfordigital(), this.getDigitalBlock(), null,
				"localvariablesfordigital", null, 1, 1, LocalVariables.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(motorBlockEClass, MotorBlock.class, "MotorBlock", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMotorBlock_Name(), ecorePackage.getEString(), "Name", null, 0, 1, MotorBlock.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMotorBlock_Description(), ecorePackage.getEString(), "Description", null, 0, 1,
				MotorBlock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getMotorBlock_SignalsIn(), ecorePackage.getEString(), "SignalsIn", null, 0, -1, MotorBlock.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMotorBlock_Signals(), this.getSignals(), null, "signals", null, 0, -1, MotorBlock.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMotorBlock_Type(), ecorePackage.getEString(), "Type", null, 0, 1, MotorBlock.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMotorBlock_Localvariables(), this.getLocalVariables(), null, "localvariables", null, 1, 1,
				MotorBlock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMotorBlock_Signalsinput(), this.getSignalsInput(), null, "signalsinput", null, 0, -1,
				MotorBlock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMotorBlock_Signalsoutput(), this.getSignalsOutput(), null, "signalsoutput", null, 0, -1,
				MotorBlock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMotorBlock_IdNbr(), ecorePackage.getEString(), "IdNbr", null, 0, 1, MotorBlock.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMotorBlock_Populatinginput(), this.getPopulatingInput(), null, "populatinginput", null, 0, -1,
				MotorBlock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMotorBlock_Populatingoutput(), this.getPopulatingOutput(), null, "populatingoutput", null, 0,
				-1, MotorBlock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(signalsEClass, Signals.class, "Signals", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSignals_Name(), ecorePackage.getEString(), "name", null, 0, 1, Signals.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSignals_SignalType(), ecorePackage.getEString(), "SignalType", null, 0, 1, Signals.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSignals_IdNbr(), ecorePackage.getEString(), "IdNbr", null, 0, 1, Signals.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(signalsInputEClass, SignalsInput.class, "SignalsInput", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSignalsInput_Name(), ecorePackage.getEString(), "Name", null, 0, 1, SignalsInput.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSignalsInput_IdNbr(), ecorePackage.getEInt(), "IdNbr", null, 0, 1, SignalsInput.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(signalsOutputEClass, SignalsOutput.class, "SignalsOutput", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSignalsOutput_Name(), ecorePackage.getEString(), "Name", null, 0, 1, SignalsOutput.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSignalsOutput_IdNbr(), ecorePackage.getEInt(), "IdNbr", null, 0, 1, SignalsOutput.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(populatingInputEClass, PopulatingInput.class, "PopulatingInput", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPopulatingInput_SignalName(), ecorePackage.getEString(), "SignalName", null, 0, 1,
				PopulatingInput.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getPopulatingInput_InputName(), ecorePackage.getEString(), "InputName", null, 0, 1,
				PopulatingInput.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getPopulatingInput_İnputsignals(), this.getSignals(), null, "inputsignals", null, 0, -1,
				PopulatingInput.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPopulatingInput_IdNbr(), ecorePackage.getEString(), "IdNbr", null, 0, 1,
				PopulatingInput.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getPopulatingInput_Operator(), this.getOperator(), null, "operator", null, 0, -1,
				PopulatingInput.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(operatorEClass, Operator.class, "Operator", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getOperator_OperatorType(), ecorePackage.getEString(), "OperatorType", null, 0, 1,
				Operator.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getOperator_IdNbr(), ecorePackage.getEString(), "IdNbr", null, 0, 100, Operator.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getOperator_Signalid(), this.getSignalId(), null, "signalid", null, 0, -1, Operator.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getOperator_Operatorwithinoperator(), this.getOperator(), null, "operatorwithinoperator", null,
				0, -1, Operator.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(signalIdEClass, SignalId.class, "SignalId", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSignalId_IdNbr(), ecorePackage.getEString(), "IdNbr", null, 0, 100, SignalId.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSignalId_Operatorsignals(), this.getSignals(), null, "operatorsignals", null, 1, 1,
				SignalId.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(sequenceBlockEClass, SequenceBlock.class, "SequenceBlock", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSequenceBlock_Name(), ecorePackage.getEString(), "Name", null, 0, 1, SequenceBlock.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSequenceBlock_Description(), ecorePackage.getEString(), "Description", null, 0, 1,
				SequenceBlock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getSequenceBlock_Populatingsteps(), this.getPopulatingSteps(), null, "populatingsteps", null, 0,
				-1, SequenceBlock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSequenceBlock_StepName(), ecorePackage.getEString(), "stepName", null, 0, 100,
				SequenceBlock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getSequenceBlock_IdNbr(), ecorePackage.getEString(), "IdNbr", null, 0, 1, SequenceBlock.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(populatingStepsEClass, PopulatingSteps.class, "PopulatingSteps", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPopulatingSteps_Signals(), this.getSignals(), null, "signals", null, 0, -1,
				PopulatingSteps.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPopulatingSteps_Seqoperator(), this.getSeqOperator(), null, "seqoperator", null, 0, -1,
				PopulatingSteps.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPopulatingSteps_SignalName(), ecorePackage.getEString(), "SignalName", null, 0, 1,
				PopulatingSteps.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getPopulatingSteps_InputName(), ecorePackage.getEString(), "InputName", null, 0, 1,
				PopulatingSteps.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getPopulatingSteps_IdNbr(), ecorePackage.getEString(), "IdNbr", null, 0, 1,
				PopulatingSteps.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getPopulatingSteps_NextIdNbr(), ecorePackage.getEString(), "NextIdNbr", null, 0, 1,
				PopulatingSteps.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getPopulatingSteps_TransitionIdNbr(), ecorePackage.getEString(), "TransitionIdNbr", null, 0, 1,
				PopulatingSteps.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getPopulatingSteps_LastTransitionIdNbr(), ecorePackage.getEString(), "LastTransitionIdNbr", null,
				0, 1, PopulatingSteps.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPopulatingSteps_LastTransitionStepNbr(), ecorePackage.getEString(), "LastTransitionStepNbr",
				null, 0, 1, PopulatingSteps.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(seqOperatorEClass, SeqOperator.class, "SeqOperator", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSeqOperator_OperatorType(), ecorePackage.getEString(), "OperatorType", null, 0, 1,
				SeqOperator.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getSeqOperator_IdNbr(), ecorePackage.getEString(), "IdNbr", null, 0, 100, SeqOperator.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSeqOperator_Seqoperatorwithinoperator(), this.getSeqOperator(), null,
				"seqoperatorwithinoperator", null, 0, -1, SeqOperator.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSeqOperator_Seqsignalid(), this.getSeqSignalID(), null, "seqsignalid", null, 0, -1,
				SeqOperator.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSeqOperator_ConcatOperator(), ecorePackage.getEString(), "concatOperator", null, 0, 1,
				SeqOperator.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(seqSignalIDEClass, SeqSignalID.class, "SeqSignalID", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSeqSignalID_IdNbr(), ecorePackage.getEString(), "IdNbr", null, 0, 100, SeqSignalID.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSeqSignalID_Seqoperatorsignals(), this.getSignals(), null, "seqoperatorsignals", null, 1, 1,
				SeqSignalID.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(analogBlockEClass, AnalogBlock.class, "AnalogBlock", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAnalogBlock_Name(), ecorePackage.getEString(), "Name", null, 0, 1, AnalogBlock.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAnalogBlock_Description(), ecorePackage.getEString(), "Description", null, 0, 1,
				AnalogBlock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getAnalogBlock_Analogtosignals(), this.getSignals(), null, "analogtosignals", null, 0, -1,
				AnalogBlock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAnalogBlock_Populatinginput(), this.getPopulatingInput(), null, "populatinginput", null, 0,
				-1, AnalogBlock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAnalogBlock_Populatingoutput(), this.getPopulatingOutput(), null, "populatingoutput", null, 0,
				-1, AnalogBlock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAnalogBlock_BlockId(), ecorePackage.getEString(), "blockId", null, 0, 1, AnalogBlock.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAnalogBlock_SignalsIn(), ecorePackage.getEString(), "SignalsIn", null, 0, -1,
				AnalogBlock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(populatingOutputEClass, PopulatingOutput.class, "PopulatingOutput", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPopulatingOutput_SignalName(), ecorePackage.getEString(), "SignalName", null, 0, 1,
				PopulatingOutput.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getPopulatingOutput_InputName(), ecorePackage.getEString(), "InputName", null, 0, 1,
				PopulatingOutput.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getPopulatingOutput_İnputsignals(), this.getSignals(), null, "inputsignals", null, 0, -1,
				PopulatingOutput.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPopulatingOutput_IdNbr(), ecorePackage.getEString(), "IdNbr", null, 0, 1,
				PopulatingOutput.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(digitalBlockEClass, DigitalBlock.class, "DigitalBlock", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDigitalBlock_Name(), ecorePackage.getEString(), "Name", null, 0, 1, DigitalBlock.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDigitalBlock_Description(), ecorePackage.getEString(), "Description", null, 0, 1,
				DigitalBlock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getDigitalBlock_Digitaltosignals(), this.getSignals(), null, "digitaltosignals", null, 0, -1,
				DigitalBlock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDigitalBlock_Populatinginput(), this.getPopulatingInput(), null, "populatinginput", null, 0,
				-1, DigitalBlock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDigitalBlock_Populatingoutput(), this.getPopulatingOutput(), null, "populatingoutput", null,
				0, -1, DigitalBlock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDigitalBlock_BlockId(), ecorePackage.getEString(), "blockId", null, 0, 1, DigitalBlock.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);
	}

} //SecondModelPackageImpl
