/**
 */
package secondModel.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import secondModel.SecondModelPackage;
import secondModel.SignalsOutput;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Signals Output</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link secondModel.impl.SignalsOutputImpl#getName <em>Name</em>}</li>
 *   <li>{@link secondModel.impl.SignalsOutputImpl#getIdNbr <em>Id Nbr</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SignalsOutputImpl extends MinimalEObjectImpl.Container implements SignalsOutput {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getIdNbr() <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdNbr()
	 * @generated
	 * @ordered
	 */
	protected static final int ID_NBR_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getIdNbr() <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdNbr()
	 * @generated
	 * @ordered
	 */
	protected int ıdNbr = ID_NBR_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SignalsOutputImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SecondModelPackage.Literals.SİGNALS_OUTPUT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.SİGNALS_OUTPUT__NAME, oldName,
					name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getIdNbr() {
		return ıdNbr;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIdNbr(int newIdNbr) {
		int oldIdNbr = ıdNbr;
		ıdNbr = newIdNbr;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.SİGNALS_OUTPUT__ID_NBR, oldIdNbr,
					ıdNbr));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case SecondModelPackage.SİGNALS_OUTPUT__NAME:
			return getName();
		case SecondModelPackage.SİGNALS_OUTPUT__ID_NBR:
			return getIdNbr();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case SecondModelPackage.SİGNALS_OUTPUT__NAME:
			setName((String) newValue);
			return;
		case SecondModelPackage.SİGNALS_OUTPUT__ID_NBR:
			setIdNbr((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case SecondModelPackage.SİGNALS_OUTPUT__NAME:
			setName(NAME_EDEFAULT);
			return;
		case SecondModelPackage.SİGNALS_OUTPUT__ID_NBR:
			setIdNbr(ID_NBR_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case SecondModelPackage.SİGNALS_OUTPUT__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case SecondModelPackage.SİGNALS_OUTPUT__ID_NBR:
			return ıdNbr != ID_NBR_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(", IdNbr: ");
		result.append(ıdNbr);
		result.append(')');
		return result.toString();
	}

} //SignalsOutputImpl
