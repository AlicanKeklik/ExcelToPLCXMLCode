/**
 */
package secondModel.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import secondModel.PopulatingSteps;
import secondModel.SecondModelPackage;
import secondModel.SequenceBlock;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Sequence Block</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link secondModel.impl.SequenceBlockImpl#getName <em>Name</em>}</li>
 *   <li>{@link secondModel.impl.SequenceBlockImpl#getDescription <em>Description</em>}</li>
 *   <li>{@link secondModel.impl.SequenceBlockImpl#getPopulatingsteps <em>Populatingsteps</em>}</li>
 *   <li>{@link secondModel.impl.SequenceBlockImpl#getStepName <em>Step Name</em>}</li>
 *   <li>{@link secondModel.impl.SequenceBlockImpl#getIdNbr <em>Id Nbr</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SequenceBlockImpl extends MinimalEObjectImpl.Container implements SequenceBlock {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected static final String DESCRİPTİON_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected String description = DESCRİPTİON_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPopulatingsteps() <em>Populatingsteps</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPopulatingsteps()
	 * @generated
	 * @ordered
	 */
	protected EList<PopulatingSteps> populatingsteps;

	/**
	 * The cached value of the '{@link #getStepName() <em>Step Name</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStepName()
	 * @generated
	 * @ordered
	 */
	protected EList<String> stepName;

	/**
	 * The default value of the '{@link #getIdNbr() <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdNbr()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_NBR_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getIdNbr() <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdNbr()
	 * @generated
	 * @ordered
	 */
	protected String ıdNbr = ID_NBR_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SequenceBlockImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SecondModelPackage.Literals.SEQUENCE_BLOCK;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.SEQUENCE_BLOCK__NAME, oldName,
					name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getDescription() {
		return description;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDescription(String newDescription) {
		String oldDescription = description;
		description = newDescription;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.SEQUENCE_BLOCK__DESCRİPTİON,
					oldDescription, description));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<PopulatingSteps> getPopulatingsteps() {
		if (populatingsteps == null) {
			populatingsteps = new EObjectContainmentEList<PopulatingSteps>(PopulatingSteps.class, this,
					SecondModelPackage.SEQUENCE_BLOCK__POPULATİNGSTEPS);
		}
		return populatingsteps;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<String> getStepName() {
		if (stepName == null) {
			stepName = new EDataTypeUniqueEList<String>(String.class, this,
					SecondModelPackage.SEQUENCE_BLOCK__STEP_NAME);
		}
		return stepName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getIdNbr() {
		return ıdNbr;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIdNbr(String newIdNbr) {
		String oldIdNbr = ıdNbr;
		ıdNbr = newIdNbr;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.SEQUENCE_BLOCK__ID_NBR, oldIdNbr,
					ıdNbr));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case SecondModelPackage.SEQUENCE_BLOCK__POPULATİNGSTEPS:
			return ((InternalEList<?>) getPopulatingsteps()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case SecondModelPackage.SEQUENCE_BLOCK__NAME:
			return getName();
		case SecondModelPackage.SEQUENCE_BLOCK__DESCRİPTİON:
			return getDescription();
		case SecondModelPackage.SEQUENCE_BLOCK__POPULATİNGSTEPS:
			return getPopulatingsteps();
		case SecondModelPackage.SEQUENCE_BLOCK__STEP_NAME:
			return getStepName();
		case SecondModelPackage.SEQUENCE_BLOCK__ID_NBR:
			return getIdNbr();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case SecondModelPackage.SEQUENCE_BLOCK__NAME:
			setName((String) newValue);
			return;
		case SecondModelPackage.SEQUENCE_BLOCK__DESCRİPTİON:
			setDescription((String) newValue);
			return;
		case SecondModelPackage.SEQUENCE_BLOCK__POPULATİNGSTEPS:
			getPopulatingsteps().clear();
			getPopulatingsteps().addAll((Collection<? extends PopulatingSteps>) newValue);
			return;
		case SecondModelPackage.SEQUENCE_BLOCK__STEP_NAME:
			getStepName().clear();
			getStepName().addAll((Collection<? extends String>) newValue);
			return;
		case SecondModelPackage.SEQUENCE_BLOCK__ID_NBR:
			setIdNbr((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case SecondModelPackage.SEQUENCE_BLOCK__NAME:
			setName(NAME_EDEFAULT);
			return;
		case SecondModelPackage.SEQUENCE_BLOCK__DESCRİPTİON:
			setDescription(DESCRİPTİON_EDEFAULT);
			return;
		case SecondModelPackage.SEQUENCE_BLOCK__POPULATİNGSTEPS:
			getPopulatingsteps().clear();
			return;
		case SecondModelPackage.SEQUENCE_BLOCK__STEP_NAME:
			getStepName().clear();
			return;
		case SecondModelPackage.SEQUENCE_BLOCK__ID_NBR:
			setIdNbr(ID_NBR_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case SecondModelPackage.SEQUENCE_BLOCK__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case SecondModelPackage.SEQUENCE_BLOCK__DESCRİPTİON:
			return DESCRİPTİON_EDEFAULT == null ? description != null : !DESCRİPTİON_EDEFAULT.equals(description);
		case SecondModelPackage.SEQUENCE_BLOCK__POPULATİNGSTEPS:
			return populatingsteps != null && !populatingsteps.isEmpty();
		case SecondModelPackage.SEQUENCE_BLOCK__STEP_NAME:
			return stepName != null && !stepName.isEmpty();
		case SecondModelPackage.SEQUENCE_BLOCK__ID_NBR:
			return ID_NBR_EDEFAULT == null ? ıdNbr != null : !ID_NBR_EDEFAULT.equals(ıdNbr);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(", Description: ");
		result.append(description);
		result.append(", stepName: ");
		result.append(stepName);
		result.append(", IdNbr: ");
		result.append(ıdNbr);
		result.append(')');
		return result.toString();
	}

} //SequenceBlockImpl
