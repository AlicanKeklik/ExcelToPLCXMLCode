/**
 */
package secondModel.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import secondModel.AnalogBlock;
import secondModel.DigitalBlock;
import secondModel.LocalVariables;
import secondModel.SecondModelPackage;
import secondModel.Signals;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Local Variables</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link secondModel.impl.LocalVariablesImpl#getName <em>Name</em>}</li>
 *   <li>{@link secondModel.impl.LocalVariablesImpl#getIdNbr <em>Id Nbr</em>}</li>
 *   <li>{@link secondModel.impl.LocalVariablesImpl#getHardwareReference <em>Hardware Reference</em>}</li>
 *   <li>{@link secondModel.impl.LocalVariablesImpl#getSignals <em>Signals</em>}</li>
 *   <li>{@link secondModel.impl.LocalVariablesImpl#getLocalvariablesforanalog <em>Localvariablesforanalog</em>}</li>
 *   <li>{@link secondModel.impl.LocalVariablesImpl#getLocalvariablesfordigital <em>Localvariablesfordigital</em>}</li>
 * </ul>
 *
 * @generated
 */
public class LocalVariablesImpl extends MinimalEObjectImpl.Container implements LocalVariables {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getIdNbr() <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdNbr()
	 * @generated
	 * @ordered
	 */
	protected static final int ID_NBR_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getIdNbr() <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdNbr()
	 * @generated
	 * @ordered
	 */
	protected int ıdNbr = ID_NBR_EDEFAULT;

	/**
	 * The default value of the '{@link #getHardwareReference() <em>Hardware Reference</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHardwareReference()
	 * @generated
	 * @ordered
	 */
	protected static final String HARDWARE_REFERENCE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getHardwareReference() <em>Hardware Reference</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHardwareReference()
	 * @generated
	 * @ordered
	 */
	protected String hardwareReference = HARDWARE_REFERENCE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSignals() <em>Signals</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSignals()
	 * @generated
	 * @ordered
	 */
	protected EList<Signals> signals;

	/**
	 * The cached value of the '{@link #getLocalvariablesforanalog() <em>Localvariablesforanalog</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocalvariablesforanalog()
	 * @generated
	 * @ordered
	 */
	protected AnalogBlock localvariablesforanalog;

	/**
	 * The cached value of the '{@link #getLocalvariablesfordigital() <em>Localvariablesfordigital</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocalvariablesfordigital()
	 * @generated
	 * @ordered
	 */
	protected DigitalBlock localvariablesfordigital;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LocalVariablesImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SecondModelPackage.Literals.LOCAL_VARİABLES;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.LOCAL_VARİABLES__NAME, oldName,
					name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getHardwareReference() {
		return hardwareReference;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setHardwareReference(String newHardwareReference) {
		String oldHardwareReference = hardwareReference;
		hardwareReference = newHardwareReference;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					SecondModelPackage.LOCAL_VARİABLES__HARDWARE_REFERENCE, oldHardwareReference, hardwareReference));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Signals> getSignals() {
		if (signals == null) {
			signals = new EObjectContainmentEList<Signals>(Signals.class, this,
					SecondModelPackage.LOCAL_VARİABLES__SİGNALS);
		}
		return signals;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AnalogBlock getLocalvariablesforanalog() {
		return localvariablesforanalog;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetLocalvariablesforanalog(AnalogBlock newLocalvariablesforanalog,
			NotificationChain msgs) {
		AnalogBlock oldLocalvariablesforanalog = localvariablesforanalog;
		localvariablesforanalog = newLocalvariablesforanalog;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					SecondModelPackage.LOCAL_VARİABLES__LOCALVARİABLESFORANALOG, oldLocalvariablesforanalog,
					newLocalvariablesforanalog);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setLocalvariablesforanalog(AnalogBlock newLocalvariablesforanalog) {
		if (newLocalvariablesforanalog != localvariablesforanalog) {
			NotificationChain msgs = null;
			if (localvariablesforanalog != null)
				msgs = ((InternalEObject) localvariablesforanalog).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - SecondModelPackage.LOCAL_VARİABLES__LOCALVARİABLESFORANALOG, null,
						msgs);
			if (newLocalvariablesforanalog != null)
				msgs = ((InternalEObject) newLocalvariablesforanalog).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - SecondModelPackage.LOCAL_VARİABLES__LOCALVARİABLESFORANALOG, null,
						msgs);
			msgs = basicSetLocalvariablesforanalog(newLocalvariablesforanalog, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					SecondModelPackage.LOCAL_VARİABLES__LOCALVARİABLESFORANALOG, newLocalvariablesforanalog,
					newLocalvariablesforanalog));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DigitalBlock getLocalvariablesfordigital() {
		return localvariablesfordigital;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetLocalvariablesfordigital(DigitalBlock newLocalvariablesfordigital,
			NotificationChain msgs) {
		DigitalBlock oldLocalvariablesfordigital = localvariablesfordigital;
		localvariablesfordigital = newLocalvariablesfordigital;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					SecondModelPackage.LOCAL_VARİABLES__LOCALVARİABLESFORDİGİTAL, oldLocalvariablesfordigital,
					newLocalvariablesfordigital);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setLocalvariablesfordigital(DigitalBlock newLocalvariablesfordigital) {
		if (newLocalvariablesfordigital != localvariablesfordigital) {
			NotificationChain msgs = null;
			if (localvariablesfordigital != null)
				msgs = ((InternalEObject) localvariablesfordigital).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - SecondModelPackage.LOCAL_VARİABLES__LOCALVARİABLESFORDİGİTAL, null,
						msgs);
			if (newLocalvariablesfordigital != null)
				msgs = ((InternalEObject) newLocalvariablesfordigital).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - SecondModelPackage.LOCAL_VARİABLES__LOCALVARİABLESFORDİGİTAL, null,
						msgs);
			msgs = basicSetLocalvariablesfordigital(newLocalvariablesfordigital, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					SecondModelPackage.LOCAL_VARİABLES__LOCALVARİABLESFORDİGİTAL, newLocalvariablesfordigital,
					newLocalvariablesfordigital));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getIdNbr() {
		return ıdNbr;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIdNbr(int newIdNbr) {
		int oldIdNbr = ıdNbr;
		ıdNbr = newIdNbr;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.LOCAL_VARİABLES__ID_NBR, oldIdNbr,
					ıdNbr));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case SecondModelPackage.LOCAL_VARİABLES__SİGNALS:
			return ((InternalEList<?>) getSignals()).basicRemove(otherEnd, msgs);
		case SecondModelPackage.LOCAL_VARİABLES__LOCALVARİABLESFORANALOG:
			return basicSetLocalvariablesforanalog(null, msgs);
		case SecondModelPackage.LOCAL_VARİABLES__LOCALVARİABLESFORDİGİTAL:
			return basicSetLocalvariablesfordigital(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case SecondModelPackage.LOCAL_VARİABLES__NAME:
			return getName();
		case SecondModelPackage.LOCAL_VARİABLES__ID_NBR:
			return getIdNbr();
		case SecondModelPackage.LOCAL_VARİABLES__HARDWARE_REFERENCE:
			return getHardwareReference();
		case SecondModelPackage.LOCAL_VARİABLES__SİGNALS:
			return getSignals();
		case SecondModelPackage.LOCAL_VARİABLES__LOCALVARİABLESFORANALOG:
			return getLocalvariablesforanalog();
		case SecondModelPackage.LOCAL_VARİABLES__LOCALVARİABLESFORDİGİTAL:
			return getLocalvariablesfordigital();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case SecondModelPackage.LOCAL_VARİABLES__NAME:
			setName((String) newValue);
			return;
		case SecondModelPackage.LOCAL_VARİABLES__ID_NBR:
			setIdNbr((Integer) newValue);
			return;
		case SecondModelPackage.LOCAL_VARİABLES__HARDWARE_REFERENCE:
			setHardwareReference((String) newValue);
			return;
		case SecondModelPackage.LOCAL_VARİABLES__SİGNALS:
			getSignals().clear();
			getSignals().addAll((Collection<? extends Signals>) newValue);
			return;
		case SecondModelPackage.LOCAL_VARİABLES__LOCALVARİABLESFORANALOG:
			setLocalvariablesforanalog((AnalogBlock) newValue);
			return;
		case SecondModelPackage.LOCAL_VARİABLES__LOCALVARİABLESFORDİGİTAL:
			setLocalvariablesfordigital((DigitalBlock) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case SecondModelPackage.LOCAL_VARİABLES__NAME:
			setName(NAME_EDEFAULT);
			return;
		case SecondModelPackage.LOCAL_VARİABLES__ID_NBR:
			setIdNbr(ID_NBR_EDEFAULT);
			return;
		case SecondModelPackage.LOCAL_VARİABLES__HARDWARE_REFERENCE:
			setHardwareReference(HARDWARE_REFERENCE_EDEFAULT);
			return;
		case SecondModelPackage.LOCAL_VARİABLES__SİGNALS:
			getSignals().clear();
			return;
		case SecondModelPackage.LOCAL_VARİABLES__LOCALVARİABLESFORANALOG:
			setLocalvariablesforanalog((AnalogBlock) null);
			return;
		case SecondModelPackage.LOCAL_VARİABLES__LOCALVARİABLESFORDİGİTAL:
			setLocalvariablesfordigital((DigitalBlock) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case SecondModelPackage.LOCAL_VARİABLES__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case SecondModelPackage.LOCAL_VARİABLES__ID_NBR:
			return ıdNbr != ID_NBR_EDEFAULT;
		case SecondModelPackage.LOCAL_VARİABLES__HARDWARE_REFERENCE:
			return HARDWARE_REFERENCE_EDEFAULT == null ? hardwareReference != null
					: !HARDWARE_REFERENCE_EDEFAULT.equals(hardwareReference);
		case SecondModelPackage.LOCAL_VARİABLES__SİGNALS:
			return signals != null && !signals.isEmpty();
		case SecondModelPackage.LOCAL_VARİABLES__LOCALVARİABLESFORANALOG:
			return localvariablesforanalog != null;
		case SecondModelPackage.LOCAL_VARİABLES__LOCALVARİABLESFORDİGİTAL:
			return localvariablesfordigital != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(", IdNbr: ");
		result.append(ıdNbr);
		result.append(", hardwareReference: ");
		result.append(hardwareReference);
		result.append(')');
		return result.toString();
	}

} //LocalVariablesImpl
