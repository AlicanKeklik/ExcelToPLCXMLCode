/**
 */
package secondModel.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;
import secondModel.LocalVariables;
import secondModel.MotorBlock;
import secondModel.PopulatingInput;
import secondModel.PopulatingOutput;
import secondModel.SecondModelPackage;
import secondModel.Signals;
import secondModel.SignalsInput;
import secondModel.SignalsOutput;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Motor Block</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link secondModel.impl.MotorBlockImpl#getName <em>Name</em>}</li>
 *   <li>{@link secondModel.impl.MotorBlockImpl#getDescription <em>Description</em>}</li>
 *   <li>{@link secondModel.impl.MotorBlockImpl#getSignalsIn <em>Signals In</em>}</li>
 *   <li>{@link secondModel.impl.MotorBlockImpl#getSignals <em>Signals</em>}</li>
 *   <li>{@link secondModel.impl.MotorBlockImpl#getType <em>Type</em>}</li>
 *   <li>{@link secondModel.impl.MotorBlockImpl#getLocalvariables <em>Localvariables</em>}</li>
 *   <li>{@link secondModel.impl.MotorBlockImpl#getSignalsinput <em>Signalsinput</em>}</li>
 *   <li>{@link secondModel.impl.MotorBlockImpl#getSignalsoutput <em>Signalsoutput</em>}</li>
 *   <li>{@link secondModel.impl.MotorBlockImpl#getIdNbr <em>Id Nbr</em>}</li>
 *   <li>{@link secondModel.impl.MotorBlockImpl#getPopulatinginput <em>Populatinginput</em>}</li>
 *   <li>{@link secondModel.impl.MotorBlockImpl#getPopulatingoutput <em>Populatingoutput</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MotorBlockImpl extends MinimalEObjectImpl.Container implements MotorBlock {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected static final String DESCRİPTİON_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected String description = DESCRİPTİON_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSignalsIn() <em>Signals In</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSignalsIn()
	 * @generated
	 * @ordered
	 */
	protected EList<String> signalsIn;

	/**
	 * The cached value of the '{@link #getSignals() <em>Signals</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSignals()
	 * @generated
	 * @ordered
	 */
	protected EList<Signals> signals;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final String TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected String type = TYPE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getLocalvariables() <em>Localvariables</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocalvariables()
	 * @generated
	 * @ordered
	 */
	protected LocalVariables localvariables;

	/**
	 * The cached value of the '{@link #getSignalsinput() <em>Signalsinput</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSignalsinput()
	 * @generated
	 * @ordered
	 */
	protected EList<SignalsInput> signalsinput;

	/**
	 * The cached value of the '{@link #getSignalsoutput() <em>Signalsoutput</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSignalsoutput()
	 * @generated
	 * @ordered
	 */
	protected EList<SignalsOutput> signalsoutput;

	/**
	 * The default value of the '{@link #getIdNbr() <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdNbr()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_NBR_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getIdNbr() <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdNbr()
	 * @generated
	 * @ordered
	 */
	protected String ıdNbr = ID_NBR_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPopulatinginput() <em>Populatinginput</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPopulatinginput()
	 * @generated
	 * @ordered
	 */
	protected EList<PopulatingInput> populatinginput;

	/**
	 * The cached value of the '{@link #getPopulatingoutput() <em>Populatingoutput</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPopulatingoutput()
	 * @generated
	 * @ordered
	 */
	protected EList<PopulatingOutput> populatingoutput;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MotorBlockImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SecondModelPackage.Literals.MOTOR_BLOCK;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.MOTOR_BLOCK__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getDescription() {
		return description;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDescription(String newDescription) {
		String oldDescription = description;
		description = newDescription;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.MOTOR_BLOCK__DESCRİPTİON,
					oldDescription, description));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<String> getSignalsIn() {
		if (signalsIn == null) {
			signalsIn = new EDataTypeUniqueEList<String>(String.class, this,
					SecondModelPackage.MOTOR_BLOCK__SİGNALS_IN);
		}
		return signalsIn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Signals> getSignals() {
		if (signals == null) {
			signals = new EObjectContainmentEList<Signals>(Signals.class, this,
					SecondModelPackage.MOTOR_BLOCK__SİGNALS);
		}
		return signals;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setType(String newType) {
		String oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.MOTOR_BLOCK__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LocalVariables getLocalvariables() {
		return localvariables;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetLocalvariables(LocalVariables newLocalvariables, NotificationChain msgs) {
		LocalVariables oldLocalvariables = localvariables;
		localvariables = newLocalvariables;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					SecondModelPackage.MOTOR_BLOCK__LOCALVARİABLES, oldLocalvariables, newLocalvariables);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setLocalvariables(LocalVariables newLocalvariables) {
		if (newLocalvariables != localvariables) {
			NotificationChain msgs = null;
			if (localvariables != null)
				msgs = ((InternalEObject) localvariables).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - SecondModelPackage.MOTOR_BLOCK__LOCALVARİABLES, null, msgs);
			if (newLocalvariables != null)
				msgs = ((InternalEObject) newLocalvariables).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - SecondModelPackage.MOTOR_BLOCK__LOCALVARİABLES, null, msgs);
			msgs = basicSetLocalvariables(newLocalvariables, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.MOTOR_BLOCK__LOCALVARİABLES,
					newLocalvariables, newLocalvariables));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<SignalsInput> getSignalsinput() {
		if (signalsinput == null) {
			signalsinput = new EObjectContainmentEList<SignalsInput>(SignalsInput.class, this,
					SecondModelPackage.MOTOR_BLOCK__SİGNALSİNPUT);
		}
		return signalsinput;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<SignalsOutput> getSignalsoutput() {
		if (signalsoutput == null) {
			signalsoutput = new EObjectContainmentEList<SignalsOutput>(SignalsOutput.class, this,
					SecondModelPackage.MOTOR_BLOCK__SİGNALSOUTPUT);
		}
		return signalsoutput;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getIdNbr() {
		return ıdNbr;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIdNbr(String newIdNbr) {
		String oldIdNbr = ıdNbr;
		ıdNbr = newIdNbr;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.MOTOR_BLOCK__ID_NBR, oldIdNbr,
					ıdNbr));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<PopulatingInput> getPopulatinginput() {
		if (populatinginput == null) {
			populatinginput = new EObjectContainmentEList<PopulatingInput>(PopulatingInput.class, this,
					SecondModelPackage.MOTOR_BLOCK__POPULATİNGİNPUT);
		}
		return populatinginput;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<PopulatingOutput> getPopulatingoutput() {
		if (populatingoutput == null) {
			populatingoutput = new EObjectContainmentEList<PopulatingOutput>(PopulatingOutput.class, this,
					SecondModelPackage.MOTOR_BLOCK__POPULATİNGOUTPUT);
		}
		return populatingoutput;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case SecondModelPackage.MOTOR_BLOCK__SİGNALS:
			return ((InternalEList<?>) getSignals()).basicRemove(otherEnd, msgs);
		case SecondModelPackage.MOTOR_BLOCK__LOCALVARİABLES:
			return basicSetLocalvariables(null, msgs);
		case SecondModelPackage.MOTOR_BLOCK__SİGNALSİNPUT:
			return ((InternalEList<?>) getSignalsinput()).basicRemove(otherEnd, msgs);
		case SecondModelPackage.MOTOR_BLOCK__SİGNALSOUTPUT:
			return ((InternalEList<?>) getSignalsoutput()).basicRemove(otherEnd, msgs);
		case SecondModelPackage.MOTOR_BLOCK__POPULATİNGİNPUT:
			return ((InternalEList<?>) getPopulatinginput()).basicRemove(otherEnd, msgs);
		case SecondModelPackage.MOTOR_BLOCK__POPULATİNGOUTPUT:
			return ((InternalEList<?>) getPopulatingoutput()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case SecondModelPackage.MOTOR_BLOCK__NAME:
			return getName();
		case SecondModelPackage.MOTOR_BLOCK__DESCRİPTİON:
			return getDescription();
		case SecondModelPackage.MOTOR_BLOCK__SİGNALS_IN:
			return getSignalsIn();
		case SecondModelPackage.MOTOR_BLOCK__SİGNALS:
			return getSignals();
		case SecondModelPackage.MOTOR_BLOCK__TYPE:
			return getType();
		case SecondModelPackage.MOTOR_BLOCK__LOCALVARİABLES:
			return getLocalvariables();
		case SecondModelPackage.MOTOR_BLOCK__SİGNALSİNPUT:
			return getSignalsinput();
		case SecondModelPackage.MOTOR_BLOCK__SİGNALSOUTPUT:
			return getSignalsoutput();
		case SecondModelPackage.MOTOR_BLOCK__ID_NBR:
			return getIdNbr();
		case SecondModelPackage.MOTOR_BLOCK__POPULATİNGİNPUT:
			return getPopulatinginput();
		case SecondModelPackage.MOTOR_BLOCK__POPULATİNGOUTPUT:
			return getPopulatingoutput();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case SecondModelPackage.MOTOR_BLOCK__NAME:
			setName((String) newValue);
			return;
		case SecondModelPackage.MOTOR_BLOCK__DESCRİPTİON:
			setDescription((String) newValue);
			return;
		case SecondModelPackage.MOTOR_BLOCK__SİGNALS_IN:
			getSignalsIn().clear();
			getSignalsIn().addAll((Collection<? extends String>) newValue);
			return;
		case SecondModelPackage.MOTOR_BLOCK__SİGNALS:
			getSignals().clear();
			getSignals().addAll((Collection<? extends Signals>) newValue);
			return;
		case SecondModelPackage.MOTOR_BLOCK__TYPE:
			setType((String) newValue);
			return;
		case SecondModelPackage.MOTOR_BLOCK__LOCALVARİABLES:
			setLocalvariables((LocalVariables) newValue);
			return;
		case SecondModelPackage.MOTOR_BLOCK__SİGNALSİNPUT:
			getSignalsinput().clear();
			getSignalsinput().addAll((Collection<? extends SignalsInput>) newValue);
			return;
		case SecondModelPackage.MOTOR_BLOCK__SİGNALSOUTPUT:
			getSignalsoutput().clear();
			getSignalsoutput().addAll((Collection<? extends SignalsOutput>) newValue);
			return;
		case SecondModelPackage.MOTOR_BLOCK__ID_NBR:
			setIdNbr((String) newValue);
			return;
		case SecondModelPackage.MOTOR_BLOCK__POPULATİNGİNPUT:
			getPopulatinginput().clear();
			getPopulatinginput().addAll((Collection<? extends PopulatingInput>) newValue);
			return;
		case SecondModelPackage.MOTOR_BLOCK__POPULATİNGOUTPUT:
			getPopulatingoutput().clear();
			getPopulatingoutput().addAll((Collection<? extends PopulatingOutput>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case SecondModelPackage.MOTOR_BLOCK__NAME:
			setName(NAME_EDEFAULT);
			return;
		case SecondModelPackage.MOTOR_BLOCK__DESCRİPTİON:
			setDescription(DESCRİPTİON_EDEFAULT);
			return;
		case SecondModelPackage.MOTOR_BLOCK__SİGNALS_IN:
			getSignalsIn().clear();
			return;
		case SecondModelPackage.MOTOR_BLOCK__SİGNALS:
			getSignals().clear();
			return;
		case SecondModelPackage.MOTOR_BLOCK__TYPE:
			setType(TYPE_EDEFAULT);
			return;
		case SecondModelPackage.MOTOR_BLOCK__LOCALVARİABLES:
			setLocalvariables((LocalVariables) null);
			return;
		case SecondModelPackage.MOTOR_BLOCK__SİGNALSİNPUT:
			getSignalsinput().clear();
			return;
		case SecondModelPackage.MOTOR_BLOCK__SİGNALSOUTPUT:
			getSignalsoutput().clear();
			return;
		case SecondModelPackage.MOTOR_BLOCK__ID_NBR:
			setIdNbr(ID_NBR_EDEFAULT);
			return;
		case SecondModelPackage.MOTOR_BLOCK__POPULATİNGİNPUT:
			getPopulatinginput().clear();
			return;
		case SecondModelPackage.MOTOR_BLOCK__POPULATİNGOUTPUT:
			getPopulatingoutput().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case SecondModelPackage.MOTOR_BLOCK__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case SecondModelPackage.MOTOR_BLOCK__DESCRİPTİON:
			return DESCRİPTİON_EDEFAULT == null ? description != null : !DESCRİPTİON_EDEFAULT.equals(description);
		case SecondModelPackage.MOTOR_BLOCK__SİGNALS_IN:
			return signalsIn != null && !signalsIn.isEmpty();
		case SecondModelPackage.MOTOR_BLOCK__SİGNALS:
			return signals != null && !signals.isEmpty();
		case SecondModelPackage.MOTOR_BLOCK__TYPE:
			return TYPE_EDEFAULT == null ? type != null : !TYPE_EDEFAULT.equals(type);
		case SecondModelPackage.MOTOR_BLOCK__LOCALVARİABLES:
			return localvariables != null;
		case SecondModelPackage.MOTOR_BLOCK__SİGNALSİNPUT:
			return signalsinput != null && !signalsinput.isEmpty();
		case SecondModelPackage.MOTOR_BLOCK__SİGNALSOUTPUT:
			return signalsoutput != null && !signalsoutput.isEmpty();
		case SecondModelPackage.MOTOR_BLOCK__ID_NBR:
			return ID_NBR_EDEFAULT == null ? ıdNbr != null : !ID_NBR_EDEFAULT.equals(ıdNbr);
		case SecondModelPackage.MOTOR_BLOCK__POPULATİNGİNPUT:
			return populatinginput != null && !populatinginput.isEmpty();
		case SecondModelPackage.MOTOR_BLOCK__POPULATİNGOUTPUT:
			return populatingoutput != null && !populatingoutput.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(", Description: ");
		result.append(description);
		result.append(", SignalsIn: ");
		result.append(signalsIn);
		result.append(", Type: ");
		result.append(type);
		result.append(", IdNbr: ");
		result.append(ıdNbr);
		result.append(')');
		return result.toString();
	}

} //MotorBlockImpl
