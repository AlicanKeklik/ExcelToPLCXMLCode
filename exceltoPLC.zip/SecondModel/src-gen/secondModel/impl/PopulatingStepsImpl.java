/**
 */
package secondModel.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import secondModel.PopulatingSteps;
import secondModel.SecondModelPackage;
import secondModel.SeqOperator;
import secondModel.Signals;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Populating Steps</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link secondModel.impl.PopulatingStepsImpl#getSignals <em>Signals</em>}</li>
 *   <li>{@link secondModel.impl.PopulatingStepsImpl#getSeqoperator <em>Seqoperator</em>}</li>
 *   <li>{@link secondModel.impl.PopulatingStepsImpl#getSignalName <em>Signal Name</em>}</li>
 *   <li>{@link secondModel.impl.PopulatingStepsImpl#getInputName <em>Input Name</em>}</li>
 *   <li>{@link secondModel.impl.PopulatingStepsImpl#getIdNbr <em>Id Nbr</em>}</li>
 *   <li>{@link secondModel.impl.PopulatingStepsImpl#getNextIdNbr <em>Next Id Nbr</em>}</li>
 *   <li>{@link secondModel.impl.PopulatingStepsImpl#getTransitionIdNbr <em>Transition Id Nbr</em>}</li>
 *   <li>{@link secondModel.impl.PopulatingStepsImpl#getLastTransitionIdNbr <em>Last Transition Id Nbr</em>}</li>
 *   <li>{@link secondModel.impl.PopulatingStepsImpl#getLastTransitionStepNbr <em>Last Transition Step Nbr</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PopulatingStepsImpl extends MinimalEObjectImpl.Container implements PopulatingSteps {
	/**
	 * The cached value of the '{@link #getSignals() <em>Signals</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSignals()
	 * @generated
	 * @ordered
	 */
	protected EList<Signals> signals;

	/**
	 * The cached value of the '{@link #getSeqoperator() <em>Seqoperator</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSeqoperator()
	 * @generated
	 * @ordered
	 */
	protected EList<SeqOperator> seqoperator;

	/**
	 * The default value of the '{@link #getSignalName() <em>Signal Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSignalName()
	 * @generated
	 * @ordered
	 */
	protected static final String SİGNAL_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSignalName() <em>Signal Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSignalName()
	 * @generated
	 * @ordered
	 */
	protected String signalName = SİGNAL_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getInputName() <em>Input Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInputName()
	 * @generated
	 * @ordered
	 */
	protected static final String INPUT_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getInputName() <em>Input Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInputName()
	 * @generated
	 * @ordered
	 */
	protected String ınputName = INPUT_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getIdNbr() <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdNbr()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_NBR_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getIdNbr() <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdNbr()
	 * @generated
	 * @ordered
	 */
	protected String ıdNbr = ID_NBR_EDEFAULT;

	/**
	 * The default value of the '{@link #getNextIdNbr() <em>Next Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNextIdNbr()
	 * @generated
	 * @ordered
	 */
	protected static final String NEXT_ID_NBR_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNextIdNbr() <em>Next Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNextIdNbr()
	 * @generated
	 * @ordered
	 */
	protected String nextIdNbr = NEXT_ID_NBR_EDEFAULT;

	/**
	 * The default value of the '{@link #getTransitionIdNbr() <em>Transition Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransitionIdNbr()
	 * @generated
	 * @ordered
	 */
	protected static final String TRANSİTİON_ID_NBR_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTransitionIdNbr() <em>Transition Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransitionIdNbr()
	 * @generated
	 * @ordered
	 */
	protected String transitionIdNbr = TRANSİTİON_ID_NBR_EDEFAULT;

	/**
	 * The default value of the '{@link #getLastTransitionIdNbr() <em>Last Transition Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLastTransitionIdNbr()
	 * @generated
	 * @ordered
	 */
	protected static final String LAST_TRANSİTİON_ID_NBR_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLastTransitionIdNbr() <em>Last Transition Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLastTransitionIdNbr()
	 * @generated
	 * @ordered
	 */
	protected String lastTransitionIdNbr = LAST_TRANSİTİON_ID_NBR_EDEFAULT;

	/**
	 * The default value of the '{@link #getLastTransitionStepNbr() <em>Last Transition Step Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLastTransitionStepNbr()
	 * @generated
	 * @ordered
	 */
	protected static final String LAST_TRANSİTİON_STEP_NBR_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLastTransitionStepNbr() <em>Last Transition Step Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLastTransitionStepNbr()
	 * @generated
	 * @ordered
	 */
	protected String lastTransitionStepNbr = LAST_TRANSİTİON_STEP_NBR_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PopulatingStepsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SecondModelPackage.Literals.POPULATİNG_STEPS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Signals> getSignals() {
		if (signals == null) {
			signals = new EObjectResolvingEList<Signals>(Signals.class, this,
					SecondModelPackage.POPULATİNG_STEPS__SİGNALS);
		}
		return signals;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<SeqOperator> getSeqoperator() {
		if (seqoperator == null) {
			seqoperator = new EObjectContainmentEList<SeqOperator>(SeqOperator.class, this,
					SecondModelPackage.POPULATİNG_STEPS__SEQOPERATOR);
		}
		return seqoperator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getSignalName() {
		return signalName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSignalName(String newSignalName) {
		String oldSignalName = signalName;
		signalName = newSignalName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.POPULATİNG_STEPS__SİGNAL_NAME,
					oldSignalName, signalName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getInputName() {
		return ınputName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInputName(String newInputName) {
		String oldInputName = ınputName;
		ınputName = newInputName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.POPULATİNG_STEPS__INPUT_NAME,
					oldInputName, ınputName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getIdNbr() {
		return ıdNbr;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIdNbr(String newIdNbr) {
		String oldIdNbr = ıdNbr;
		ıdNbr = newIdNbr;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.POPULATİNG_STEPS__ID_NBR, oldIdNbr,
					ıdNbr));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getNextIdNbr() {
		return nextIdNbr;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setNextIdNbr(String newNextIdNbr) {
		String oldNextIdNbr = nextIdNbr;
		nextIdNbr = newNextIdNbr;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.POPULATİNG_STEPS__NEXT_ID_NBR,
					oldNextIdNbr, nextIdNbr));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getTransitionIdNbr() {
		return transitionIdNbr;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setTransitionIdNbr(String newTransitionIdNbr) {
		String oldTransitionIdNbr = transitionIdNbr;
		transitionIdNbr = newTransitionIdNbr;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					SecondModelPackage.POPULATİNG_STEPS__TRANSİTİON_ID_NBR, oldTransitionIdNbr, transitionIdNbr));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getLastTransitionIdNbr() {
		return lastTransitionIdNbr;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setLastTransitionIdNbr(String newLastTransitionIdNbr) {
		String oldLastTransitionIdNbr = lastTransitionIdNbr;
		lastTransitionIdNbr = newLastTransitionIdNbr;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					SecondModelPackage.POPULATİNG_STEPS__LAST_TRANSİTİON_ID_NBR, oldLastTransitionIdNbr,
					lastTransitionIdNbr));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getLastTransitionStepNbr() {
		return lastTransitionStepNbr;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setLastTransitionStepNbr(String newLastTransitionStepNbr) {
		String oldLastTransitionStepNbr = lastTransitionStepNbr;
		lastTransitionStepNbr = newLastTransitionStepNbr;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					SecondModelPackage.POPULATİNG_STEPS__LAST_TRANSİTİON_STEP_NBR, oldLastTransitionStepNbr,
					lastTransitionStepNbr));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case SecondModelPackage.POPULATİNG_STEPS__SEQOPERATOR:
			return ((InternalEList<?>) getSeqoperator()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case SecondModelPackage.POPULATİNG_STEPS__SİGNALS:
			return getSignals();
		case SecondModelPackage.POPULATİNG_STEPS__SEQOPERATOR:
			return getSeqoperator();
		case SecondModelPackage.POPULATİNG_STEPS__SİGNAL_NAME:
			return getSignalName();
		case SecondModelPackage.POPULATİNG_STEPS__INPUT_NAME:
			return getInputName();
		case SecondModelPackage.POPULATİNG_STEPS__ID_NBR:
			return getIdNbr();
		case SecondModelPackage.POPULATİNG_STEPS__NEXT_ID_NBR:
			return getNextIdNbr();
		case SecondModelPackage.POPULATİNG_STEPS__TRANSİTİON_ID_NBR:
			return getTransitionIdNbr();
		case SecondModelPackage.POPULATİNG_STEPS__LAST_TRANSİTİON_ID_NBR:
			return getLastTransitionIdNbr();
		case SecondModelPackage.POPULATİNG_STEPS__LAST_TRANSİTİON_STEP_NBR:
			return getLastTransitionStepNbr();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case SecondModelPackage.POPULATİNG_STEPS__SİGNALS:
			getSignals().clear();
			getSignals().addAll((Collection<? extends Signals>) newValue);
			return;
		case SecondModelPackage.POPULATİNG_STEPS__SEQOPERATOR:
			getSeqoperator().clear();
			getSeqoperator().addAll((Collection<? extends SeqOperator>) newValue);
			return;
		case SecondModelPackage.POPULATİNG_STEPS__SİGNAL_NAME:
			setSignalName((String) newValue);
			return;
		case SecondModelPackage.POPULATİNG_STEPS__INPUT_NAME:
			setInputName((String) newValue);
			return;
		case SecondModelPackage.POPULATİNG_STEPS__ID_NBR:
			setIdNbr((String) newValue);
			return;
		case SecondModelPackage.POPULATİNG_STEPS__NEXT_ID_NBR:
			setNextIdNbr((String) newValue);
			return;
		case SecondModelPackage.POPULATİNG_STEPS__TRANSİTİON_ID_NBR:
			setTransitionIdNbr((String) newValue);
			return;
		case SecondModelPackage.POPULATİNG_STEPS__LAST_TRANSİTİON_ID_NBR:
			setLastTransitionIdNbr((String) newValue);
			return;
		case SecondModelPackage.POPULATİNG_STEPS__LAST_TRANSİTİON_STEP_NBR:
			setLastTransitionStepNbr((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case SecondModelPackage.POPULATİNG_STEPS__SİGNALS:
			getSignals().clear();
			return;
		case SecondModelPackage.POPULATİNG_STEPS__SEQOPERATOR:
			getSeqoperator().clear();
			return;
		case SecondModelPackage.POPULATİNG_STEPS__SİGNAL_NAME:
			setSignalName(SİGNAL_NAME_EDEFAULT);
			return;
		case SecondModelPackage.POPULATİNG_STEPS__INPUT_NAME:
			setInputName(INPUT_NAME_EDEFAULT);
			return;
		case SecondModelPackage.POPULATİNG_STEPS__ID_NBR:
			setIdNbr(ID_NBR_EDEFAULT);
			return;
		case SecondModelPackage.POPULATİNG_STEPS__NEXT_ID_NBR:
			setNextIdNbr(NEXT_ID_NBR_EDEFAULT);
			return;
		case SecondModelPackage.POPULATİNG_STEPS__TRANSİTİON_ID_NBR:
			setTransitionIdNbr(TRANSİTİON_ID_NBR_EDEFAULT);
			return;
		case SecondModelPackage.POPULATİNG_STEPS__LAST_TRANSİTİON_ID_NBR:
			setLastTransitionIdNbr(LAST_TRANSİTİON_ID_NBR_EDEFAULT);
			return;
		case SecondModelPackage.POPULATİNG_STEPS__LAST_TRANSİTİON_STEP_NBR:
			setLastTransitionStepNbr(LAST_TRANSİTİON_STEP_NBR_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case SecondModelPackage.POPULATİNG_STEPS__SİGNALS:
			return signals != null && !signals.isEmpty();
		case SecondModelPackage.POPULATİNG_STEPS__SEQOPERATOR:
			return seqoperator != null && !seqoperator.isEmpty();
		case SecondModelPackage.POPULATİNG_STEPS__SİGNAL_NAME:
			return SİGNAL_NAME_EDEFAULT == null ? signalName != null : !SİGNAL_NAME_EDEFAULT.equals(signalName);
		case SecondModelPackage.POPULATİNG_STEPS__INPUT_NAME:
			return INPUT_NAME_EDEFAULT == null ? ınputName != null : !INPUT_NAME_EDEFAULT.equals(ınputName);
		case SecondModelPackage.POPULATİNG_STEPS__ID_NBR:
			return ID_NBR_EDEFAULT == null ? ıdNbr != null : !ID_NBR_EDEFAULT.equals(ıdNbr);
		case SecondModelPackage.POPULATİNG_STEPS__NEXT_ID_NBR:
			return NEXT_ID_NBR_EDEFAULT == null ? nextIdNbr != null : !NEXT_ID_NBR_EDEFAULT.equals(nextIdNbr);
		case SecondModelPackage.POPULATİNG_STEPS__TRANSİTİON_ID_NBR:
			return TRANSİTİON_ID_NBR_EDEFAULT == null ? transitionIdNbr != null
					: !TRANSİTİON_ID_NBR_EDEFAULT.equals(transitionIdNbr);
		case SecondModelPackage.POPULATİNG_STEPS__LAST_TRANSİTİON_ID_NBR:
			return LAST_TRANSİTİON_ID_NBR_EDEFAULT == null ? lastTransitionIdNbr != null
					: !LAST_TRANSİTİON_ID_NBR_EDEFAULT.equals(lastTransitionIdNbr);
		case SecondModelPackage.POPULATİNG_STEPS__LAST_TRANSİTİON_STEP_NBR:
			return LAST_TRANSİTİON_STEP_NBR_EDEFAULT == null ? lastTransitionStepNbr != null
					: !LAST_TRANSİTİON_STEP_NBR_EDEFAULT.equals(lastTransitionStepNbr);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (SignalName: ");
		result.append(signalName);
		result.append(", InputName: ");
		result.append(ınputName);
		result.append(", IdNbr: ");
		result.append(ıdNbr);
		result.append(", NextIdNbr: ");
		result.append(nextIdNbr);
		result.append(", TransitionIdNbr: ");
		result.append(transitionIdNbr);
		result.append(", LastTransitionIdNbr: ");
		result.append(lastTransitionIdNbr);
		result.append(", LastTransitionStepNbr: ");
		result.append(lastTransitionStepNbr);
		result.append(')');
		return result.toString();
	}

} //PopulatingStepsImpl
