/**
 */
package secondModel.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import secondModel.AnalogBlock;
import secondModel.DigitalBlock;
import secondModel.LocalVariables;
import secondModel.MotorBlock;
import secondModel.SecondModelPackage;
import secondModel.SequenceBlock;
import secondModel.Signals;
import secondModel.TopDataClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Top Data Class</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link secondModel.impl.TopDataClassImpl#getHeaderText <em>Header Text</em>}</li>
 *   <li>{@link secondModel.impl.TopDataClassImpl#getLocalvariables <em>Localvariables</em>}</li>
 *   <li>{@link secondModel.impl.TopDataClassImpl#getMotorblock <em>Motorblock</em>}</li>
 *   <li>{@link secondModel.impl.TopDataClassImpl#getSignals <em>Signals</em>}</li>
 *   <li>{@link secondModel.impl.TopDataClassImpl#getSequenceblock <em>Sequenceblock</em>}</li>
 *   <li>{@link secondModel.impl.TopDataClassImpl#getAnalogblock <em>Analogblock</em>}</li>
 *   <li>{@link secondModel.impl.TopDataClassImpl#getDigitalblock <em>Digitalblock</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TopDataClassImpl extends MinimalEObjectImpl.Container implements TopDataClass {
	/**
	 * The default value of the '{@link #getHeaderText() <em>Header Text</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHeaderText()
	 * @generated
	 * @ordered
	 */
	protected static final String HEADER_TEXT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getHeaderText() <em>Header Text</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHeaderText()
	 * @generated
	 * @ordered
	 */
	protected String headerText = HEADER_TEXT_EDEFAULT;

	/**
	 * The cached value of the '{@link #getLocalvariables() <em>Localvariables</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocalvariables()
	 * @generated
	 * @ordered
	 */
	protected EList<LocalVariables> localvariables;

	/**
	 * The cached value of the '{@link #getMotorblock() <em>Motorblock</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMotorblock()
	 * @generated
	 * @ordered
	 */
	protected EList<MotorBlock> motorblock;

	/**
	 * The cached value of the '{@link #getSignals() <em>Signals</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSignals()
	 * @generated
	 * @ordered
	 */
	protected EList<Signals> signals;

	/**
	 * The cached value of the '{@link #getSequenceblock() <em>Sequenceblock</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSequenceblock()
	 * @generated
	 * @ordered
	 */
	protected EList<SequenceBlock> sequenceblock;

	/**
	 * The cached value of the '{@link #getAnalogblock() <em>Analogblock</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAnalogblock()
	 * @generated
	 * @ordered
	 */
	protected EList<AnalogBlock> analogblock;

	/**
	 * The cached value of the '{@link #getDigitalblock() <em>Digitalblock</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDigitalblock()
	 * @generated
	 * @ordered
	 */
	protected EList<DigitalBlock> digitalblock;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TopDataClassImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SecondModelPackage.Literals.TOP_DATA_CLASS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getHeaderText() {
		return headerText;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setHeaderText(String newHeaderText) {
		String oldHeaderText = headerText;
		headerText = newHeaderText;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.TOP_DATA_CLASS__HEADER_TEXT,
					oldHeaderText, headerText));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<LocalVariables> getLocalvariables() {
		if (localvariables == null) {
			localvariables = new EObjectContainmentEList<LocalVariables>(LocalVariables.class, this,
					SecondModelPackage.TOP_DATA_CLASS__LOCALVARİABLES);
		}
		return localvariables;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<MotorBlock> getMotorblock() {
		if (motorblock == null) {
			motorblock = new EObjectContainmentEList<MotorBlock>(MotorBlock.class, this,
					SecondModelPackage.TOP_DATA_CLASS__MOTORBLOCK);
		}
		return motorblock;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Signals> getSignals() {
		if (signals == null) {
			signals = new EObjectContainmentEList<Signals>(Signals.class, this,
					SecondModelPackage.TOP_DATA_CLASS__SİGNALS);
		}
		return signals;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<SequenceBlock> getSequenceblock() {
		if (sequenceblock == null) {
			sequenceblock = new EObjectContainmentEList<SequenceBlock>(SequenceBlock.class, this,
					SecondModelPackage.TOP_DATA_CLASS__SEQUENCEBLOCK);
		}
		return sequenceblock;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<AnalogBlock> getAnalogblock() {
		if (analogblock == null) {
			analogblock = new EObjectContainmentEList<AnalogBlock>(AnalogBlock.class, this,
					SecondModelPackage.TOP_DATA_CLASS__ANALOGBLOCK);
		}
		return analogblock;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<DigitalBlock> getDigitalblock() {
		if (digitalblock == null) {
			digitalblock = new EObjectContainmentEList<DigitalBlock>(DigitalBlock.class, this,
					SecondModelPackage.TOP_DATA_CLASS__DİGİTALBLOCK);
		}
		return digitalblock;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case SecondModelPackage.TOP_DATA_CLASS__LOCALVARİABLES:
			return ((InternalEList<?>) getLocalvariables()).basicRemove(otherEnd, msgs);
		case SecondModelPackage.TOP_DATA_CLASS__MOTORBLOCK:
			return ((InternalEList<?>) getMotorblock()).basicRemove(otherEnd, msgs);
		case SecondModelPackage.TOP_DATA_CLASS__SİGNALS:
			return ((InternalEList<?>) getSignals()).basicRemove(otherEnd, msgs);
		case SecondModelPackage.TOP_DATA_CLASS__SEQUENCEBLOCK:
			return ((InternalEList<?>) getSequenceblock()).basicRemove(otherEnd, msgs);
		case SecondModelPackage.TOP_DATA_CLASS__ANALOGBLOCK:
			return ((InternalEList<?>) getAnalogblock()).basicRemove(otherEnd, msgs);
		case SecondModelPackage.TOP_DATA_CLASS__DİGİTALBLOCK:
			return ((InternalEList<?>) getDigitalblock()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case SecondModelPackage.TOP_DATA_CLASS__HEADER_TEXT:
			return getHeaderText();
		case SecondModelPackage.TOP_DATA_CLASS__LOCALVARİABLES:
			return getLocalvariables();
		case SecondModelPackage.TOP_DATA_CLASS__MOTORBLOCK:
			return getMotorblock();
		case SecondModelPackage.TOP_DATA_CLASS__SİGNALS:
			return getSignals();
		case SecondModelPackage.TOP_DATA_CLASS__SEQUENCEBLOCK:
			return getSequenceblock();
		case SecondModelPackage.TOP_DATA_CLASS__ANALOGBLOCK:
			return getAnalogblock();
		case SecondModelPackage.TOP_DATA_CLASS__DİGİTALBLOCK:
			return getDigitalblock();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case SecondModelPackage.TOP_DATA_CLASS__HEADER_TEXT:
			setHeaderText((String) newValue);
			return;
		case SecondModelPackage.TOP_DATA_CLASS__LOCALVARİABLES:
			getLocalvariables().clear();
			getLocalvariables().addAll((Collection<? extends LocalVariables>) newValue);
			return;
		case SecondModelPackage.TOP_DATA_CLASS__MOTORBLOCK:
			getMotorblock().clear();
			getMotorblock().addAll((Collection<? extends MotorBlock>) newValue);
			return;
		case SecondModelPackage.TOP_DATA_CLASS__SİGNALS:
			getSignals().clear();
			getSignals().addAll((Collection<? extends Signals>) newValue);
			return;
		case SecondModelPackage.TOP_DATA_CLASS__SEQUENCEBLOCK:
			getSequenceblock().clear();
			getSequenceblock().addAll((Collection<? extends SequenceBlock>) newValue);
			return;
		case SecondModelPackage.TOP_DATA_CLASS__ANALOGBLOCK:
			getAnalogblock().clear();
			getAnalogblock().addAll((Collection<? extends AnalogBlock>) newValue);
			return;
		case SecondModelPackage.TOP_DATA_CLASS__DİGİTALBLOCK:
			getDigitalblock().clear();
			getDigitalblock().addAll((Collection<? extends DigitalBlock>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case SecondModelPackage.TOP_DATA_CLASS__HEADER_TEXT:
			setHeaderText(HEADER_TEXT_EDEFAULT);
			return;
		case SecondModelPackage.TOP_DATA_CLASS__LOCALVARİABLES:
			getLocalvariables().clear();
			return;
		case SecondModelPackage.TOP_DATA_CLASS__MOTORBLOCK:
			getMotorblock().clear();
			return;
		case SecondModelPackage.TOP_DATA_CLASS__SİGNALS:
			getSignals().clear();
			return;
		case SecondModelPackage.TOP_DATA_CLASS__SEQUENCEBLOCK:
			getSequenceblock().clear();
			return;
		case SecondModelPackage.TOP_DATA_CLASS__ANALOGBLOCK:
			getAnalogblock().clear();
			return;
		case SecondModelPackage.TOP_DATA_CLASS__DİGİTALBLOCK:
			getDigitalblock().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case SecondModelPackage.TOP_DATA_CLASS__HEADER_TEXT:
			return HEADER_TEXT_EDEFAULT == null ? headerText != null : !HEADER_TEXT_EDEFAULT.equals(headerText);
		case SecondModelPackage.TOP_DATA_CLASS__LOCALVARİABLES:
			return localvariables != null && !localvariables.isEmpty();
		case SecondModelPackage.TOP_DATA_CLASS__MOTORBLOCK:
			return motorblock != null && !motorblock.isEmpty();
		case SecondModelPackage.TOP_DATA_CLASS__SİGNALS:
			return signals != null && !signals.isEmpty();
		case SecondModelPackage.TOP_DATA_CLASS__SEQUENCEBLOCK:
			return sequenceblock != null && !sequenceblock.isEmpty();
		case SecondModelPackage.TOP_DATA_CLASS__ANALOGBLOCK:
			return analogblock != null && !analogblock.isEmpty();
		case SecondModelPackage.TOP_DATA_CLASS__DİGİTALBLOCK:
			return digitalblock != null && !digitalblock.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (HeaderText: ");
		result.append(headerText);
		result.append(')');
		return result.toString();
	}

} //TopDataClassImpl
