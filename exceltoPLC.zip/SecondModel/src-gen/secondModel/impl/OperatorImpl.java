/**
 */
package secondModel.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;
import secondModel.Operator;
import secondModel.SecondModelPackage;
import secondModel.SignalId;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Operator</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link secondModel.impl.OperatorImpl#getOperatorType <em>Operator Type</em>}</li>
 *   <li>{@link secondModel.impl.OperatorImpl#getIdNbr <em>Id Nbr</em>}</li>
 *   <li>{@link secondModel.impl.OperatorImpl#getSignalid <em>Signalid</em>}</li>
 *   <li>{@link secondModel.impl.OperatorImpl#getOperatorwithinoperator <em>Operatorwithinoperator</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OperatorImpl extends MinimalEObjectImpl.Container implements Operator {
	/**
	 * The default value of the '{@link #getOperatorType() <em>Operator Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOperatorType()
	 * @generated
	 * @ordered
	 */
	protected static final String OPERATOR_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOperatorType() <em>Operator Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOperatorType()
	 * @generated
	 * @ordered
	 */
	protected String operatorType = OPERATOR_TYPE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getIdNbr() <em>Id Nbr</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdNbr()
	 * @generated
	 * @ordered
	 */
	protected EList<String> ıdNbr;

	/**
	 * The cached value of the '{@link #getSignalid() <em>Signalid</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSignalid()
	 * @generated
	 * @ordered
	 */
	protected EList<SignalId> signalid;

	/**
	 * The cached value of the '{@link #getOperatorwithinoperator() <em>Operatorwithinoperator</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOperatorwithinoperator()
	 * @generated
	 * @ordered
	 */
	protected EList<Operator> operatorwithinoperator;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OperatorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SecondModelPackage.Literals.OPERATOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getOperatorType() {
		return operatorType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setOperatorType(String newOperatorType) {
		String oldOperatorType = operatorType;
		operatorType = newOperatorType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.OPERATOR__OPERATOR_TYPE,
					oldOperatorType, operatorType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<String> getIdNbr() {
		if (ıdNbr == null) {
			ıdNbr = new EDataTypeUniqueEList<String>(String.class, this, SecondModelPackage.OPERATOR__ID_NBR);
		}
		return ıdNbr;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<SignalId> getSignalid() {
		if (signalid == null) {
			signalid = new EObjectContainmentEList<SignalId>(SignalId.class, this,
					SecondModelPackage.OPERATOR__SİGNALİD);
		}
		return signalid;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Operator> getOperatorwithinoperator() {
		if (operatorwithinoperator == null) {
			operatorwithinoperator = new EObjectResolvingEList<Operator>(Operator.class, this,
					SecondModelPackage.OPERATOR__OPERATORWİTHİNOPERATOR);
		}
		return operatorwithinoperator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case SecondModelPackage.OPERATOR__SİGNALİD:
			return ((InternalEList<?>) getSignalid()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case SecondModelPackage.OPERATOR__OPERATOR_TYPE:
			return getOperatorType();
		case SecondModelPackage.OPERATOR__ID_NBR:
			return getIdNbr();
		case SecondModelPackage.OPERATOR__SİGNALİD:
			return getSignalid();
		case SecondModelPackage.OPERATOR__OPERATORWİTHİNOPERATOR:
			return getOperatorwithinoperator();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case SecondModelPackage.OPERATOR__OPERATOR_TYPE:
			setOperatorType((String) newValue);
			return;
		case SecondModelPackage.OPERATOR__ID_NBR:
			getIdNbr().clear();
			getIdNbr().addAll((Collection<? extends String>) newValue);
			return;
		case SecondModelPackage.OPERATOR__SİGNALİD:
			getSignalid().clear();
			getSignalid().addAll((Collection<? extends SignalId>) newValue);
			return;
		case SecondModelPackage.OPERATOR__OPERATORWİTHİNOPERATOR:
			getOperatorwithinoperator().clear();
			getOperatorwithinoperator().addAll((Collection<? extends Operator>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case SecondModelPackage.OPERATOR__OPERATOR_TYPE:
			setOperatorType(OPERATOR_TYPE_EDEFAULT);
			return;
		case SecondModelPackage.OPERATOR__ID_NBR:
			getIdNbr().clear();
			return;
		case SecondModelPackage.OPERATOR__SİGNALİD:
			getSignalid().clear();
			return;
		case SecondModelPackage.OPERATOR__OPERATORWİTHİNOPERATOR:
			getOperatorwithinoperator().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case SecondModelPackage.OPERATOR__OPERATOR_TYPE:
			return OPERATOR_TYPE_EDEFAULT == null ? operatorType != null : !OPERATOR_TYPE_EDEFAULT.equals(operatorType);
		case SecondModelPackage.OPERATOR__ID_NBR:
			return ıdNbr != null && !ıdNbr.isEmpty();
		case SecondModelPackage.OPERATOR__SİGNALİD:
			return signalid != null && !signalid.isEmpty();
		case SecondModelPackage.OPERATOR__OPERATORWİTHİNOPERATOR:
			return operatorwithinoperator != null && !operatorwithinoperator.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (OperatorType: ");
		result.append(operatorType);
		result.append(", IdNbr: ");
		result.append(ıdNbr);
		result.append(')');
		return result.toString();
	}

} //OperatorImpl
