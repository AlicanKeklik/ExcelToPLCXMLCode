/**
 */
package secondModel.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import secondModel.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class SecondModelFactoryImpl extends EFactoryImpl implements SecondModelFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static SecondModelFactory init() {
		try {
			SecondModelFactory theSecondModelFactory = (SecondModelFactory) EPackage.Registry.INSTANCE
					.getEFactory(SecondModelPackage.eNS_URI);
			if (theSecondModelFactory != null) {
				return theSecondModelFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new SecondModelFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SecondModelFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case SecondModelPackage.TOP_DATA_CLASS:
			return createTopDataClass();
		case SecondModelPackage.LOCAL_VARİABLES:
			return createLocalVariables();
		case SecondModelPackage.MOTOR_BLOCK:
			return createMotorBlock();
		case SecondModelPackage.SİGNALS:
			return createSignals();
		case SecondModelPackage.SİGNALS_INPUT:
			return createSignalsInput();
		case SecondModelPackage.SİGNALS_OUTPUT:
			return createSignalsOutput();
		case SecondModelPackage.POPULATİNG_INPUT:
			return createPopulatingInput();
		case SecondModelPackage.OPERATOR:
			return createOperator();
		case SecondModelPackage.SİGNAL_ID:
			return createSignalId();
		case SecondModelPackage.SEQUENCE_BLOCK:
			return createSequenceBlock();
		case SecondModelPackage.POPULATİNG_STEPS:
			return createPopulatingSteps();
		case SecondModelPackage.SEQ_OPERATOR:
			return createSeqOperator();
		case SecondModelPackage.SEQ_SİGNAL_ID:
			return createSeqSignalID();
		case SecondModelPackage.ANALOG_BLOCK:
			return createAnalogBlock();
		case SecondModelPackage.POPULATİNG_OUTPUT:
			return createPopulatingOutput();
		case SecondModelPackage.DİGİTAL_BLOCK:
			return createDigitalBlock();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TopDataClass createTopDataClass() {
		TopDataClassImpl topDataClass = new TopDataClassImpl();
		return topDataClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LocalVariables createLocalVariables() {
		LocalVariablesImpl localVariables = new LocalVariablesImpl();
		return localVariables;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MotorBlock createMotorBlock() {
		MotorBlockImpl motorBlock = new MotorBlockImpl();
		return motorBlock;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Signals createSignals() {
		SignalsImpl signals = new SignalsImpl();
		return signals;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SignalsInput createSignalsInput() {
		SignalsInputImpl signalsInput = new SignalsInputImpl();
		return signalsInput;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SignalsOutput createSignalsOutput() {
		SignalsOutputImpl signalsOutput = new SignalsOutputImpl();
		return signalsOutput;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PopulatingInput createPopulatingInput() {
		PopulatingInputImpl populatingInput = new PopulatingInputImpl();
		return populatingInput;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Operator createOperator() {
		OperatorImpl operator = new OperatorImpl();
		return operator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SignalId createSignalId() {
		SignalIdImpl signalId = new SignalIdImpl();
		return signalId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SequenceBlock createSequenceBlock() {
		SequenceBlockImpl sequenceBlock = new SequenceBlockImpl();
		return sequenceBlock;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PopulatingSteps createPopulatingSteps() {
		PopulatingStepsImpl populatingSteps = new PopulatingStepsImpl();
		return populatingSteps;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SeqOperator createSeqOperator() {
		SeqOperatorImpl seqOperator = new SeqOperatorImpl();
		return seqOperator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SeqSignalID createSeqSignalID() {
		SeqSignalIDImpl seqSignalID = new SeqSignalIDImpl();
		return seqSignalID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AnalogBlock createAnalogBlock() {
		AnalogBlockImpl analogBlock = new AnalogBlockImpl();
		return analogBlock;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PopulatingOutput createPopulatingOutput() {
		PopulatingOutputImpl populatingOutput = new PopulatingOutputImpl();
		return populatingOutput;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DigitalBlock createDigitalBlock() {
		DigitalBlockImpl digitalBlock = new DigitalBlockImpl();
		return digitalBlock;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SecondModelPackage getSecondModelPackage() {
		return (SecondModelPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static SecondModelPackage getPackage() {
		return SecondModelPackage.eINSTANCE;
	}

} //SecondModelFactoryImpl
