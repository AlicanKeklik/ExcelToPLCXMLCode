/**
 */
package secondModel.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;

import secondModel.SecondModelPackage;
import secondModel.SignalId;
import secondModel.Signals;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Signal Id</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link secondModel.impl.SignalIdImpl#getIdNbr <em>Id Nbr</em>}</li>
 *   <li>{@link secondModel.impl.SignalIdImpl#getOperatorsignals <em>Operatorsignals</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SignalIdImpl extends MinimalEObjectImpl.Container implements SignalId {
	/**
	 * The cached value of the '{@link #getIdNbr() <em>Id Nbr</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdNbr()
	 * @generated
	 * @ordered
	 */
	protected EList<String> ıdNbr;

	/**
	 * The cached value of the '{@link #getOperatorsignals() <em>Operatorsignals</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOperatorsignals()
	 * @generated
	 * @ordered
	 */
	protected Signals operatorsignals;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SignalIdImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SecondModelPackage.Literals.SİGNAL_ID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<String> getIdNbr() {
		if (ıdNbr == null) {
			ıdNbr = new EDataTypeUniqueEList<String>(String.class, this, SecondModelPackage.SİGNAL_ID__ID_NBR);
		}
		return ıdNbr;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Signals getOperatorsignals() {
		if (operatorsignals != null && operatorsignals.eIsProxy()) {
			InternalEObject oldOperatorsignals = (InternalEObject) operatorsignals;
			operatorsignals = (Signals) eResolveProxy(oldOperatorsignals);
			if (operatorsignals != oldOperatorsignals) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							SecondModelPackage.SİGNAL_ID__OPERATORSİGNALS, oldOperatorsignals, operatorsignals));
			}
		}
		return operatorsignals;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Signals basicGetOperatorsignals() {
		return operatorsignals;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setOperatorsignals(Signals newOperatorsignals) {
		Signals oldOperatorsignals = operatorsignals;
		operatorsignals = newOperatorsignals;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.SİGNAL_ID__OPERATORSİGNALS,
					oldOperatorsignals, operatorsignals));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case SecondModelPackage.SİGNAL_ID__ID_NBR:
			return getIdNbr();
		case SecondModelPackage.SİGNAL_ID__OPERATORSİGNALS:
			if (resolve)
				return getOperatorsignals();
			return basicGetOperatorsignals();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case SecondModelPackage.SİGNAL_ID__ID_NBR:
			getIdNbr().clear();
			getIdNbr().addAll((Collection<? extends String>) newValue);
			return;
		case SecondModelPackage.SİGNAL_ID__OPERATORSİGNALS:
			setOperatorsignals((Signals) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case SecondModelPackage.SİGNAL_ID__ID_NBR:
			getIdNbr().clear();
			return;
		case SecondModelPackage.SİGNAL_ID__OPERATORSİGNALS:
			setOperatorsignals((Signals) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case SecondModelPackage.SİGNAL_ID__ID_NBR:
			return ıdNbr != null && !ıdNbr.isEmpty();
		case SecondModelPackage.SİGNAL_ID__OPERATORSİGNALS:
			return operatorsignals != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (IdNbr: ");
		result.append(ıdNbr);
		result.append(')');
		return result.toString();
	}

} //SignalIdImpl
