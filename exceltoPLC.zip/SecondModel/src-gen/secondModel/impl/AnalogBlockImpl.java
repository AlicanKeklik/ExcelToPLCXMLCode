/**
 */
package secondModel.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import secondModel.AnalogBlock;
import secondModel.PopulatingInput;
import secondModel.PopulatingOutput;
import secondModel.SecondModelPackage;
import secondModel.Signals;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Analog Block</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link secondModel.impl.AnalogBlockImpl#getName <em>Name</em>}</li>
 *   <li>{@link secondModel.impl.AnalogBlockImpl#getDescription <em>Description</em>}</li>
 *   <li>{@link secondModel.impl.AnalogBlockImpl#getAnalogtosignals <em>Analogtosignals</em>}</li>
 *   <li>{@link secondModel.impl.AnalogBlockImpl#getPopulatinginput <em>Populatinginput</em>}</li>
 *   <li>{@link secondModel.impl.AnalogBlockImpl#getPopulatingoutput <em>Populatingoutput</em>}</li>
 *   <li>{@link secondModel.impl.AnalogBlockImpl#getBlockId <em>Block Id</em>}</li>
 *   <li>{@link secondModel.impl.AnalogBlockImpl#getSignalsIn <em>Signals In</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AnalogBlockImpl extends MinimalEObjectImpl.Container implements AnalogBlock {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected static final String DESCRİPTİON_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected String description = DESCRİPTİON_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAnalogtosignals() <em>Analogtosignals</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAnalogtosignals()
	 * @generated
	 * @ordered
	 */
	protected EList<Signals> analogtosignals;

	/**
	 * The cached value of the '{@link #getPopulatinginput() <em>Populatinginput</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPopulatinginput()
	 * @generated
	 * @ordered
	 */
	protected EList<PopulatingInput> populatinginput;

	/**
	 * The cached value of the '{@link #getPopulatingoutput() <em>Populatingoutput</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPopulatingoutput()
	 * @generated
	 * @ordered
	 */
	protected EList<PopulatingOutput> populatingoutput;

	/**
	 * The default value of the '{@link #getBlockId() <em>Block Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBlockId()
	 * @generated
	 * @ordered
	 */
	protected static final String BLOCK_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getBlockId() <em>Block Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBlockId()
	 * @generated
	 * @ordered
	 */
	protected String blockId = BLOCK_ID_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSignalsIn() <em>Signals In</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSignalsIn()
	 * @generated
	 * @ordered
	 */
	protected EList<String> signalsIn;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AnalogBlockImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SecondModelPackage.Literals.ANALOG_BLOCK;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.ANALOG_BLOCK__NAME, oldName,
					name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getDescription() {
		return description;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDescription(String newDescription) {
		String oldDescription = description;
		description = newDescription;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.ANALOG_BLOCK__DESCRİPTİON,
					oldDescription, description));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Signals> getAnalogtosignals() {
		if (analogtosignals == null) {
			analogtosignals = new EObjectContainmentEList<Signals>(Signals.class, this,
					SecondModelPackage.ANALOG_BLOCK__ANALOGTOSİGNALS);
		}
		return analogtosignals;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<PopulatingInput> getPopulatinginput() {
		if (populatinginput == null) {
			populatinginput = new EObjectContainmentEList<PopulatingInput>(PopulatingInput.class, this,
					SecondModelPackage.ANALOG_BLOCK__POPULATİNGİNPUT);
		}
		return populatinginput;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<PopulatingOutput> getPopulatingoutput() {
		if (populatingoutput == null) {
			populatingoutput = new EObjectContainmentEList<PopulatingOutput>(PopulatingOutput.class, this,
					SecondModelPackage.ANALOG_BLOCK__POPULATİNGOUTPUT);
		}
		return populatingoutput;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getBlockId() {
		return blockId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setBlockId(String newBlockId) {
		String oldBlockId = blockId;
		blockId = newBlockId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.ANALOG_BLOCK__BLOCK_ID, oldBlockId,
					blockId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<String> getSignalsIn() {
		if (signalsIn == null) {
			signalsIn = new EDataTypeUniqueEList<String>(String.class, this,
					SecondModelPackage.ANALOG_BLOCK__SİGNALS_IN);
		}
		return signalsIn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case SecondModelPackage.ANALOG_BLOCK__ANALOGTOSİGNALS:
			return ((InternalEList<?>) getAnalogtosignals()).basicRemove(otherEnd, msgs);
		case SecondModelPackage.ANALOG_BLOCK__POPULATİNGİNPUT:
			return ((InternalEList<?>) getPopulatinginput()).basicRemove(otherEnd, msgs);
		case SecondModelPackage.ANALOG_BLOCK__POPULATİNGOUTPUT:
			return ((InternalEList<?>) getPopulatingoutput()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case SecondModelPackage.ANALOG_BLOCK__NAME:
			return getName();
		case SecondModelPackage.ANALOG_BLOCK__DESCRİPTİON:
			return getDescription();
		case SecondModelPackage.ANALOG_BLOCK__ANALOGTOSİGNALS:
			return getAnalogtosignals();
		case SecondModelPackage.ANALOG_BLOCK__POPULATİNGİNPUT:
			return getPopulatinginput();
		case SecondModelPackage.ANALOG_BLOCK__POPULATİNGOUTPUT:
			return getPopulatingoutput();
		case SecondModelPackage.ANALOG_BLOCK__BLOCK_ID:
			return getBlockId();
		case SecondModelPackage.ANALOG_BLOCK__SİGNALS_IN:
			return getSignalsIn();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case SecondModelPackage.ANALOG_BLOCK__NAME:
			setName((String) newValue);
			return;
		case SecondModelPackage.ANALOG_BLOCK__DESCRİPTİON:
			setDescription((String) newValue);
			return;
		case SecondModelPackage.ANALOG_BLOCK__ANALOGTOSİGNALS:
			getAnalogtosignals().clear();
			getAnalogtosignals().addAll((Collection<? extends Signals>) newValue);
			return;
		case SecondModelPackage.ANALOG_BLOCK__POPULATİNGİNPUT:
			getPopulatinginput().clear();
			getPopulatinginput().addAll((Collection<? extends PopulatingInput>) newValue);
			return;
		case SecondModelPackage.ANALOG_BLOCK__POPULATİNGOUTPUT:
			getPopulatingoutput().clear();
			getPopulatingoutput().addAll((Collection<? extends PopulatingOutput>) newValue);
			return;
		case SecondModelPackage.ANALOG_BLOCK__BLOCK_ID:
			setBlockId((String) newValue);
			return;
		case SecondModelPackage.ANALOG_BLOCK__SİGNALS_IN:
			getSignalsIn().clear();
			getSignalsIn().addAll((Collection<? extends String>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case SecondModelPackage.ANALOG_BLOCK__NAME:
			setName(NAME_EDEFAULT);
			return;
		case SecondModelPackage.ANALOG_BLOCK__DESCRİPTİON:
			setDescription(DESCRİPTİON_EDEFAULT);
			return;
		case SecondModelPackage.ANALOG_BLOCK__ANALOGTOSİGNALS:
			getAnalogtosignals().clear();
			return;
		case SecondModelPackage.ANALOG_BLOCK__POPULATİNGİNPUT:
			getPopulatinginput().clear();
			return;
		case SecondModelPackage.ANALOG_BLOCK__POPULATİNGOUTPUT:
			getPopulatingoutput().clear();
			return;
		case SecondModelPackage.ANALOG_BLOCK__BLOCK_ID:
			setBlockId(BLOCK_ID_EDEFAULT);
			return;
		case SecondModelPackage.ANALOG_BLOCK__SİGNALS_IN:
			getSignalsIn().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case SecondModelPackage.ANALOG_BLOCK__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case SecondModelPackage.ANALOG_BLOCK__DESCRİPTİON:
			return DESCRİPTİON_EDEFAULT == null ? description != null : !DESCRİPTİON_EDEFAULT.equals(description);
		case SecondModelPackage.ANALOG_BLOCK__ANALOGTOSİGNALS:
			return analogtosignals != null && !analogtosignals.isEmpty();
		case SecondModelPackage.ANALOG_BLOCK__POPULATİNGİNPUT:
			return populatinginput != null && !populatinginput.isEmpty();
		case SecondModelPackage.ANALOG_BLOCK__POPULATİNGOUTPUT:
			return populatingoutput != null && !populatingoutput.isEmpty();
		case SecondModelPackage.ANALOG_BLOCK__BLOCK_ID:
			return BLOCK_ID_EDEFAULT == null ? blockId != null : !BLOCK_ID_EDEFAULT.equals(blockId);
		case SecondModelPackage.ANALOG_BLOCK__SİGNALS_IN:
			return signalsIn != null && !signalsIn.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(", Description: ");
		result.append(description);
		result.append(", blockId: ");
		result.append(blockId);
		result.append(", SignalsIn: ");
		result.append(signalsIn);
		result.append(')');
		return result.toString();
	}

} //AnalogBlockImpl
