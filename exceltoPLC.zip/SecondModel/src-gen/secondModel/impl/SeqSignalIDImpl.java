/**
 */
package secondModel.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;

import secondModel.SecondModelPackage;
import secondModel.SeqSignalID;
import secondModel.Signals;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Seq Signal ID</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link secondModel.impl.SeqSignalIDImpl#getIdNbr <em>Id Nbr</em>}</li>
 *   <li>{@link secondModel.impl.SeqSignalIDImpl#getSeqoperatorsignals <em>Seqoperatorsignals</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SeqSignalIDImpl extends MinimalEObjectImpl.Container implements SeqSignalID {
	/**
	 * The cached value of the '{@link #getIdNbr() <em>Id Nbr</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdNbr()
	 * @generated
	 * @ordered
	 */
	protected EList<String> ıdNbr;

	/**
	 * The cached value of the '{@link #getSeqoperatorsignals() <em>Seqoperatorsignals</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSeqoperatorsignals()
	 * @generated
	 * @ordered
	 */
	protected Signals seqoperatorsignals;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SeqSignalIDImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SecondModelPackage.Literals.SEQ_SİGNAL_ID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<String> getIdNbr() {
		if (ıdNbr == null) {
			ıdNbr = new EDataTypeUniqueEList<String>(String.class, this, SecondModelPackage.SEQ_SİGNAL_ID__ID_NBR);
		}
		return ıdNbr;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Signals getSeqoperatorsignals() {
		if (seqoperatorsignals != null && seqoperatorsignals.eIsProxy()) {
			InternalEObject oldSeqoperatorsignals = (InternalEObject) seqoperatorsignals;
			seqoperatorsignals = (Signals) eResolveProxy(oldSeqoperatorsignals);
			if (seqoperatorsignals != oldSeqoperatorsignals) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							SecondModelPackage.SEQ_SİGNAL_ID__SEQOPERATORSİGNALS, oldSeqoperatorsignals,
							seqoperatorsignals));
			}
		}
		return seqoperatorsignals;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Signals basicGetSeqoperatorsignals() {
		return seqoperatorsignals;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSeqoperatorsignals(Signals newSeqoperatorsignals) {
		Signals oldSeqoperatorsignals = seqoperatorsignals;
		seqoperatorsignals = newSeqoperatorsignals;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SecondModelPackage.SEQ_SİGNAL_ID__SEQOPERATORSİGNALS,
					oldSeqoperatorsignals, seqoperatorsignals));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case SecondModelPackage.SEQ_SİGNAL_ID__ID_NBR:
			return getIdNbr();
		case SecondModelPackage.SEQ_SİGNAL_ID__SEQOPERATORSİGNALS:
			if (resolve)
				return getSeqoperatorsignals();
			return basicGetSeqoperatorsignals();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case SecondModelPackage.SEQ_SİGNAL_ID__ID_NBR:
			getIdNbr().clear();
			getIdNbr().addAll((Collection<? extends String>) newValue);
			return;
		case SecondModelPackage.SEQ_SİGNAL_ID__SEQOPERATORSİGNALS:
			setSeqoperatorsignals((Signals) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case SecondModelPackage.SEQ_SİGNAL_ID__ID_NBR:
			getIdNbr().clear();
			return;
		case SecondModelPackage.SEQ_SİGNAL_ID__SEQOPERATORSİGNALS:
			setSeqoperatorsignals((Signals) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case SecondModelPackage.SEQ_SİGNAL_ID__ID_NBR:
			return ıdNbr != null && !ıdNbr.isEmpty();
		case SecondModelPackage.SEQ_SİGNAL_ID__SEQOPERATORSİGNALS:
			return seqoperatorsignals != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (IdNbr: ");
		result.append(ıdNbr);
		result.append(')');
		return result.toString();
	}

} //SeqSignalIDImpl
