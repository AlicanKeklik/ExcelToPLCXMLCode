/**
 */
package secondModel;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Digital Block</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link secondModel.DigitalBlock#getName <em>Name</em>}</li>
 *   <li>{@link secondModel.DigitalBlock#getDescription <em>Description</em>}</li>
 *   <li>{@link secondModel.DigitalBlock#getDigitaltosignals <em>Digitaltosignals</em>}</li>
 *   <li>{@link secondModel.DigitalBlock#getPopulatinginput <em>Populatinginput</em>}</li>
 *   <li>{@link secondModel.DigitalBlock#getPopulatingoutput <em>Populatingoutput</em>}</li>
 *   <li>{@link secondModel.DigitalBlock#getBlockId <em>Block Id</em>}</li>
 * </ul>
 *
 * @see secondModel.SecondModelPackage#getDigitalBlock()
 * @model
 * @generated
 */
public interface DigitalBlock extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see secondModel.SecondModelPackage#getDigitalBlock_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link secondModel.DigitalBlock#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Description</em>' attribute.
	 * @see #setDescription(String)
	 * @see secondModel.SecondModelPackage#getDigitalBlock_Description()
	 * @model
	 * @generated
	 */
	String getDescription();

	/**
	 * Sets the value of the '{@link secondModel.DigitalBlock#getDescription <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Description</em>' attribute.
	 * @see #getDescription()
	 * @generated
	 */
	void setDescription(String value);

	/**
	 * Returns the value of the '<em><b>Digitaltosignals</b></em>' containment reference list.
	 * The list contents are of type {@link secondModel.Signals}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Digitaltosignals</em>' containment reference list.
	 * @see secondModel.SecondModelPackage#getDigitalBlock_Digitaltosignals()
	 * @model containment="true"
	 * @generated
	 */
	EList<Signals> getDigitaltosignals();

	/**
	 * Returns the value of the '<em><b>Populatinginput</b></em>' containment reference list.
	 * The list contents are of type {@link secondModel.PopulatingInput}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Populatinginput</em>' containment reference list.
	 * @see secondModel.SecondModelPackage#getDigitalBlock_Populatinginput()
	 * @model containment="true"
	 * @generated
	 */
	EList<PopulatingInput> getPopulatinginput();

	/**
	 * Returns the value of the '<em><b>Populatingoutput</b></em>' containment reference list.
	 * The list contents are of type {@link secondModel.PopulatingOutput}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Populatingoutput</em>' containment reference list.
	 * @see secondModel.SecondModelPackage#getDigitalBlock_Populatingoutput()
	 * @model containment="true"
	 * @generated
	 */
	EList<PopulatingOutput> getPopulatingoutput();

	/**
	 * Returns the value of the '<em><b>Block Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Block Id</em>' attribute.
	 * @see #setBlockId(String)
	 * @see secondModel.SecondModelPackage#getDigitalBlock_BlockId()
	 * @model
	 * @generated
	 */
	String getBlockId();

	/**
	 * Sets the value of the '{@link secondModel.DigitalBlock#getBlockId <em>Block Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Block Id</em>' attribute.
	 * @see #getBlockId()
	 * @generated
	 */
	void setBlockId(String value);

} // DigitalBlock
