/**
 */
package secondModel;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see secondModel.SecondModelPackage
 * @generated
 */
public interface SecondModelFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	SecondModelFactory eINSTANCE = secondModel.impl.SecondModelFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Top Data Class</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Top Data Class</em>'.
	 * @generated
	 */
	TopDataClass createTopDataClass();

	/**
	 * Returns a new object of class '<em>Local Variables</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Local Variables</em>'.
	 * @generated
	 */
	LocalVariables createLocalVariables();

	/**
	 * Returns a new object of class '<em>Motor Block</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Motor Block</em>'.
	 * @generated
	 */
	MotorBlock createMotorBlock();

	/**
	 * Returns a new object of class '<em>Signals</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Signals</em>'.
	 * @generated
	 */
	Signals createSignals();

	/**
	 * Returns a new object of class '<em>Signals Input</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Signals Input</em>'.
	 * @generated
	 */
	SignalsInput createSignalsInput();

	/**
	 * Returns a new object of class '<em>Signals Output</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Signals Output</em>'.
	 * @generated
	 */
	SignalsOutput createSignalsOutput();

	/**
	 * Returns a new object of class '<em>Populating Input</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Populating Input</em>'.
	 * @generated
	 */
	PopulatingInput createPopulatingInput();

	/**
	 * Returns a new object of class '<em>Operator</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Operator</em>'.
	 * @generated
	 */
	Operator createOperator();

	/**
	 * Returns a new object of class '<em>Signal Id</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Signal Id</em>'.
	 * @generated
	 */
	SignalId createSignalId();

	/**
	 * Returns a new object of class '<em>Sequence Block</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sequence Block</em>'.
	 * @generated
	 */
	SequenceBlock createSequenceBlock();

	/**
	 * Returns a new object of class '<em>Populating Steps</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Populating Steps</em>'.
	 * @generated
	 */
	PopulatingSteps createPopulatingSteps();

	/**
	 * Returns a new object of class '<em>Seq Operator</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Seq Operator</em>'.
	 * @generated
	 */
	SeqOperator createSeqOperator();

	/**
	 * Returns a new object of class '<em>Seq Signal ID</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Seq Signal ID</em>'.
	 * @generated
	 */
	SeqSignalID createSeqSignalID();

	/**
	 * Returns a new object of class '<em>Analog Block</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Analog Block</em>'.
	 * @generated
	 */
	AnalogBlock createAnalogBlock();

	/**
	 * Returns a new object of class '<em>Populating Output</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Populating Output</em>'.
	 * @generated
	 */
	PopulatingOutput createPopulatingOutput();

	/**
	 * Returns a new object of class '<em>Digital Block</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Digital Block</em>'.
	 * @generated
	 */
	DigitalBlock createDigitalBlock();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	SecondModelPackage getSecondModelPackage();

} //SecondModelFactory
