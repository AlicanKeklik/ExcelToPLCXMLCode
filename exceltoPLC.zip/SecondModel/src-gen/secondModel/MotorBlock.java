/**
 */
package secondModel;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Motor Block</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link secondModel.MotorBlock#getName <em>Name</em>}</li>
 *   <li>{@link secondModel.MotorBlock#getDescription <em>Description</em>}</li>
 *   <li>{@link secondModel.MotorBlock#getSignalsIn <em>Signals In</em>}</li>
 *   <li>{@link secondModel.MotorBlock#getSignals <em>Signals</em>}</li>
 *   <li>{@link secondModel.MotorBlock#getType <em>Type</em>}</li>
 *   <li>{@link secondModel.MotorBlock#getLocalvariables <em>Localvariables</em>}</li>
 *   <li>{@link secondModel.MotorBlock#getSignalsinput <em>Signalsinput</em>}</li>
 *   <li>{@link secondModel.MotorBlock#getSignalsoutput <em>Signalsoutput</em>}</li>
 *   <li>{@link secondModel.MotorBlock#getIdNbr <em>Id Nbr</em>}</li>
 *   <li>{@link secondModel.MotorBlock#getPopulatinginput <em>Populatinginput</em>}</li>
 *   <li>{@link secondModel.MotorBlock#getPopulatingoutput <em>Populatingoutput</em>}</li>
 * </ul>
 *
 * @see secondModel.SecondModelPackage#getMotorBlock()
 * @model
 * @generated
 */
public interface MotorBlock extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see secondModel.SecondModelPackage#getMotorBlock_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link secondModel.MotorBlock#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Description</em>' attribute.
	 * @see #setDescription(String)
	 * @see secondModel.SecondModelPackage#getMotorBlock_Description()
	 * @model
	 * @generated
	 */
	String getDescription();

	/**
	 * Sets the value of the '{@link secondModel.MotorBlock#getDescription <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Description</em>' attribute.
	 * @see #getDescription()
	 * @generated
	 */
	void setDescription(String value);

	/**
	 * Returns the value of the '<em><b>Signals In</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Signals In</em>' attribute list.
	 * @see secondModel.SecondModelPackage#getMotorBlock_SignalsIn()
	 * @model
	 * @generated
	 */
	EList<String> getSignalsIn();

	/**
	 * Returns the value of the '<em><b>Signals</b></em>' containment reference list.
	 * The list contents are of type {@link secondModel.Signals}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Signals</em>' containment reference list.
	 * @see secondModel.SecondModelPackage#getMotorBlock_Signals()
	 * @model containment="true"
	 * @generated
	 */
	EList<Signals> getSignals();

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see #setType(String)
	 * @see secondModel.SecondModelPackage#getMotorBlock_Type()
	 * @model
	 * @generated
	 */
	String getType();

	/**
	 * Sets the value of the '{@link secondModel.MotorBlock#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see #getType()
	 * @generated
	 */
	void setType(String value);

	/**
	 * Returns the value of the '<em><b>Localvariables</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Localvariables</em>' containment reference.
	 * @see #setLocalvariables(LocalVariables)
	 * @see secondModel.SecondModelPackage#getMotorBlock_Localvariables()
	 * @model containment="true" required="true"
	 * @generated
	 */
	LocalVariables getLocalvariables();

	/**
	 * Sets the value of the '{@link secondModel.MotorBlock#getLocalvariables <em>Localvariables</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Localvariables</em>' containment reference.
	 * @see #getLocalvariables()
	 * @generated
	 */
	void setLocalvariables(LocalVariables value);

	/**
	 * Returns the value of the '<em><b>Signalsinput</b></em>' containment reference list.
	 * The list contents are of type {@link secondModel.SignalsInput}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Signalsinput</em>' containment reference list.
	 * @see secondModel.SecondModelPackage#getMotorBlock_Signalsinput()
	 * @model containment="true"
	 * @generated
	 */
	EList<SignalsInput> getSignalsinput();

	/**
	 * Returns the value of the '<em><b>Signalsoutput</b></em>' containment reference list.
	 * The list contents are of type {@link secondModel.SignalsOutput}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Signalsoutput</em>' containment reference list.
	 * @see secondModel.SecondModelPackage#getMotorBlock_Signalsoutput()
	 * @model containment="true"
	 * @generated
	 */
	EList<SignalsOutput> getSignalsoutput();

	/**
	 * Returns the value of the '<em><b>Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id Nbr</em>' attribute.
	 * @see #setIdNbr(String)
	 * @see secondModel.SecondModelPackage#getMotorBlock_IdNbr()
	 * @model
	 * @generated
	 */
	String getIdNbr();

	/**
	 * Sets the value of the '{@link secondModel.MotorBlock#getIdNbr <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id Nbr</em>' attribute.
	 * @see #getIdNbr()
	 * @generated
	 */
	void setIdNbr(String value);

	/**
	 * Returns the value of the '<em><b>Populatinginput</b></em>' containment reference list.
	 * The list contents are of type {@link secondModel.PopulatingInput}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Populatinginput</em>' containment reference list.
	 * @see secondModel.SecondModelPackage#getMotorBlock_Populatinginput()
	 * @model containment="true"
	 * @generated
	 */
	EList<PopulatingInput> getPopulatinginput();

	/**
	 * Returns the value of the '<em><b>Populatingoutput</b></em>' containment reference list.
	 * The list contents are of type {@link secondModel.PopulatingOutput}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Populatingoutput</em>' containment reference list.
	 * @see secondModel.SecondModelPackage#getMotorBlock_Populatingoutput()
	 * @model containment="true"
	 * @generated
	 */
	EList<PopulatingOutput> getPopulatingoutput();

} // MotorBlock
