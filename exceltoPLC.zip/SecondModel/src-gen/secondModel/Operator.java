/**
 */
package secondModel;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Operator</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link secondModel.Operator#getOperatorType <em>Operator Type</em>}</li>
 *   <li>{@link secondModel.Operator#getIdNbr <em>Id Nbr</em>}</li>
 *   <li>{@link secondModel.Operator#getSignalid <em>Signalid</em>}</li>
 *   <li>{@link secondModel.Operator#getOperatorwithinoperator <em>Operatorwithinoperator</em>}</li>
 * </ul>
 *
 * @see secondModel.SecondModelPackage#getOperator()
 * @model
 * @generated
 */
public interface Operator extends EObject {
	/**
	 * Returns the value of the '<em><b>Operator Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operator Type</em>' attribute.
	 * @see #setOperatorType(String)
	 * @see secondModel.SecondModelPackage#getOperator_OperatorType()
	 * @model
	 * @generated
	 */
	String getOperatorType();

	/**
	 * Sets the value of the '{@link secondModel.Operator#getOperatorType <em>Operator Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Operator Type</em>' attribute.
	 * @see #getOperatorType()
	 * @generated
	 */
	void setOperatorType(String value);

	/**
	 * Returns the value of the '<em><b>Id Nbr</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id Nbr</em>' attribute list.
	 * @see secondModel.SecondModelPackage#getOperator_IdNbr()
	 * @model upper="100"
	 * @generated
	 */
	EList<String> getIdNbr();

	/**
	 * Returns the value of the '<em><b>Signalid</b></em>' containment reference list.
	 * The list contents are of type {@link secondModel.SignalId}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Signalid</em>' containment reference list.
	 * @see secondModel.SecondModelPackage#getOperator_Signalid()
	 * @model containment="true"
	 * @generated
	 */
	EList<SignalId> getSignalid();

	/**
	 * Returns the value of the '<em><b>Operatorwithinoperator</b></em>' reference list.
	 * The list contents are of type {@link secondModel.Operator}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operatorwithinoperator</em>' reference list.
	 * @see secondModel.SecondModelPackage#getOperator_Operatorwithinoperator()
	 * @model
	 * @generated
	 */
	EList<Operator> getOperatorwithinoperator();

} // Operator
