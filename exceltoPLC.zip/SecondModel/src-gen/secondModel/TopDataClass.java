/**
 */
package secondModel;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Top Data Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link secondModel.TopDataClass#getHeaderText <em>Header Text</em>}</li>
 *   <li>{@link secondModel.TopDataClass#getLocalvariables <em>Localvariables</em>}</li>
 *   <li>{@link secondModel.TopDataClass#getMotorblock <em>Motorblock</em>}</li>
 *   <li>{@link secondModel.TopDataClass#getSignals <em>Signals</em>}</li>
 *   <li>{@link secondModel.TopDataClass#getSequenceblock <em>Sequenceblock</em>}</li>
 *   <li>{@link secondModel.TopDataClass#getAnalogblock <em>Analogblock</em>}</li>
 *   <li>{@link secondModel.TopDataClass#getDigitalblock <em>Digitalblock</em>}</li>
 * </ul>
 *
 * @see secondModel.SecondModelPackage#getTopDataClass()
 * @model
 * @generated
 */
public interface TopDataClass extends EObject {
	/**
	 * Returns the value of the '<em><b>Header Text</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Header Text</em>' attribute.
	 * @see #setHeaderText(String)
	 * @see secondModel.SecondModelPackage#getTopDataClass_HeaderText()
	 * @model
	 * @generated
	 */
	String getHeaderText();

	/**
	 * Sets the value of the '{@link secondModel.TopDataClass#getHeaderText <em>Header Text</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Header Text</em>' attribute.
	 * @see #getHeaderText()
	 * @generated
	 */
	void setHeaderText(String value);

	/**
	 * Returns the value of the '<em><b>Localvariables</b></em>' containment reference list.
	 * The list contents are of type {@link secondModel.LocalVariables}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Localvariables</em>' containment reference list.
	 * @see secondModel.SecondModelPackage#getTopDataClass_Localvariables()
	 * @model containment="true"
	 * @generated
	 */
	EList<LocalVariables> getLocalvariables();

	/**
	 * Returns the value of the '<em><b>Motorblock</b></em>' containment reference list.
	 * The list contents are of type {@link secondModel.MotorBlock}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Motorblock</em>' containment reference list.
	 * @see secondModel.SecondModelPackage#getTopDataClass_Motorblock()
	 * @model containment="true"
	 * @generated
	 */
	EList<MotorBlock> getMotorblock();

	/**
	 * Returns the value of the '<em><b>Signals</b></em>' containment reference list.
	 * The list contents are of type {@link secondModel.Signals}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Signals</em>' containment reference list.
	 * @see secondModel.SecondModelPackage#getTopDataClass_Signals()
	 * @model containment="true"
	 * @generated
	 */
	EList<Signals> getSignals();

	/**
	 * Returns the value of the '<em><b>Sequenceblock</b></em>' containment reference list.
	 * The list contents are of type {@link secondModel.SequenceBlock}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sequenceblock</em>' containment reference list.
	 * @see secondModel.SecondModelPackage#getTopDataClass_Sequenceblock()
	 * @model containment="true"
	 * @generated
	 */
	EList<SequenceBlock> getSequenceblock();

	/**
	 * Returns the value of the '<em><b>Analogblock</b></em>' containment reference list.
	 * The list contents are of type {@link secondModel.AnalogBlock}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Analogblock</em>' containment reference list.
	 * @see secondModel.SecondModelPackage#getTopDataClass_Analogblock()
	 * @model containment="true"
	 * @generated
	 */
	EList<AnalogBlock> getAnalogblock();

	/**
	 * Returns the value of the '<em><b>Digitalblock</b></em>' containment reference list.
	 * The list contents are of type {@link secondModel.DigitalBlock}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Digitalblock</em>' containment reference list.
	 * @see secondModel.SecondModelPackage#getTopDataClass_Digitalblock()
	 * @model containment="true"
	 * @generated
	 */
	EList<DigitalBlock> getDigitalblock();

} // TopDataClass
