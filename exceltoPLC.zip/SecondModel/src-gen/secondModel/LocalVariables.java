/**
 */
package secondModel;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Local Variables</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link secondModel.LocalVariables#getName <em>Name</em>}</li>
 *   <li>{@link secondModel.LocalVariables#getIdNbr <em>Id Nbr</em>}</li>
 *   <li>{@link secondModel.LocalVariables#getHardwareReference <em>Hardware Reference</em>}</li>
 *   <li>{@link secondModel.LocalVariables#getSignals <em>Signals</em>}</li>
 *   <li>{@link secondModel.LocalVariables#getLocalvariablesforanalog <em>Localvariablesforanalog</em>}</li>
 *   <li>{@link secondModel.LocalVariables#getLocalvariablesfordigital <em>Localvariablesfordigital</em>}</li>
 * </ul>
 *
 * @see secondModel.SecondModelPackage#getLocalVariables()
 * @model
 * @generated
 */
public interface LocalVariables extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see secondModel.SecondModelPackage#getLocalVariables_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link secondModel.LocalVariables#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Hardware Reference</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hardware Reference</em>' attribute.
	 * @see #setHardwareReference(String)
	 * @see secondModel.SecondModelPackage#getLocalVariables_HardwareReference()
	 * @model
	 * @generated
	 */
	String getHardwareReference();

	/**
	 * Sets the value of the '{@link secondModel.LocalVariables#getHardwareReference <em>Hardware Reference</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Hardware Reference</em>' attribute.
	 * @see #getHardwareReference()
	 * @generated
	 */
	void setHardwareReference(String value);

	/**
	 * Returns the value of the '<em><b>Signals</b></em>' containment reference list.
	 * The list contents are of type {@link secondModel.Signals}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Signals</em>' containment reference list.
	 * @see secondModel.SecondModelPackage#getLocalVariables_Signals()
	 * @model containment="true"
	 * @generated
	 */
	EList<Signals> getSignals();

	/**
	 * Returns the value of the '<em><b>Localvariablesforanalog</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Localvariablesforanalog</em>' containment reference.
	 * @see #setLocalvariablesforanalog(AnalogBlock)
	 * @see secondModel.SecondModelPackage#getLocalVariables_Localvariablesforanalog()
	 * @model containment="true" required="true"
	 * @generated
	 */
	AnalogBlock getLocalvariablesforanalog();

	/**
	 * Sets the value of the '{@link secondModel.LocalVariables#getLocalvariablesforanalog <em>Localvariablesforanalog</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Localvariablesforanalog</em>' containment reference.
	 * @see #getLocalvariablesforanalog()
	 * @generated
	 */
	void setLocalvariablesforanalog(AnalogBlock value);

	/**
	 * Returns the value of the '<em><b>Localvariablesfordigital</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Localvariablesfordigital</em>' containment reference.
	 * @see #setLocalvariablesfordigital(DigitalBlock)
	 * @see secondModel.SecondModelPackage#getLocalVariables_Localvariablesfordigital()
	 * @model containment="true" required="true"
	 * @generated
	 */
	DigitalBlock getLocalvariablesfordigital();

	/**
	 * Sets the value of the '{@link secondModel.LocalVariables#getLocalvariablesfordigital <em>Localvariablesfordigital</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Localvariablesfordigital</em>' containment reference.
	 * @see #getLocalvariablesfordigital()
	 * @generated
	 */
	void setLocalvariablesfordigital(DigitalBlock value);

	/**
	 * Returns the value of the '<em><b>Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id Nbr</em>' attribute.
	 * @see #setIdNbr(int)
	 * @see secondModel.SecondModelPackage#getLocalVariables_IdNbr()
	 * @model
	 * @generated
	 */
	int getIdNbr();

	/**
	 * Sets the value of the '{@link secondModel.LocalVariables#getIdNbr <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id Nbr</em>' attribute.
	 * @see #getIdNbr()
	 * @generated
	 */
	void setIdNbr(int value);

} // LocalVariables
