/**
 */
package secondModel;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sequence Block</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link secondModel.SequenceBlock#getName <em>Name</em>}</li>
 *   <li>{@link secondModel.SequenceBlock#getDescription <em>Description</em>}</li>
 *   <li>{@link secondModel.SequenceBlock#getPopulatingsteps <em>Populatingsteps</em>}</li>
 *   <li>{@link secondModel.SequenceBlock#getStepName <em>Step Name</em>}</li>
 *   <li>{@link secondModel.SequenceBlock#getIdNbr <em>Id Nbr</em>}</li>
 * </ul>
 *
 * @see secondModel.SecondModelPackage#getSequenceBlock()
 * @model
 * @generated
 */
public interface SequenceBlock extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see secondModel.SecondModelPackage#getSequenceBlock_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link secondModel.SequenceBlock#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Description</em>' attribute.
	 * @see #setDescription(String)
	 * @see secondModel.SecondModelPackage#getSequenceBlock_Description()
	 * @model
	 * @generated
	 */
	String getDescription();

	/**
	 * Sets the value of the '{@link secondModel.SequenceBlock#getDescription <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Description</em>' attribute.
	 * @see #getDescription()
	 * @generated
	 */
	void setDescription(String value);

	/**
	 * Returns the value of the '<em><b>Populatingsteps</b></em>' containment reference list.
	 * The list contents are of type {@link secondModel.PopulatingSteps}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Populatingsteps</em>' containment reference list.
	 * @see secondModel.SecondModelPackage#getSequenceBlock_Populatingsteps()
	 * @model containment="true"
	 * @generated
	 */
	EList<PopulatingSteps> getPopulatingsteps();

	/**
	 * Returns the value of the '<em><b>Step Name</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Step Name</em>' attribute list.
	 * @see secondModel.SecondModelPackage#getSequenceBlock_StepName()
	 * @model upper="100"
	 * @generated
	 */
	EList<String> getStepName();

	/**
	 * Returns the value of the '<em><b>Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id Nbr</em>' attribute.
	 * @see #setIdNbr(String)
	 * @see secondModel.SecondModelPackage#getSequenceBlock_IdNbr()
	 * @model
	 * @generated
	 */
	String getIdNbr();

	/**
	 * Sets the value of the '{@link secondModel.SequenceBlock#getIdNbr <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id Nbr</em>' attribute.
	 * @see #getIdNbr()
	 * @generated
	 */
	void setIdNbr(String value);

} // SequenceBlock
