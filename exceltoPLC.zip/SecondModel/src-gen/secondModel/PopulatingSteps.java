/**
 */
package secondModel;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Populating Steps</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link secondModel.PopulatingSteps#getSignals <em>Signals</em>}</li>
 *   <li>{@link secondModel.PopulatingSteps#getSeqoperator <em>Seqoperator</em>}</li>
 *   <li>{@link secondModel.PopulatingSteps#getSignalName <em>Signal Name</em>}</li>
 *   <li>{@link secondModel.PopulatingSteps#getInputName <em>Input Name</em>}</li>
 *   <li>{@link secondModel.PopulatingSteps#getIdNbr <em>Id Nbr</em>}</li>
 *   <li>{@link secondModel.PopulatingSteps#getNextIdNbr <em>Next Id Nbr</em>}</li>
 *   <li>{@link secondModel.PopulatingSteps#getTransitionIdNbr <em>Transition Id Nbr</em>}</li>
 *   <li>{@link secondModel.PopulatingSteps#getLastTransitionIdNbr <em>Last Transition Id Nbr</em>}</li>
 *   <li>{@link secondModel.PopulatingSteps#getLastTransitionStepNbr <em>Last Transition Step Nbr</em>}</li>
 * </ul>
 *
 * @see secondModel.SecondModelPackage#getPopulatingSteps()
 * @model
 * @generated
 */
public interface PopulatingSteps extends EObject {
	/**
	 * Returns the value of the '<em><b>Signals</b></em>' reference list.
	 * The list contents are of type {@link secondModel.Signals}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Signals</em>' reference list.
	 * @see secondModel.SecondModelPackage#getPopulatingSteps_Signals()
	 * @model
	 * @generated
	 */
	EList<Signals> getSignals();

	/**
	 * Returns the value of the '<em><b>Seqoperator</b></em>' containment reference list.
	 * The list contents are of type {@link secondModel.SeqOperator}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Seqoperator</em>' containment reference list.
	 * @see secondModel.SecondModelPackage#getPopulatingSteps_Seqoperator()
	 * @model containment="true"
	 * @generated
	 */
	EList<SeqOperator> getSeqoperator();

	/**
	 * Returns the value of the '<em><b>Signal Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Signal Name</em>' attribute.
	 * @see #setSignalName(String)
	 * @see secondModel.SecondModelPackage#getPopulatingSteps_SignalName()
	 * @model
	 * @generated
	 */
	String getSignalName();

	/**
	 * Sets the value of the '{@link secondModel.PopulatingSteps#getSignalName <em>Signal Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Signal Name</em>' attribute.
	 * @see #getSignalName()
	 * @generated
	 */
	void setSignalName(String value);

	/**
	 * Returns the value of the '<em><b>Input Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Input Name</em>' attribute.
	 * @see #setInputName(String)
	 * @see secondModel.SecondModelPackage#getPopulatingSteps_InputName()
	 * @model
	 * @generated
	 */
	String getInputName();

	/**
	 * Sets the value of the '{@link secondModel.PopulatingSteps#getInputName <em>Input Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Input Name</em>' attribute.
	 * @see #getInputName()
	 * @generated
	 */
	void setInputName(String value);

	/**
	 * Returns the value of the '<em><b>Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id Nbr</em>' attribute.
	 * @see #setIdNbr(String)
	 * @see secondModel.SecondModelPackage#getPopulatingSteps_IdNbr()
	 * @model
	 * @generated
	 */
	String getIdNbr();

	/**
	 * Sets the value of the '{@link secondModel.PopulatingSteps#getIdNbr <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id Nbr</em>' attribute.
	 * @see #getIdNbr()
	 * @generated
	 */
	void setIdNbr(String value);

	/**
	 * Returns the value of the '<em><b>Next Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Next Id Nbr</em>' attribute.
	 * @see #setNextIdNbr(String)
	 * @see secondModel.SecondModelPackage#getPopulatingSteps_NextIdNbr()
	 * @model
	 * @generated
	 */
	String getNextIdNbr();

	/**
	 * Sets the value of the '{@link secondModel.PopulatingSteps#getNextIdNbr <em>Next Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Next Id Nbr</em>' attribute.
	 * @see #getNextIdNbr()
	 * @generated
	 */
	void setNextIdNbr(String value);

	/**
	 * Returns the value of the '<em><b>Transition Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transition Id Nbr</em>' attribute.
	 * @see #setTransitionIdNbr(String)
	 * @see secondModel.SecondModelPackage#getPopulatingSteps_TransitionIdNbr()
	 * @model
	 * @generated
	 */
	String getTransitionIdNbr();

	/**
	 * Sets the value of the '{@link secondModel.PopulatingSteps#getTransitionIdNbr <em>Transition Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Transition Id Nbr</em>' attribute.
	 * @see #getTransitionIdNbr()
	 * @generated
	 */
	void setTransitionIdNbr(String value);

	/**
	 * Returns the value of the '<em><b>Last Transition Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Last Transition Id Nbr</em>' attribute.
	 * @see #setLastTransitionIdNbr(String)
	 * @see secondModel.SecondModelPackage#getPopulatingSteps_LastTransitionIdNbr()
	 * @model
	 * @generated
	 */
	String getLastTransitionIdNbr();

	/**
	 * Sets the value of the '{@link secondModel.PopulatingSteps#getLastTransitionIdNbr <em>Last Transition Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Last Transition Id Nbr</em>' attribute.
	 * @see #getLastTransitionIdNbr()
	 * @generated
	 */
	void setLastTransitionIdNbr(String value);

	/**
	 * Returns the value of the '<em><b>Last Transition Step Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Last Transition Step Nbr</em>' attribute.
	 * @see #setLastTransitionStepNbr(String)
	 * @see secondModel.SecondModelPackage#getPopulatingSteps_LastTransitionStepNbr()
	 * @model
	 * @generated
	 */
	String getLastTransitionStepNbr();

	/**
	 * Sets the value of the '{@link secondModel.PopulatingSteps#getLastTransitionStepNbr <em>Last Transition Step Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Last Transition Step Nbr</em>' attribute.
	 * @see #getLastTransitionStepNbr()
	 * @generated
	 */
	void setLastTransitionStepNbr(String value);

} // PopulatingSteps
