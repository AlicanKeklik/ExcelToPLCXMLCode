/**
 */
package secondModel;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Signals</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link secondModel.Signals#getName <em>Name</em>}</li>
 *   <li>{@link secondModel.Signals#getSignalType <em>Signal Type</em>}</li>
 *   <li>{@link secondModel.Signals#getIdNbr <em>Id Nbr</em>}</li>
 * </ul>
 *
 * @see secondModel.SecondModelPackage#getSignals()
 * @model
 * @generated
 */
public interface Signals extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see secondModel.SecondModelPackage#getSignals_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link secondModel.Signals#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Signal Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Signal Type</em>' attribute.
	 * @see #setSignalType(String)
	 * @see secondModel.SecondModelPackage#getSignals_SignalType()
	 * @model
	 * @generated
	 */
	String getSignalType();

	/**
	 * Sets the value of the '{@link secondModel.Signals#getSignalType <em>Signal Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Signal Type</em>' attribute.
	 * @see #getSignalType()
	 * @generated
	 */
	void setSignalType(String value);

	/**
	 * Returns the value of the '<em><b>Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id Nbr</em>' attribute.
	 * @see #setIdNbr(String)
	 * @see secondModel.SecondModelPackage#getSignals_IdNbr()
	 * @model
	 * @generated
	 */
	String getIdNbr();

	/**
	 * Sets the value of the '{@link secondModel.Signals#getIdNbr <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id Nbr</em>' attribute.
	 * @see #getIdNbr()
	 * @generated
	 */
	void setIdNbr(String value);

} // Signals
