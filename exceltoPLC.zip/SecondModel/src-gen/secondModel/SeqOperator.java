/**
 */
package secondModel;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Seq Operator</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link secondModel.SeqOperator#getOperatorType <em>Operator Type</em>}</li>
 *   <li>{@link secondModel.SeqOperator#getIdNbr <em>Id Nbr</em>}</li>
 *   <li>{@link secondModel.SeqOperator#getSeqoperatorwithinoperator <em>Seqoperatorwithinoperator</em>}</li>
 *   <li>{@link secondModel.SeqOperator#getSeqsignalid <em>Seqsignalid</em>}</li>
 *   <li>{@link secondModel.SeqOperator#getConcatOperator <em>Concat Operator</em>}</li>
 * </ul>
 *
 * @see secondModel.SecondModelPackage#getSeqOperator()
 * @model
 * @generated
 */
public interface SeqOperator extends EObject {
	/**
	 * Returns the value of the '<em><b>Operator Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operator Type</em>' attribute.
	 * @see #setOperatorType(String)
	 * @see secondModel.SecondModelPackage#getSeqOperator_OperatorType()
	 * @model
	 * @generated
	 */
	String getOperatorType();

	/**
	 * Sets the value of the '{@link secondModel.SeqOperator#getOperatorType <em>Operator Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Operator Type</em>' attribute.
	 * @see #getOperatorType()
	 * @generated
	 */
	void setOperatorType(String value);

	/**
	 * Returns the value of the '<em><b>Id Nbr</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id Nbr</em>' attribute list.
	 * @see secondModel.SecondModelPackage#getSeqOperator_IdNbr()
	 * @model upper="100"
	 * @generated
	 */
	EList<String> getIdNbr();

	/**
	 * Returns the value of the '<em><b>Seqoperatorwithinoperator</b></em>' reference list.
	 * The list contents are of type {@link secondModel.SeqOperator}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Seqoperatorwithinoperator</em>' reference list.
	 * @see secondModel.SecondModelPackage#getSeqOperator_Seqoperatorwithinoperator()
	 * @model
	 * @generated
	 */
	EList<SeqOperator> getSeqoperatorwithinoperator();

	/**
	 * Returns the value of the '<em><b>Seqsignalid</b></em>' containment reference list.
	 * The list contents are of type {@link secondModel.SeqSignalID}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Seqsignalid</em>' containment reference list.
	 * @see secondModel.SecondModelPackage#getSeqOperator_Seqsignalid()
	 * @model containment="true"
	 * @generated
	 */
	EList<SeqSignalID> getSeqsignalid();

	/**
	 * Returns the value of the '<em><b>Concat Operator</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Concat Operator</em>' attribute.
	 * @see #setConcatOperator(String)
	 * @see secondModel.SecondModelPackage#getSeqOperator_ConcatOperator()
	 * @model
	 * @generated
	 */
	String getConcatOperator();

	/**
	 * Sets the value of the '{@link secondModel.SeqOperator#getConcatOperator <em>Concat Operator</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Concat Operator</em>' attribute.
	 * @see #getConcatOperator()
	 * @generated
	 */
	void setConcatOperator(String value);

} // SeqOperator
