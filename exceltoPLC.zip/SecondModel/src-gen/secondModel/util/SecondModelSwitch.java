/**
 */
package secondModel.util;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

import secondModel.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see secondModel.SecondModelPackage
 * @generated
 */
public class SecondModelSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static SecondModelPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SecondModelSwitch() {
		if (modelPackage == null) {
			modelPackage = SecondModelPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case SecondModelPackage.TOP_DATA_CLASS: {
			TopDataClass topDataClass = (TopDataClass) theEObject;
			T result = caseTopDataClass(topDataClass);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SecondModelPackage.LOCAL_VARİABLES: {
			LocalVariables localVariables = (LocalVariables) theEObject;
			T result = caseLocalVariables(localVariables);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SecondModelPackage.MOTOR_BLOCK: {
			MotorBlock motorBlock = (MotorBlock) theEObject;
			T result = caseMotorBlock(motorBlock);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SecondModelPackage.SİGNALS: {
			Signals signals = (Signals) theEObject;
			T result = caseSignals(signals);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SecondModelPackage.SİGNALS_INPUT: {
			SignalsInput signalsInput = (SignalsInput) theEObject;
			T result = caseSignalsInput(signalsInput);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SecondModelPackage.SİGNALS_OUTPUT: {
			SignalsOutput signalsOutput = (SignalsOutput) theEObject;
			T result = caseSignalsOutput(signalsOutput);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SecondModelPackage.POPULATİNG_INPUT: {
			PopulatingInput populatingInput = (PopulatingInput) theEObject;
			T result = casePopulatingInput(populatingInput);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SecondModelPackage.OPERATOR: {
			Operator operator = (Operator) theEObject;
			T result = caseOperator(operator);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SecondModelPackage.SİGNAL_ID: {
			SignalId signalId = (SignalId) theEObject;
			T result = caseSignalId(signalId);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SecondModelPackage.SEQUENCE_BLOCK: {
			SequenceBlock sequenceBlock = (SequenceBlock) theEObject;
			T result = caseSequenceBlock(sequenceBlock);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SecondModelPackage.POPULATİNG_STEPS: {
			PopulatingSteps populatingSteps = (PopulatingSteps) theEObject;
			T result = casePopulatingSteps(populatingSteps);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SecondModelPackage.SEQ_OPERATOR: {
			SeqOperator seqOperator = (SeqOperator) theEObject;
			T result = caseSeqOperator(seqOperator);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SecondModelPackage.SEQ_SİGNAL_ID: {
			SeqSignalID seqSignalID = (SeqSignalID) theEObject;
			T result = caseSeqSignalID(seqSignalID);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SecondModelPackage.ANALOG_BLOCK: {
			AnalogBlock analogBlock = (AnalogBlock) theEObject;
			T result = caseAnalogBlock(analogBlock);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SecondModelPackage.POPULATİNG_OUTPUT: {
			PopulatingOutput populatingOutput = (PopulatingOutput) theEObject;
			T result = casePopulatingOutput(populatingOutput);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case SecondModelPackage.DİGİTAL_BLOCK: {
			DigitalBlock digitalBlock = (DigitalBlock) theEObject;
			T result = caseDigitalBlock(digitalBlock);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Top Data Class</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Top Data Class</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTopDataClass(TopDataClass object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Local Variables</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Local Variables</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLocalVariables(LocalVariables object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Motor Block</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Motor Block</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMotorBlock(MotorBlock object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Signals</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Signals</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSignals(Signals object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Signals Input</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Signals Input</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSignalsInput(SignalsInput object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Signals Output</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Signals Output</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSignalsOutput(SignalsOutput object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Populating Input</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Populating Input</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePopulatingInput(PopulatingInput object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Operator</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Operator</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOperator(Operator object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Signal Id</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Signal Id</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSignalId(SignalId object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Sequence Block</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Sequence Block</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSequenceBlock(SequenceBlock object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Populating Steps</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Populating Steps</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePopulatingSteps(PopulatingSteps object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Seq Operator</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Seq Operator</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSeqOperator(SeqOperator object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Seq Signal ID</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Seq Signal ID</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSeqSignalID(SeqSignalID object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Analog Block</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Analog Block</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAnalogBlock(AnalogBlock object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Populating Output</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Populating Output</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePopulatingOutput(PopulatingOutput object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Digital Block</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Digital Block</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDigitalBlock(DigitalBlock object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //SecondModelSwitch
