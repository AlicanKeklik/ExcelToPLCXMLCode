/**
 */
package secondModel.util;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

import secondModel.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see secondModel.SecondModelPackage
 * @generated
 */
public class SecondModelAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static SecondModelPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SecondModelAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = SecondModelPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SecondModelSwitch<Adapter> modelSwitch = new SecondModelSwitch<Adapter>() {
		@Override
		public Adapter caseTopDataClass(TopDataClass object) {
			return createTopDataClassAdapter();
		}

		@Override
		public Adapter caseLocalVariables(LocalVariables object) {
			return createLocalVariablesAdapter();
		}

		@Override
		public Adapter caseMotorBlock(MotorBlock object) {
			return createMotorBlockAdapter();
		}

		@Override
		public Adapter caseSignals(Signals object) {
			return createSignalsAdapter();
		}

		@Override
		public Adapter caseSignalsInput(SignalsInput object) {
			return createSignalsInputAdapter();
		}

		@Override
		public Adapter caseSignalsOutput(SignalsOutput object) {
			return createSignalsOutputAdapter();
		}

		@Override
		public Adapter casePopulatingInput(PopulatingInput object) {
			return createPopulatingInputAdapter();
		}

		@Override
		public Adapter caseOperator(Operator object) {
			return createOperatorAdapter();
		}

		@Override
		public Adapter caseSignalId(SignalId object) {
			return createSignalIdAdapter();
		}

		@Override
		public Adapter caseSequenceBlock(SequenceBlock object) {
			return createSequenceBlockAdapter();
		}

		@Override
		public Adapter casePopulatingSteps(PopulatingSteps object) {
			return createPopulatingStepsAdapter();
		}

		@Override
		public Adapter caseSeqOperator(SeqOperator object) {
			return createSeqOperatorAdapter();
		}

		@Override
		public Adapter caseSeqSignalID(SeqSignalID object) {
			return createSeqSignalIDAdapter();
		}

		@Override
		public Adapter caseAnalogBlock(AnalogBlock object) {
			return createAnalogBlockAdapter();
		}

		@Override
		public Adapter casePopulatingOutput(PopulatingOutput object) {
			return createPopulatingOutputAdapter();
		}

		@Override
		public Adapter caseDigitalBlock(DigitalBlock object) {
			return createDigitalBlockAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link secondModel.TopDataClass <em>Top Data Class</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see secondModel.TopDataClass
	 * @generated
	 */
	public Adapter createTopDataClassAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link secondModel.LocalVariables <em>Local Variables</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see secondModel.LocalVariables
	 * @generated
	 */
	public Adapter createLocalVariablesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link secondModel.MotorBlock <em>Motor Block</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see secondModel.MotorBlock
	 * @generated
	 */
	public Adapter createMotorBlockAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link secondModel.Signals <em>Signals</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see secondModel.Signals
	 * @generated
	 */
	public Adapter createSignalsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link secondModel.SignalsInput <em>Signals Input</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see secondModel.SignalsInput
	 * @generated
	 */
	public Adapter createSignalsInputAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link secondModel.SignalsOutput <em>Signals Output</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see secondModel.SignalsOutput
	 * @generated
	 */
	public Adapter createSignalsOutputAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link secondModel.PopulatingInput <em>Populating Input</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see secondModel.PopulatingInput
	 * @generated
	 */
	public Adapter createPopulatingInputAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link secondModel.Operator <em>Operator</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see secondModel.Operator
	 * @generated
	 */
	public Adapter createOperatorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link secondModel.SignalId <em>Signal Id</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see secondModel.SignalId
	 * @generated
	 */
	public Adapter createSignalIdAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link secondModel.SequenceBlock <em>Sequence Block</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see secondModel.SequenceBlock
	 * @generated
	 */
	public Adapter createSequenceBlockAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link secondModel.PopulatingSteps <em>Populating Steps</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see secondModel.PopulatingSteps
	 * @generated
	 */
	public Adapter createPopulatingStepsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link secondModel.SeqOperator <em>Seq Operator</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see secondModel.SeqOperator
	 * @generated
	 */
	public Adapter createSeqOperatorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link secondModel.SeqSignalID <em>Seq Signal ID</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see secondModel.SeqSignalID
	 * @generated
	 */
	public Adapter createSeqSignalIDAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link secondModel.AnalogBlock <em>Analog Block</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see secondModel.AnalogBlock
	 * @generated
	 */
	public Adapter createAnalogBlockAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link secondModel.PopulatingOutput <em>Populating Output</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see secondModel.PopulatingOutput
	 * @generated
	 */
	public Adapter createPopulatingOutputAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link secondModel.DigitalBlock <em>Digital Block</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see secondModel.DigitalBlock
	 * @generated
	 */
	public Adapter createDigitalBlockAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //SecondModelAdapterFactory
