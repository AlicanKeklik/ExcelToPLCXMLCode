/**
 */
package secondModel;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Populating Output</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link secondModel.PopulatingOutput#getSignalName <em>Signal Name</em>}</li>
 *   <li>{@link secondModel.PopulatingOutput#getInputName <em>Input Name</em>}</li>
 *   <li>{@link secondModel.PopulatingOutput#getİnputsignals <em>İnputsignals</em>}</li>
 *   <li>{@link secondModel.PopulatingOutput#getIdNbr <em>Id Nbr</em>}</li>
 * </ul>
 *
 * @see secondModel.SecondModelPackage#getPopulatingOutput()
 * @model
 * @generated
 */
public interface PopulatingOutput extends EObject {
	/**
	 * Returns the value of the '<em><b>Signal Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Signal Name</em>' attribute.
	 * @see #setSignalName(String)
	 * @see secondModel.SecondModelPackage#getPopulatingOutput_SignalName()
	 * @model
	 * @generated
	 */
	String getSignalName();

	/**
	 * Sets the value of the '{@link secondModel.PopulatingOutput#getSignalName <em>Signal Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Signal Name</em>' attribute.
	 * @see #getSignalName()
	 * @generated
	 */
	void setSignalName(String value);

	/**
	 * Returns the value of the '<em><b>Input Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Input Name</em>' attribute.
	 * @see #setInputName(String)
	 * @see secondModel.SecondModelPackage#getPopulatingOutput_InputName()
	 * @model
	 * @generated
	 */
	String getInputName();

	/**
	 * Sets the value of the '{@link secondModel.PopulatingOutput#getInputName <em>Input Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Input Name</em>' attribute.
	 * @see #getInputName()
	 * @generated
	 */
	void setInputName(String value);

	/**
	 * Returns the value of the '<em><b>İnputsignals</b></em>' reference list.
	 * The list contents are of type {@link secondModel.Signals}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>İnputsignals</em>' reference list.
	 * @see secondModel.SecondModelPackage#getPopulatingOutput_İnputsignals()
	 * @model
	 * @generated
	 */
	EList<Signals> getİnputsignals();

	/**
	 * Returns the value of the '<em><b>Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id Nbr</em>' attribute.
	 * @see #setIdNbr(String)
	 * @see secondModel.SecondModelPackage#getPopulatingOutput_IdNbr()
	 * @model
	 * @generated
	 */
	String getIdNbr();

	/**
	 * Sets the value of the '{@link secondModel.PopulatingOutput#getIdNbr <em>Id Nbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id Nbr</em>' attribute.
	 * @see #getIdNbr()
	 * @generated
	 */
	void setIdNbr(String value);

} // PopulatingOutput
