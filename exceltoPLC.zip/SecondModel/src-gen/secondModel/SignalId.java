/**
 */
package secondModel;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Signal Id</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link secondModel.SignalId#getIdNbr <em>Id Nbr</em>}</li>
 *   <li>{@link secondModel.SignalId#getOperatorsignals <em>Operatorsignals</em>}</li>
 * </ul>
 *
 * @see secondModel.SecondModelPackage#getSignalId()
 * @model
 * @generated
 */
public interface SignalId extends EObject {
	/**
	 * Returns the value of the '<em><b>Id Nbr</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id Nbr</em>' attribute list.
	 * @see secondModel.SecondModelPackage#getSignalId_IdNbr()
	 * @model upper="100"
	 * @generated
	 */
	EList<String> getIdNbr();

	/**
	 * Returns the value of the '<em><b>Operatorsignals</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operatorsignals</em>' reference.
	 * @see #setOperatorsignals(Signals)
	 * @see secondModel.SecondModelPackage#getSignalId_Operatorsignals()
	 * @model required="true"
	 * @generated
	 */
	Signals getOperatorsignals();

	/**
	 * Sets the value of the '{@link secondModel.SignalId#getOperatorsignals <em>Operatorsignals</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Operatorsignals</em>' reference.
	 * @see #getOperatorsignals()
	 * @generated
	 */
	void setOperatorsignals(Signals value);

} // SignalId
