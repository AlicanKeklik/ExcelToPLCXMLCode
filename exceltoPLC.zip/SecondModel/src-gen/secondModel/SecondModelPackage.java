/**
 */
package secondModel;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see secondModel.SecondModelFactory
 * @model kind="package"
 * @generated
 */
public interface SecondModelPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "secondModel";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/secondModel";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "secondModel";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	SecondModelPackage eINSTANCE = secondModel.impl.SecondModelPackageImpl.init();

	/**
	 * The meta object id for the '{@link secondModel.impl.TopDataClassImpl <em>Top Data Class</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see secondModel.impl.TopDataClassImpl
	 * @see secondModel.impl.SecondModelPackageImpl#getTopDataClass()
	 * @generated
	 */
	int TOP_DATA_CLASS = 0;

	/**
	 * The feature id for the '<em><b>Header Text</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOP_DATA_CLASS__HEADER_TEXT = 0;

	/**
	 * The feature id for the '<em><b>Localvariables</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOP_DATA_CLASS__LOCALVARİABLES = 1;

	/**
	 * The feature id for the '<em><b>Motorblock</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOP_DATA_CLASS__MOTORBLOCK = 2;

	/**
	 * The feature id for the '<em><b>Signals</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOP_DATA_CLASS__SİGNALS = 3;

	/**
	 * The feature id for the '<em><b>Sequenceblock</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOP_DATA_CLASS__SEQUENCEBLOCK = 4;

	/**
	 * The feature id for the '<em><b>Analogblock</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOP_DATA_CLASS__ANALOGBLOCK = 5;

	/**
	 * The feature id for the '<em><b>Digitalblock</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOP_DATA_CLASS__DİGİTALBLOCK = 6;

	/**
	 * The number of structural features of the '<em>Top Data Class</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOP_DATA_CLASS_FEATURE_COUNT = 7;

	/**
	 * The number of operations of the '<em>Top Data Class</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOP_DATA_CLASS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link secondModel.impl.LocalVariablesImpl <em>Local Variables</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see secondModel.impl.LocalVariablesImpl
	 * @see secondModel.impl.SecondModelPackageImpl#getLocalVariables()
	 * @generated
	 */
	int LOCAL_VARİABLES = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCAL_VARİABLES__NAME = 0;

	/**
	 * The feature id for the '<em><b>Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCAL_VARİABLES__ID_NBR = 1;

	/**
	 * The feature id for the '<em><b>Hardware Reference</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCAL_VARİABLES__HARDWARE_REFERENCE = 2;

	/**
	 * The feature id for the '<em><b>Signals</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCAL_VARİABLES__SİGNALS = 3;

	/**
	 * The feature id for the '<em><b>Localvariablesforanalog</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCAL_VARİABLES__LOCALVARİABLESFORANALOG = 4;

	/**
	 * The feature id for the '<em><b>Localvariablesfordigital</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCAL_VARİABLES__LOCALVARİABLESFORDİGİTAL = 5;

	/**
	 * The number of structural features of the '<em>Local Variables</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCAL_VARİABLES_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Local Variables</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCAL_VARİABLES_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link secondModel.impl.MotorBlockImpl <em>Motor Block</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see secondModel.impl.MotorBlockImpl
	 * @see secondModel.impl.SecondModelPackageImpl#getMotorBlock()
	 * @generated
	 */
	int MOTOR_BLOCK = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR_BLOCK__NAME = 0;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR_BLOCK__DESCRİPTİON = 1;

	/**
	 * The feature id for the '<em><b>Signals In</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR_BLOCK__SİGNALS_IN = 2;

	/**
	 * The feature id for the '<em><b>Signals</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR_BLOCK__SİGNALS = 3;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR_BLOCK__TYPE = 4;

	/**
	 * The feature id for the '<em><b>Localvariables</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR_BLOCK__LOCALVARİABLES = 5;

	/**
	 * The feature id for the '<em><b>Signalsinput</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR_BLOCK__SİGNALSİNPUT = 6;

	/**
	 * The feature id for the '<em><b>Signalsoutput</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR_BLOCK__SİGNALSOUTPUT = 7;

	/**
	 * The feature id for the '<em><b>Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR_BLOCK__ID_NBR = 8;

	/**
	 * The feature id for the '<em><b>Populatinginput</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR_BLOCK__POPULATİNGİNPUT = 9;

	/**
	 * The feature id for the '<em><b>Populatingoutput</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR_BLOCK__POPULATİNGOUTPUT = 10;

	/**
	 * The number of structural features of the '<em>Motor Block</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR_BLOCK_FEATURE_COUNT = 11;

	/**
	 * The number of operations of the '<em>Motor Block</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR_BLOCK_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link secondModel.impl.SignalsImpl <em>Signals</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see secondModel.impl.SignalsImpl
	 * @see secondModel.impl.SecondModelPackageImpl#getSignals()
	 * @generated
	 */
	int SİGNALS = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNALS__NAME = 0;

	/**
	 * The feature id for the '<em><b>Signal Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNALS__SİGNAL_TYPE = 1;

	/**
	 * The feature id for the '<em><b>Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNALS__ID_NBR = 2;

	/**
	 * The number of structural features of the '<em>Signals</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNALS_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Signals</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNALS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link secondModel.impl.SignalsInputImpl <em>Signals Input</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see secondModel.impl.SignalsInputImpl
	 * @see secondModel.impl.SecondModelPackageImpl#getSignalsInput()
	 * @generated
	 */
	int SİGNALS_INPUT = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNALS_INPUT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNALS_INPUT__ID_NBR = 1;

	/**
	 * The number of structural features of the '<em>Signals Input</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNALS_INPUT_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Signals Input</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNALS_INPUT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link secondModel.impl.SignalsOutputImpl <em>Signals Output</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see secondModel.impl.SignalsOutputImpl
	 * @see secondModel.impl.SecondModelPackageImpl#getSignalsOutput()
	 * @generated
	 */
	int SİGNALS_OUTPUT = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNALS_OUTPUT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNALS_OUTPUT__ID_NBR = 1;

	/**
	 * The number of structural features of the '<em>Signals Output</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNALS_OUTPUT_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Signals Output</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNALS_OUTPUT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link secondModel.impl.PopulatingInputImpl <em>Populating Input</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see secondModel.impl.PopulatingInputImpl
	 * @see secondModel.impl.SecondModelPackageImpl#getPopulatingInput()
	 * @generated
	 */
	int POPULATİNG_INPUT = 6;

	/**
	 * The feature id for the '<em><b>Signal Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_INPUT__SİGNAL_NAME = 0;

	/**
	 * The feature id for the '<em><b>Input Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_INPUT__INPUT_NAME = 1;

	/**
	 * The feature id for the '<em><b>İnputsignals</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_INPUT__İNPUTSİGNALS = 2;

	/**
	 * The feature id for the '<em><b>Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_INPUT__ID_NBR = 3;

	/**
	 * The feature id for the '<em><b>Operator</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_INPUT__OPERATOR = 4;

	/**
	 * The number of structural features of the '<em>Populating Input</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_INPUT_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Populating Input</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_INPUT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link secondModel.impl.OperatorImpl <em>Operator</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see secondModel.impl.OperatorImpl
	 * @see secondModel.impl.SecondModelPackageImpl#getOperator()
	 * @generated
	 */
	int OPERATOR = 7;

	/**
	 * The feature id for the '<em><b>Operator Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATOR__OPERATOR_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Id Nbr</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATOR__ID_NBR = 1;

	/**
	 * The feature id for the '<em><b>Signalid</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATOR__SİGNALİD = 2;

	/**
	 * The feature id for the '<em><b>Operatorwithinoperator</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATOR__OPERATORWİTHİNOPERATOR = 3;

	/**
	 * The number of structural features of the '<em>Operator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATOR_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Operator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link secondModel.impl.SignalIdImpl <em>Signal Id</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see secondModel.impl.SignalIdImpl
	 * @see secondModel.impl.SecondModelPackageImpl#getSignalId()
	 * @generated
	 */
	int SİGNAL_ID = 8;

	/**
	 * The feature id for the '<em><b>Id Nbr</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNAL_ID__ID_NBR = 0;

	/**
	 * The feature id for the '<em><b>Operatorsignals</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNAL_ID__OPERATORSİGNALS = 1;

	/**
	 * The number of structural features of the '<em>Signal Id</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNAL_ID_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Signal Id</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SİGNAL_ID_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link secondModel.impl.SequenceBlockImpl <em>Sequence Block</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see secondModel.impl.SequenceBlockImpl
	 * @see secondModel.impl.SecondModelPackageImpl#getSequenceBlock()
	 * @generated
	 */
	int SEQUENCE_BLOCK = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQUENCE_BLOCK__NAME = 0;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQUENCE_BLOCK__DESCRİPTİON = 1;

	/**
	 * The feature id for the '<em><b>Populatingsteps</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQUENCE_BLOCK__POPULATİNGSTEPS = 2;

	/**
	 * The feature id for the '<em><b>Step Name</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQUENCE_BLOCK__STEP_NAME = 3;

	/**
	 * The feature id for the '<em><b>Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQUENCE_BLOCK__ID_NBR = 4;

	/**
	 * The number of structural features of the '<em>Sequence Block</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQUENCE_BLOCK_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Sequence Block</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQUENCE_BLOCK_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link secondModel.impl.PopulatingStepsImpl <em>Populating Steps</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see secondModel.impl.PopulatingStepsImpl
	 * @see secondModel.impl.SecondModelPackageImpl#getPopulatingSteps()
	 * @generated
	 */
	int POPULATİNG_STEPS = 10;

	/**
	 * The feature id for the '<em><b>Signals</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_STEPS__SİGNALS = 0;

	/**
	 * The feature id for the '<em><b>Seqoperator</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_STEPS__SEQOPERATOR = 1;

	/**
	 * The feature id for the '<em><b>Signal Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_STEPS__SİGNAL_NAME = 2;

	/**
	 * The feature id for the '<em><b>Input Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_STEPS__INPUT_NAME = 3;

	/**
	 * The feature id for the '<em><b>Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_STEPS__ID_NBR = 4;

	/**
	 * The feature id for the '<em><b>Next Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_STEPS__NEXT_ID_NBR = 5;

	/**
	 * The feature id for the '<em><b>Transition Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_STEPS__TRANSİTİON_ID_NBR = 6;

	/**
	 * The feature id for the '<em><b>Last Transition Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_STEPS__LAST_TRANSİTİON_ID_NBR = 7;

	/**
	 * The feature id for the '<em><b>Last Transition Step Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_STEPS__LAST_TRANSİTİON_STEP_NBR = 8;

	/**
	 * The number of structural features of the '<em>Populating Steps</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_STEPS_FEATURE_COUNT = 9;

	/**
	 * The number of operations of the '<em>Populating Steps</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_STEPS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link secondModel.impl.SeqOperatorImpl <em>Seq Operator</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see secondModel.impl.SeqOperatorImpl
	 * @see secondModel.impl.SecondModelPackageImpl#getSeqOperator()
	 * @generated
	 */
	int SEQ_OPERATOR = 11;

	/**
	 * The feature id for the '<em><b>Operator Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQ_OPERATOR__OPERATOR_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Id Nbr</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQ_OPERATOR__ID_NBR = 1;

	/**
	 * The feature id for the '<em><b>Seqoperatorwithinoperator</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQ_OPERATOR__SEQOPERATORWİTHİNOPERATOR = 2;

	/**
	 * The feature id for the '<em><b>Seqsignalid</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQ_OPERATOR__SEQSİGNALİD = 3;

	/**
	 * The feature id for the '<em><b>Concat Operator</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQ_OPERATOR__CONCAT_OPERATOR = 4;

	/**
	 * The number of structural features of the '<em>Seq Operator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQ_OPERATOR_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Seq Operator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQ_OPERATOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link secondModel.impl.SeqSignalIDImpl <em>Seq Signal ID</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see secondModel.impl.SeqSignalIDImpl
	 * @see secondModel.impl.SecondModelPackageImpl#getSeqSignalID()
	 * @generated
	 */
	int SEQ_SİGNAL_ID = 12;

	/**
	 * The feature id for the '<em><b>Id Nbr</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQ_SİGNAL_ID__ID_NBR = 0;

	/**
	 * The feature id for the '<em><b>Seqoperatorsignals</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQ_SİGNAL_ID__SEQOPERATORSİGNALS = 1;

	/**
	 * The number of structural features of the '<em>Seq Signal ID</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQ_SİGNAL_ID_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Seq Signal ID</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEQ_SİGNAL_ID_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link secondModel.impl.AnalogBlockImpl <em>Analog Block</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see secondModel.impl.AnalogBlockImpl
	 * @see secondModel.impl.SecondModelPackageImpl#getAnalogBlock()
	 * @generated
	 */
	int ANALOG_BLOCK = 13;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALOG_BLOCK__NAME = 0;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALOG_BLOCK__DESCRİPTİON = 1;

	/**
	 * The feature id for the '<em><b>Analogtosignals</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALOG_BLOCK__ANALOGTOSİGNALS = 2;

	/**
	 * The feature id for the '<em><b>Populatinginput</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALOG_BLOCK__POPULATİNGİNPUT = 3;

	/**
	 * The feature id for the '<em><b>Populatingoutput</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALOG_BLOCK__POPULATİNGOUTPUT = 4;

	/**
	 * The feature id for the '<em><b>Block Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALOG_BLOCK__BLOCK_ID = 5;

	/**
	 * The feature id for the '<em><b>Signals In</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALOG_BLOCK__SİGNALS_IN = 6;

	/**
	 * The number of structural features of the '<em>Analog Block</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALOG_BLOCK_FEATURE_COUNT = 7;

	/**
	 * The number of operations of the '<em>Analog Block</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALOG_BLOCK_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link secondModel.impl.PopulatingOutputImpl <em>Populating Output</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see secondModel.impl.PopulatingOutputImpl
	 * @see secondModel.impl.SecondModelPackageImpl#getPopulatingOutput()
	 * @generated
	 */
	int POPULATİNG_OUTPUT = 14;

	/**
	 * The feature id for the '<em><b>Signal Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_OUTPUT__SİGNAL_NAME = 0;

	/**
	 * The feature id for the '<em><b>Input Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_OUTPUT__INPUT_NAME = 1;

	/**
	 * The feature id for the '<em><b>İnputsignals</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_OUTPUT__İNPUTSİGNALS = 2;

	/**
	 * The feature id for the '<em><b>Id Nbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_OUTPUT__ID_NBR = 3;

	/**
	 * The number of structural features of the '<em>Populating Output</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_OUTPUT_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Populating Output</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POPULATİNG_OUTPUT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link secondModel.impl.DigitalBlockImpl <em>Digital Block</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see secondModel.impl.DigitalBlockImpl
	 * @see secondModel.impl.SecondModelPackageImpl#getDigitalBlock()
	 * @generated
	 */
	int DİGİTAL_BLOCK = 15;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DİGİTAL_BLOCK__NAME = 0;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DİGİTAL_BLOCK__DESCRİPTİON = 1;

	/**
	 * The feature id for the '<em><b>Digitaltosignals</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DİGİTAL_BLOCK__DİGİTALTOSİGNALS = 2;

	/**
	 * The feature id for the '<em><b>Populatinginput</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DİGİTAL_BLOCK__POPULATİNGİNPUT = 3;

	/**
	 * The feature id for the '<em><b>Populatingoutput</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DİGİTAL_BLOCK__POPULATİNGOUTPUT = 4;

	/**
	 * The feature id for the '<em><b>Block Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DİGİTAL_BLOCK__BLOCK_ID = 5;

	/**
	 * The number of structural features of the '<em>Digital Block</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DİGİTAL_BLOCK_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Digital Block</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DİGİTAL_BLOCK_OPERATION_COUNT = 0;

	/**
	 * Returns the meta object for class '{@link secondModel.TopDataClass <em>Top Data Class</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Top Data Class</em>'.
	 * @see secondModel.TopDataClass
	 * @generated
	 */
	EClass getTopDataClass();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.TopDataClass#getHeaderText <em>Header Text</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Header Text</em>'.
	 * @see secondModel.TopDataClass#getHeaderText()
	 * @see #getTopDataClass()
	 * @generated
	 */
	EAttribute getTopDataClass_HeaderText();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.TopDataClass#getLocalvariables <em>Localvariables</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Localvariables</em>'.
	 * @see secondModel.TopDataClass#getLocalvariables()
	 * @see #getTopDataClass()
	 * @generated
	 */
	EReference getTopDataClass_Localvariables();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.TopDataClass#getMotorblock <em>Motorblock</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Motorblock</em>'.
	 * @see secondModel.TopDataClass#getMotorblock()
	 * @see #getTopDataClass()
	 * @generated
	 */
	EReference getTopDataClass_Motorblock();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.TopDataClass#getSignals <em>Signals</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Signals</em>'.
	 * @see secondModel.TopDataClass#getSignals()
	 * @see #getTopDataClass()
	 * @generated
	 */
	EReference getTopDataClass_Signals();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.TopDataClass#getSequenceblock <em>Sequenceblock</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Sequenceblock</em>'.
	 * @see secondModel.TopDataClass#getSequenceblock()
	 * @see #getTopDataClass()
	 * @generated
	 */
	EReference getTopDataClass_Sequenceblock();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.TopDataClass#getAnalogblock <em>Analogblock</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Analogblock</em>'.
	 * @see secondModel.TopDataClass#getAnalogblock()
	 * @see #getTopDataClass()
	 * @generated
	 */
	EReference getTopDataClass_Analogblock();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.TopDataClass#getDigitalblock <em>Digitalblock</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Digitalblock</em>'.
	 * @see secondModel.TopDataClass#getDigitalblock()
	 * @see #getTopDataClass()
	 * @generated
	 */
	EReference getTopDataClass_Digitalblock();

	/**
	 * Returns the meta object for class '{@link secondModel.LocalVariables <em>Local Variables</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Local Variables</em>'.
	 * @see secondModel.LocalVariables
	 * @generated
	 */
	EClass getLocalVariables();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.LocalVariables#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see secondModel.LocalVariables#getName()
	 * @see #getLocalVariables()
	 * @generated
	 */
	EAttribute getLocalVariables_Name();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.LocalVariables#getHardwareReference <em>Hardware Reference</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Hardware Reference</em>'.
	 * @see secondModel.LocalVariables#getHardwareReference()
	 * @see #getLocalVariables()
	 * @generated
	 */
	EAttribute getLocalVariables_HardwareReference();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.LocalVariables#getSignals <em>Signals</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Signals</em>'.
	 * @see secondModel.LocalVariables#getSignals()
	 * @see #getLocalVariables()
	 * @generated
	 */
	EReference getLocalVariables_Signals();

	/**
	 * Returns the meta object for the containment reference '{@link secondModel.LocalVariables#getLocalvariablesforanalog <em>Localvariablesforanalog</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Localvariablesforanalog</em>'.
	 * @see secondModel.LocalVariables#getLocalvariablesforanalog()
	 * @see #getLocalVariables()
	 * @generated
	 */
	EReference getLocalVariables_Localvariablesforanalog();

	/**
	 * Returns the meta object for the containment reference '{@link secondModel.LocalVariables#getLocalvariablesfordigital <em>Localvariablesfordigital</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Localvariablesfordigital</em>'.
	 * @see secondModel.LocalVariables#getLocalvariablesfordigital()
	 * @see #getLocalVariables()
	 * @generated
	 */
	EReference getLocalVariables_Localvariablesfordigital();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.LocalVariables#getIdNbr <em>Id Nbr</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id Nbr</em>'.
	 * @see secondModel.LocalVariables#getIdNbr()
	 * @see #getLocalVariables()
	 * @generated
	 */
	EAttribute getLocalVariables_IdNbr();

	/**
	 * Returns the meta object for class '{@link secondModel.MotorBlock <em>Motor Block</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Motor Block</em>'.
	 * @see secondModel.MotorBlock
	 * @generated
	 */
	EClass getMotorBlock();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.MotorBlock#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see secondModel.MotorBlock#getName()
	 * @see #getMotorBlock()
	 * @generated
	 */
	EAttribute getMotorBlock_Name();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.MotorBlock#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see secondModel.MotorBlock#getDescription()
	 * @see #getMotorBlock()
	 * @generated
	 */
	EAttribute getMotorBlock_Description();

	/**
	 * Returns the meta object for the attribute list '{@link secondModel.MotorBlock#getSignalsIn <em>Signals In</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Signals In</em>'.
	 * @see secondModel.MotorBlock#getSignalsIn()
	 * @see #getMotorBlock()
	 * @generated
	 */
	EAttribute getMotorBlock_SignalsIn();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.MotorBlock#getSignals <em>Signals</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Signals</em>'.
	 * @see secondModel.MotorBlock#getSignals()
	 * @see #getMotorBlock()
	 * @generated
	 */
	EReference getMotorBlock_Signals();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.MotorBlock#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see secondModel.MotorBlock#getType()
	 * @see #getMotorBlock()
	 * @generated
	 */
	EAttribute getMotorBlock_Type();

	/**
	 * Returns the meta object for the containment reference '{@link secondModel.MotorBlock#getLocalvariables <em>Localvariables</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Localvariables</em>'.
	 * @see secondModel.MotorBlock#getLocalvariables()
	 * @see #getMotorBlock()
	 * @generated
	 */
	EReference getMotorBlock_Localvariables();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.MotorBlock#getSignalsinput <em>Signalsinput</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Signalsinput</em>'.
	 * @see secondModel.MotorBlock#getSignalsinput()
	 * @see #getMotorBlock()
	 * @generated
	 */
	EReference getMotorBlock_Signalsinput();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.MotorBlock#getSignalsoutput <em>Signalsoutput</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Signalsoutput</em>'.
	 * @see secondModel.MotorBlock#getSignalsoutput()
	 * @see #getMotorBlock()
	 * @generated
	 */
	EReference getMotorBlock_Signalsoutput();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.MotorBlock#getIdNbr <em>Id Nbr</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id Nbr</em>'.
	 * @see secondModel.MotorBlock#getIdNbr()
	 * @see #getMotorBlock()
	 * @generated
	 */
	EAttribute getMotorBlock_IdNbr();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.MotorBlock#getPopulatinginput <em>Populatinginput</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Populatinginput</em>'.
	 * @see secondModel.MotorBlock#getPopulatinginput()
	 * @see #getMotorBlock()
	 * @generated
	 */
	EReference getMotorBlock_Populatinginput();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.MotorBlock#getPopulatingoutput <em>Populatingoutput</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Populatingoutput</em>'.
	 * @see secondModel.MotorBlock#getPopulatingoutput()
	 * @see #getMotorBlock()
	 * @generated
	 */
	EReference getMotorBlock_Populatingoutput();

	/**
	 * Returns the meta object for class '{@link secondModel.Signals <em>Signals</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Signals</em>'.
	 * @see secondModel.Signals
	 * @generated
	 */
	EClass getSignals();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.Signals#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see secondModel.Signals#getName()
	 * @see #getSignals()
	 * @generated
	 */
	EAttribute getSignals_Name();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.Signals#getSignalType <em>Signal Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Signal Type</em>'.
	 * @see secondModel.Signals#getSignalType()
	 * @see #getSignals()
	 * @generated
	 */
	EAttribute getSignals_SignalType();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.Signals#getIdNbr <em>Id Nbr</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id Nbr</em>'.
	 * @see secondModel.Signals#getIdNbr()
	 * @see #getSignals()
	 * @generated
	 */
	EAttribute getSignals_IdNbr();

	/**
	 * Returns the meta object for class '{@link secondModel.SignalsInput <em>Signals Input</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Signals Input</em>'.
	 * @see secondModel.SignalsInput
	 * @generated
	 */
	EClass getSignalsInput();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.SignalsInput#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see secondModel.SignalsInput#getName()
	 * @see #getSignalsInput()
	 * @generated
	 */
	EAttribute getSignalsInput_Name();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.SignalsInput#getIdNbr <em>Id Nbr</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id Nbr</em>'.
	 * @see secondModel.SignalsInput#getIdNbr()
	 * @see #getSignalsInput()
	 * @generated
	 */
	EAttribute getSignalsInput_IdNbr();

	/**
	 * Returns the meta object for class '{@link secondModel.SignalsOutput <em>Signals Output</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Signals Output</em>'.
	 * @see secondModel.SignalsOutput
	 * @generated
	 */
	EClass getSignalsOutput();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.SignalsOutput#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see secondModel.SignalsOutput#getName()
	 * @see #getSignalsOutput()
	 * @generated
	 */
	EAttribute getSignalsOutput_Name();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.SignalsOutput#getIdNbr <em>Id Nbr</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id Nbr</em>'.
	 * @see secondModel.SignalsOutput#getIdNbr()
	 * @see #getSignalsOutput()
	 * @generated
	 */
	EAttribute getSignalsOutput_IdNbr();

	/**
	 * Returns the meta object for class '{@link secondModel.PopulatingInput <em>Populating Input</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Populating Input</em>'.
	 * @see secondModel.PopulatingInput
	 * @generated
	 */
	EClass getPopulatingInput();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.PopulatingInput#getSignalName <em>Signal Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Signal Name</em>'.
	 * @see secondModel.PopulatingInput#getSignalName()
	 * @see #getPopulatingInput()
	 * @generated
	 */
	EAttribute getPopulatingInput_SignalName();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.PopulatingInput#getInputName <em>Input Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Input Name</em>'.
	 * @see secondModel.PopulatingInput#getInputName()
	 * @see #getPopulatingInput()
	 * @generated
	 */
	EAttribute getPopulatingInput_InputName();

	/**
	 * Returns the meta object for the reference list '{@link secondModel.PopulatingInput#getİnputsignals <em>İnputsignals</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>İnputsignals</em>'.
	 * @see secondModel.PopulatingInput#getİnputsignals()
	 * @see #getPopulatingInput()
	 * @generated
	 */
	EReference getPopulatingInput_İnputsignals();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.PopulatingInput#getIdNbr <em>Id Nbr</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id Nbr</em>'.
	 * @see secondModel.PopulatingInput#getIdNbr()
	 * @see #getPopulatingInput()
	 * @generated
	 */
	EAttribute getPopulatingInput_IdNbr();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.PopulatingInput#getOperator <em>Operator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Operator</em>'.
	 * @see secondModel.PopulatingInput#getOperator()
	 * @see #getPopulatingInput()
	 * @generated
	 */
	EReference getPopulatingInput_Operator();

	/**
	 * Returns the meta object for class '{@link secondModel.Operator <em>Operator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Operator</em>'.
	 * @see secondModel.Operator
	 * @generated
	 */
	EClass getOperator();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.Operator#getOperatorType <em>Operator Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Operator Type</em>'.
	 * @see secondModel.Operator#getOperatorType()
	 * @see #getOperator()
	 * @generated
	 */
	EAttribute getOperator_OperatorType();

	/**
	 * Returns the meta object for the attribute list '{@link secondModel.Operator#getIdNbr <em>Id Nbr</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Id Nbr</em>'.
	 * @see secondModel.Operator#getIdNbr()
	 * @see #getOperator()
	 * @generated
	 */
	EAttribute getOperator_IdNbr();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.Operator#getSignalid <em>Signalid</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Signalid</em>'.
	 * @see secondModel.Operator#getSignalid()
	 * @see #getOperator()
	 * @generated
	 */
	EReference getOperator_Signalid();

	/**
	 * Returns the meta object for the reference list '{@link secondModel.Operator#getOperatorwithinoperator <em>Operatorwithinoperator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Operatorwithinoperator</em>'.
	 * @see secondModel.Operator#getOperatorwithinoperator()
	 * @see #getOperator()
	 * @generated
	 */
	EReference getOperator_Operatorwithinoperator();

	/**
	 * Returns the meta object for class '{@link secondModel.SignalId <em>Signal Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Signal Id</em>'.
	 * @see secondModel.SignalId
	 * @generated
	 */
	EClass getSignalId();

	/**
	 * Returns the meta object for the attribute list '{@link secondModel.SignalId#getIdNbr <em>Id Nbr</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Id Nbr</em>'.
	 * @see secondModel.SignalId#getIdNbr()
	 * @see #getSignalId()
	 * @generated
	 */
	EAttribute getSignalId_IdNbr();

	/**
	 * Returns the meta object for the reference '{@link secondModel.SignalId#getOperatorsignals <em>Operatorsignals</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Operatorsignals</em>'.
	 * @see secondModel.SignalId#getOperatorsignals()
	 * @see #getSignalId()
	 * @generated
	 */
	EReference getSignalId_Operatorsignals();

	/**
	 * Returns the meta object for class '{@link secondModel.SequenceBlock <em>Sequence Block</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sequence Block</em>'.
	 * @see secondModel.SequenceBlock
	 * @generated
	 */
	EClass getSequenceBlock();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.SequenceBlock#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see secondModel.SequenceBlock#getName()
	 * @see #getSequenceBlock()
	 * @generated
	 */
	EAttribute getSequenceBlock_Name();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.SequenceBlock#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see secondModel.SequenceBlock#getDescription()
	 * @see #getSequenceBlock()
	 * @generated
	 */
	EAttribute getSequenceBlock_Description();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.SequenceBlock#getPopulatingsteps <em>Populatingsteps</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Populatingsteps</em>'.
	 * @see secondModel.SequenceBlock#getPopulatingsteps()
	 * @see #getSequenceBlock()
	 * @generated
	 */
	EReference getSequenceBlock_Populatingsteps();

	/**
	 * Returns the meta object for the attribute list '{@link secondModel.SequenceBlock#getStepName <em>Step Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Step Name</em>'.
	 * @see secondModel.SequenceBlock#getStepName()
	 * @see #getSequenceBlock()
	 * @generated
	 */
	EAttribute getSequenceBlock_StepName();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.SequenceBlock#getIdNbr <em>Id Nbr</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id Nbr</em>'.
	 * @see secondModel.SequenceBlock#getIdNbr()
	 * @see #getSequenceBlock()
	 * @generated
	 */
	EAttribute getSequenceBlock_IdNbr();

	/**
	 * Returns the meta object for class '{@link secondModel.PopulatingSteps <em>Populating Steps</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Populating Steps</em>'.
	 * @see secondModel.PopulatingSteps
	 * @generated
	 */
	EClass getPopulatingSteps();

	/**
	 * Returns the meta object for the reference list '{@link secondModel.PopulatingSteps#getSignals <em>Signals</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Signals</em>'.
	 * @see secondModel.PopulatingSteps#getSignals()
	 * @see #getPopulatingSteps()
	 * @generated
	 */
	EReference getPopulatingSteps_Signals();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.PopulatingSteps#getSeqoperator <em>Seqoperator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Seqoperator</em>'.
	 * @see secondModel.PopulatingSteps#getSeqoperator()
	 * @see #getPopulatingSteps()
	 * @generated
	 */
	EReference getPopulatingSteps_Seqoperator();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.PopulatingSteps#getSignalName <em>Signal Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Signal Name</em>'.
	 * @see secondModel.PopulatingSteps#getSignalName()
	 * @see #getPopulatingSteps()
	 * @generated
	 */
	EAttribute getPopulatingSteps_SignalName();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.PopulatingSteps#getInputName <em>Input Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Input Name</em>'.
	 * @see secondModel.PopulatingSteps#getInputName()
	 * @see #getPopulatingSteps()
	 * @generated
	 */
	EAttribute getPopulatingSteps_InputName();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.PopulatingSteps#getIdNbr <em>Id Nbr</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id Nbr</em>'.
	 * @see secondModel.PopulatingSteps#getIdNbr()
	 * @see #getPopulatingSteps()
	 * @generated
	 */
	EAttribute getPopulatingSteps_IdNbr();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.PopulatingSteps#getNextIdNbr <em>Next Id Nbr</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Next Id Nbr</em>'.
	 * @see secondModel.PopulatingSteps#getNextIdNbr()
	 * @see #getPopulatingSteps()
	 * @generated
	 */
	EAttribute getPopulatingSteps_NextIdNbr();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.PopulatingSteps#getTransitionIdNbr <em>Transition Id Nbr</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Transition Id Nbr</em>'.
	 * @see secondModel.PopulatingSteps#getTransitionIdNbr()
	 * @see #getPopulatingSteps()
	 * @generated
	 */
	EAttribute getPopulatingSteps_TransitionIdNbr();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.PopulatingSteps#getLastTransitionIdNbr <em>Last Transition Id Nbr</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Last Transition Id Nbr</em>'.
	 * @see secondModel.PopulatingSteps#getLastTransitionIdNbr()
	 * @see #getPopulatingSteps()
	 * @generated
	 */
	EAttribute getPopulatingSteps_LastTransitionIdNbr();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.PopulatingSteps#getLastTransitionStepNbr <em>Last Transition Step Nbr</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Last Transition Step Nbr</em>'.
	 * @see secondModel.PopulatingSteps#getLastTransitionStepNbr()
	 * @see #getPopulatingSteps()
	 * @generated
	 */
	EAttribute getPopulatingSteps_LastTransitionStepNbr();

	/**
	 * Returns the meta object for class '{@link secondModel.SeqOperator <em>Seq Operator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Seq Operator</em>'.
	 * @see secondModel.SeqOperator
	 * @generated
	 */
	EClass getSeqOperator();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.SeqOperator#getOperatorType <em>Operator Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Operator Type</em>'.
	 * @see secondModel.SeqOperator#getOperatorType()
	 * @see #getSeqOperator()
	 * @generated
	 */
	EAttribute getSeqOperator_OperatorType();

	/**
	 * Returns the meta object for the attribute list '{@link secondModel.SeqOperator#getIdNbr <em>Id Nbr</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Id Nbr</em>'.
	 * @see secondModel.SeqOperator#getIdNbr()
	 * @see #getSeqOperator()
	 * @generated
	 */
	EAttribute getSeqOperator_IdNbr();

	/**
	 * Returns the meta object for the reference list '{@link secondModel.SeqOperator#getSeqoperatorwithinoperator <em>Seqoperatorwithinoperator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Seqoperatorwithinoperator</em>'.
	 * @see secondModel.SeqOperator#getSeqoperatorwithinoperator()
	 * @see #getSeqOperator()
	 * @generated
	 */
	EReference getSeqOperator_Seqoperatorwithinoperator();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.SeqOperator#getSeqsignalid <em>Seqsignalid</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Seqsignalid</em>'.
	 * @see secondModel.SeqOperator#getSeqsignalid()
	 * @see #getSeqOperator()
	 * @generated
	 */
	EReference getSeqOperator_Seqsignalid();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.SeqOperator#getConcatOperator <em>Concat Operator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Concat Operator</em>'.
	 * @see secondModel.SeqOperator#getConcatOperator()
	 * @see #getSeqOperator()
	 * @generated
	 */
	EAttribute getSeqOperator_ConcatOperator();

	/**
	 * Returns the meta object for class '{@link secondModel.SeqSignalID <em>Seq Signal ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Seq Signal ID</em>'.
	 * @see secondModel.SeqSignalID
	 * @generated
	 */
	EClass getSeqSignalID();

	/**
	 * Returns the meta object for the attribute list '{@link secondModel.SeqSignalID#getIdNbr <em>Id Nbr</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Id Nbr</em>'.
	 * @see secondModel.SeqSignalID#getIdNbr()
	 * @see #getSeqSignalID()
	 * @generated
	 */
	EAttribute getSeqSignalID_IdNbr();

	/**
	 * Returns the meta object for the reference '{@link secondModel.SeqSignalID#getSeqoperatorsignals <em>Seqoperatorsignals</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Seqoperatorsignals</em>'.
	 * @see secondModel.SeqSignalID#getSeqoperatorsignals()
	 * @see #getSeqSignalID()
	 * @generated
	 */
	EReference getSeqSignalID_Seqoperatorsignals();

	/**
	 * Returns the meta object for class '{@link secondModel.AnalogBlock <em>Analog Block</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Analog Block</em>'.
	 * @see secondModel.AnalogBlock
	 * @generated
	 */
	EClass getAnalogBlock();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.AnalogBlock#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see secondModel.AnalogBlock#getName()
	 * @see #getAnalogBlock()
	 * @generated
	 */
	EAttribute getAnalogBlock_Name();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.AnalogBlock#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see secondModel.AnalogBlock#getDescription()
	 * @see #getAnalogBlock()
	 * @generated
	 */
	EAttribute getAnalogBlock_Description();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.AnalogBlock#getAnalogtosignals <em>Analogtosignals</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Analogtosignals</em>'.
	 * @see secondModel.AnalogBlock#getAnalogtosignals()
	 * @see #getAnalogBlock()
	 * @generated
	 */
	EReference getAnalogBlock_Analogtosignals();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.AnalogBlock#getPopulatinginput <em>Populatinginput</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Populatinginput</em>'.
	 * @see secondModel.AnalogBlock#getPopulatinginput()
	 * @see #getAnalogBlock()
	 * @generated
	 */
	EReference getAnalogBlock_Populatinginput();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.AnalogBlock#getPopulatingoutput <em>Populatingoutput</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Populatingoutput</em>'.
	 * @see secondModel.AnalogBlock#getPopulatingoutput()
	 * @see #getAnalogBlock()
	 * @generated
	 */
	EReference getAnalogBlock_Populatingoutput();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.AnalogBlock#getBlockId <em>Block Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Block Id</em>'.
	 * @see secondModel.AnalogBlock#getBlockId()
	 * @see #getAnalogBlock()
	 * @generated
	 */
	EAttribute getAnalogBlock_BlockId();

	/**
	 * Returns the meta object for the attribute list '{@link secondModel.AnalogBlock#getSignalsIn <em>Signals In</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Signals In</em>'.
	 * @see secondModel.AnalogBlock#getSignalsIn()
	 * @see #getAnalogBlock()
	 * @generated
	 */
	EAttribute getAnalogBlock_SignalsIn();

	/**
	 * Returns the meta object for class '{@link secondModel.PopulatingOutput <em>Populating Output</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Populating Output</em>'.
	 * @see secondModel.PopulatingOutput
	 * @generated
	 */
	EClass getPopulatingOutput();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.PopulatingOutput#getSignalName <em>Signal Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Signal Name</em>'.
	 * @see secondModel.PopulatingOutput#getSignalName()
	 * @see #getPopulatingOutput()
	 * @generated
	 */
	EAttribute getPopulatingOutput_SignalName();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.PopulatingOutput#getInputName <em>Input Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Input Name</em>'.
	 * @see secondModel.PopulatingOutput#getInputName()
	 * @see #getPopulatingOutput()
	 * @generated
	 */
	EAttribute getPopulatingOutput_InputName();

	/**
	 * Returns the meta object for the reference list '{@link secondModel.PopulatingOutput#getİnputsignals <em>İnputsignals</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>İnputsignals</em>'.
	 * @see secondModel.PopulatingOutput#getİnputsignals()
	 * @see #getPopulatingOutput()
	 * @generated
	 */
	EReference getPopulatingOutput_İnputsignals();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.PopulatingOutput#getIdNbr <em>Id Nbr</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id Nbr</em>'.
	 * @see secondModel.PopulatingOutput#getIdNbr()
	 * @see #getPopulatingOutput()
	 * @generated
	 */
	EAttribute getPopulatingOutput_IdNbr();

	/**
	 * Returns the meta object for class '{@link secondModel.DigitalBlock <em>Digital Block</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Digital Block</em>'.
	 * @see secondModel.DigitalBlock
	 * @generated
	 */
	EClass getDigitalBlock();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.DigitalBlock#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see secondModel.DigitalBlock#getName()
	 * @see #getDigitalBlock()
	 * @generated
	 */
	EAttribute getDigitalBlock_Name();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.DigitalBlock#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see secondModel.DigitalBlock#getDescription()
	 * @see #getDigitalBlock()
	 * @generated
	 */
	EAttribute getDigitalBlock_Description();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.DigitalBlock#getDigitaltosignals <em>Digitaltosignals</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Digitaltosignals</em>'.
	 * @see secondModel.DigitalBlock#getDigitaltosignals()
	 * @see #getDigitalBlock()
	 * @generated
	 */
	EReference getDigitalBlock_Digitaltosignals();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.DigitalBlock#getPopulatinginput <em>Populatinginput</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Populatinginput</em>'.
	 * @see secondModel.DigitalBlock#getPopulatinginput()
	 * @see #getDigitalBlock()
	 * @generated
	 */
	EReference getDigitalBlock_Populatinginput();

	/**
	 * Returns the meta object for the containment reference list '{@link secondModel.DigitalBlock#getPopulatingoutput <em>Populatingoutput</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Populatingoutput</em>'.
	 * @see secondModel.DigitalBlock#getPopulatingoutput()
	 * @see #getDigitalBlock()
	 * @generated
	 */
	EReference getDigitalBlock_Populatingoutput();

	/**
	 * Returns the meta object for the attribute '{@link secondModel.DigitalBlock#getBlockId <em>Block Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Block Id</em>'.
	 * @see secondModel.DigitalBlock#getBlockId()
	 * @see #getDigitalBlock()
	 * @generated
	 */
	EAttribute getDigitalBlock_BlockId();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	SecondModelFactory getSecondModelFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link secondModel.impl.TopDataClassImpl <em>Top Data Class</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see secondModel.impl.TopDataClassImpl
		 * @see secondModel.impl.SecondModelPackageImpl#getTopDataClass()
		 * @generated
		 */
		EClass TOP_DATA_CLASS = eINSTANCE.getTopDataClass();

		/**
		 * The meta object literal for the '<em><b>Header Text</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TOP_DATA_CLASS__HEADER_TEXT = eINSTANCE.getTopDataClass_HeaderText();

		/**
		 * The meta object literal for the '<em><b>Localvariables</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TOP_DATA_CLASS__LOCALVARİABLES = eINSTANCE.getTopDataClass_Localvariables();

		/**
		 * The meta object literal for the '<em><b>Motorblock</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TOP_DATA_CLASS__MOTORBLOCK = eINSTANCE.getTopDataClass_Motorblock();

		/**
		 * The meta object literal for the '<em><b>Signals</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TOP_DATA_CLASS__SİGNALS = eINSTANCE.getTopDataClass_Signals();

		/**
		 * The meta object literal for the '<em><b>Sequenceblock</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TOP_DATA_CLASS__SEQUENCEBLOCK = eINSTANCE.getTopDataClass_Sequenceblock();

		/**
		 * The meta object literal for the '<em><b>Analogblock</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TOP_DATA_CLASS__ANALOGBLOCK = eINSTANCE.getTopDataClass_Analogblock();

		/**
		 * The meta object literal for the '<em><b>Digitalblock</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TOP_DATA_CLASS__DİGİTALBLOCK = eINSTANCE.getTopDataClass_Digitalblock();

		/**
		 * The meta object literal for the '{@link secondModel.impl.LocalVariablesImpl <em>Local Variables</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see secondModel.impl.LocalVariablesImpl
		 * @see secondModel.impl.SecondModelPackageImpl#getLocalVariables()
		 * @generated
		 */
		EClass LOCAL_VARİABLES = eINSTANCE.getLocalVariables();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOCAL_VARİABLES__NAME = eINSTANCE.getLocalVariables_Name();

		/**
		 * The meta object literal for the '<em><b>Id Nbr</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOCAL_VARİABLES__ID_NBR = eINSTANCE.getLocalVariables_IdNbr();

		/**
		 * The meta object literal for the '<em><b>Hardware Reference</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOCAL_VARİABLES__HARDWARE_REFERENCE = eINSTANCE.getLocalVariables_HardwareReference();

		/**
		 * The meta object literal for the '<em><b>Signals</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LOCAL_VARİABLES__SİGNALS = eINSTANCE.getLocalVariables_Signals();

		/**
		 * The meta object literal for the '<em><b>Localvariablesforanalog</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LOCAL_VARİABLES__LOCALVARİABLESFORANALOG = eINSTANCE.getLocalVariables_Localvariablesforanalog();

		/**
		 * The meta object literal for the '<em><b>Localvariablesfordigital</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LOCAL_VARİABLES__LOCALVARİABLESFORDİGİTAL = eINSTANCE.getLocalVariables_Localvariablesfordigital();

		/**
		 * The meta object literal for the '{@link secondModel.impl.MotorBlockImpl <em>Motor Block</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see secondModel.impl.MotorBlockImpl
		 * @see secondModel.impl.SecondModelPackageImpl#getMotorBlock()
		 * @generated
		 */
		EClass MOTOR_BLOCK = eINSTANCE.getMotorBlock();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOTOR_BLOCK__NAME = eINSTANCE.getMotorBlock_Name();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOTOR_BLOCK__DESCRİPTİON = eINSTANCE.getMotorBlock_Description();

		/**
		 * The meta object literal for the '<em><b>Signals In</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOTOR_BLOCK__SİGNALS_IN = eINSTANCE.getMotorBlock_SignalsIn();

		/**
		 * The meta object literal for the '<em><b>Signals</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOTOR_BLOCK__SİGNALS = eINSTANCE.getMotorBlock_Signals();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOTOR_BLOCK__TYPE = eINSTANCE.getMotorBlock_Type();

		/**
		 * The meta object literal for the '<em><b>Localvariables</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOTOR_BLOCK__LOCALVARİABLES = eINSTANCE.getMotorBlock_Localvariables();

		/**
		 * The meta object literal for the '<em><b>Signalsinput</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOTOR_BLOCK__SİGNALSİNPUT = eINSTANCE.getMotorBlock_Signalsinput();

		/**
		 * The meta object literal for the '<em><b>Signalsoutput</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOTOR_BLOCK__SİGNALSOUTPUT = eINSTANCE.getMotorBlock_Signalsoutput();

		/**
		 * The meta object literal for the '<em><b>Id Nbr</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOTOR_BLOCK__ID_NBR = eINSTANCE.getMotorBlock_IdNbr();

		/**
		 * The meta object literal for the '<em><b>Populatinginput</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOTOR_BLOCK__POPULATİNGİNPUT = eINSTANCE.getMotorBlock_Populatinginput();

		/**
		 * The meta object literal for the '<em><b>Populatingoutput</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOTOR_BLOCK__POPULATİNGOUTPUT = eINSTANCE.getMotorBlock_Populatingoutput();

		/**
		 * The meta object literal for the '{@link secondModel.impl.SignalsImpl <em>Signals</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see secondModel.impl.SignalsImpl
		 * @see secondModel.impl.SecondModelPackageImpl#getSignals()
		 * @generated
		 */
		EClass SİGNALS = eINSTANCE.getSignals();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SİGNALS__NAME = eINSTANCE.getSignals_Name();

		/**
		 * The meta object literal for the '<em><b>Signal Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SİGNALS__SİGNAL_TYPE = eINSTANCE.getSignals_SignalType();

		/**
		 * The meta object literal for the '<em><b>Id Nbr</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SİGNALS__ID_NBR = eINSTANCE.getSignals_IdNbr();

		/**
		 * The meta object literal for the '{@link secondModel.impl.SignalsInputImpl <em>Signals Input</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see secondModel.impl.SignalsInputImpl
		 * @see secondModel.impl.SecondModelPackageImpl#getSignalsInput()
		 * @generated
		 */
		EClass SİGNALS_INPUT = eINSTANCE.getSignalsInput();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SİGNALS_INPUT__NAME = eINSTANCE.getSignalsInput_Name();

		/**
		 * The meta object literal for the '<em><b>Id Nbr</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SİGNALS_INPUT__ID_NBR = eINSTANCE.getSignalsInput_IdNbr();

		/**
		 * The meta object literal for the '{@link secondModel.impl.SignalsOutputImpl <em>Signals Output</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see secondModel.impl.SignalsOutputImpl
		 * @see secondModel.impl.SecondModelPackageImpl#getSignalsOutput()
		 * @generated
		 */
		EClass SİGNALS_OUTPUT = eINSTANCE.getSignalsOutput();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SİGNALS_OUTPUT__NAME = eINSTANCE.getSignalsOutput_Name();

		/**
		 * The meta object literal for the '<em><b>Id Nbr</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SİGNALS_OUTPUT__ID_NBR = eINSTANCE.getSignalsOutput_IdNbr();

		/**
		 * The meta object literal for the '{@link secondModel.impl.PopulatingInputImpl <em>Populating Input</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see secondModel.impl.PopulatingInputImpl
		 * @see secondModel.impl.SecondModelPackageImpl#getPopulatingInput()
		 * @generated
		 */
		EClass POPULATİNG_INPUT = eINSTANCE.getPopulatingInput();

		/**
		 * The meta object literal for the '<em><b>Signal Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POPULATİNG_INPUT__SİGNAL_NAME = eINSTANCE.getPopulatingInput_SignalName();

		/**
		 * The meta object literal for the '<em><b>Input Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POPULATİNG_INPUT__INPUT_NAME = eINSTANCE.getPopulatingInput_InputName();

		/**
		 * The meta object literal for the '<em><b>İnputsignals</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference POPULATİNG_INPUT__İNPUTSİGNALS = eINSTANCE.getPopulatingInput_İnputsignals();

		/**
		 * The meta object literal for the '<em><b>Id Nbr</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POPULATİNG_INPUT__ID_NBR = eINSTANCE.getPopulatingInput_IdNbr();

		/**
		 * The meta object literal for the '<em><b>Operator</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference POPULATİNG_INPUT__OPERATOR = eINSTANCE.getPopulatingInput_Operator();

		/**
		 * The meta object literal for the '{@link secondModel.impl.OperatorImpl <em>Operator</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see secondModel.impl.OperatorImpl
		 * @see secondModel.impl.SecondModelPackageImpl#getOperator()
		 * @generated
		 */
		EClass OPERATOR = eINSTANCE.getOperator();

		/**
		 * The meta object literal for the '<em><b>Operator Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OPERATOR__OPERATOR_TYPE = eINSTANCE.getOperator_OperatorType();

		/**
		 * The meta object literal for the '<em><b>Id Nbr</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OPERATOR__ID_NBR = eINSTANCE.getOperator_IdNbr();

		/**
		 * The meta object literal for the '<em><b>Signalid</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OPERATOR__SİGNALİD = eINSTANCE.getOperator_Signalid();

		/**
		 * The meta object literal for the '<em><b>Operatorwithinoperator</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OPERATOR__OPERATORWİTHİNOPERATOR = eINSTANCE.getOperator_Operatorwithinoperator();

		/**
		 * The meta object literal for the '{@link secondModel.impl.SignalIdImpl <em>Signal Id</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see secondModel.impl.SignalIdImpl
		 * @see secondModel.impl.SecondModelPackageImpl#getSignalId()
		 * @generated
		 */
		EClass SİGNAL_ID = eINSTANCE.getSignalId();

		/**
		 * The meta object literal for the '<em><b>Id Nbr</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SİGNAL_ID__ID_NBR = eINSTANCE.getSignalId_IdNbr();

		/**
		 * The meta object literal for the '<em><b>Operatorsignals</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SİGNAL_ID__OPERATORSİGNALS = eINSTANCE.getSignalId_Operatorsignals();

		/**
		 * The meta object literal for the '{@link secondModel.impl.SequenceBlockImpl <em>Sequence Block</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see secondModel.impl.SequenceBlockImpl
		 * @see secondModel.impl.SecondModelPackageImpl#getSequenceBlock()
		 * @generated
		 */
		EClass SEQUENCE_BLOCK = eINSTANCE.getSequenceBlock();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEQUENCE_BLOCK__NAME = eINSTANCE.getSequenceBlock_Name();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEQUENCE_BLOCK__DESCRİPTİON = eINSTANCE.getSequenceBlock_Description();

		/**
		 * The meta object literal for the '<em><b>Populatingsteps</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEQUENCE_BLOCK__POPULATİNGSTEPS = eINSTANCE.getSequenceBlock_Populatingsteps();

		/**
		 * The meta object literal for the '<em><b>Step Name</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEQUENCE_BLOCK__STEP_NAME = eINSTANCE.getSequenceBlock_StepName();

		/**
		 * The meta object literal for the '<em><b>Id Nbr</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEQUENCE_BLOCK__ID_NBR = eINSTANCE.getSequenceBlock_IdNbr();

		/**
		 * The meta object literal for the '{@link secondModel.impl.PopulatingStepsImpl <em>Populating Steps</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see secondModel.impl.PopulatingStepsImpl
		 * @see secondModel.impl.SecondModelPackageImpl#getPopulatingSteps()
		 * @generated
		 */
		EClass POPULATİNG_STEPS = eINSTANCE.getPopulatingSteps();

		/**
		 * The meta object literal for the '<em><b>Signals</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference POPULATİNG_STEPS__SİGNALS = eINSTANCE.getPopulatingSteps_Signals();

		/**
		 * The meta object literal for the '<em><b>Seqoperator</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference POPULATİNG_STEPS__SEQOPERATOR = eINSTANCE.getPopulatingSteps_Seqoperator();

		/**
		 * The meta object literal for the '<em><b>Signal Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POPULATİNG_STEPS__SİGNAL_NAME = eINSTANCE.getPopulatingSteps_SignalName();

		/**
		 * The meta object literal for the '<em><b>Input Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POPULATİNG_STEPS__INPUT_NAME = eINSTANCE.getPopulatingSteps_InputName();

		/**
		 * The meta object literal for the '<em><b>Id Nbr</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POPULATİNG_STEPS__ID_NBR = eINSTANCE.getPopulatingSteps_IdNbr();

		/**
		 * The meta object literal for the '<em><b>Next Id Nbr</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POPULATİNG_STEPS__NEXT_ID_NBR = eINSTANCE.getPopulatingSteps_NextIdNbr();

		/**
		 * The meta object literal for the '<em><b>Transition Id Nbr</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POPULATİNG_STEPS__TRANSİTİON_ID_NBR = eINSTANCE.getPopulatingSteps_TransitionIdNbr();

		/**
		 * The meta object literal for the '<em><b>Last Transition Id Nbr</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POPULATİNG_STEPS__LAST_TRANSİTİON_ID_NBR = eINSTANCE.getPopulatingSteps_LastTransitionIdNbr();

		/**
		 * The meta object literal for the '<em><b>Last Transition Step Nbr</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POPULATİNG_STEPS__LAST_TRANSİTİON_STEP_NBR = eINSTANCE.getPopulatingSteps_LastTransitionStepNbr();

		/**
		 * The meta object literal for the '{@link secondModel.impl.SeqOperatorImpl <em>Seq Operator</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see secondModel.impl.SeqOperatorImpl
		 * @see secondModel.impl.SecondModelPackageImpl#getSeqOperator()
		 * @generated
		 */
		EClass SEQ_OPERATOR = eINSTANCE.getSeqOperator();

		/**
		 * The meta object literal for the '<em><b>Operator Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEQ_OPERATOR__OPERATOR_TYPE = eINSTANCE.getSeqOperator_OperatorType();

		/**
		 * The meta object literal for the '<em><b>Id Nbr</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEQ_OPERATOR__ID_NBR = eINSTANCE.getSeqOperator_IdNbr();

		/**
		 * The meta object literal for the '<em><b>Seqoperatorwithinoperator</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEQ_OPERATOR__SEQOPERATORWİTHİNOPERATOR = eINSTANCE.getSeqOperator_Seqoperatorwithinoperator();

		/**
		 * The meta object literal for the '<em><b>Seqsignalid</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEQ_OPERATOR__SEQSİGNALİD = eINSTANCE.getSeqOperator_Seqsignalid();

		/**
		 * The meta object literal for the '<em><b>Concat Operator</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEQ_OPERATOR__CONCAT_OPERATOR = eINSTANCE.getSeqOperator_ConcatOperator();

		/**
		 * The meta object literal for the '{@link secondModel.impl.SeqSignalIDImpl <em>Seq Signal ID</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see secondModel.impl.SeqSignalIDImpl
		 * @see secondModel.impl.SecondModelPackageImpl#getSeqSignalID()
		 * @generated
		 */
		EClass SEQ_SİGNAL_ID = eINSTANCE.getSeqSignalID();

		/**
		 * The meta object literal for the '<em><b>Id Nbr</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEQ_SİGNAL_ID__ID_NBR = eINSTANCE.getSeqSignalID_IdNbr();

		/**
		 * The meta object literal for the '<em><b>Seqoperatorsignals</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEQ_SİGNAL_ID__SEQOPERATORSİGNALS = eINSTANCE.getSeqSignalID_Seqoperatorsignals();

		/**
		 * The meta object literal for the '{@link secondModel.impl.AnalogBlockImpl <em>Analog Block</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see secondModel.impl.AnalogBlockImpl
		 * @see secondModel.impl.SecondModelPackageImpl#getAnalogBlock()
		 * @generated
		 */
		EClass ANALOG_BLOCK = eINSTANCE.getAnalogBlock();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANALOG_BLOCK__NAME = eINSTANCE.getAnalogBlock_Name();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANALOG_BLOCK__DESCRİPTİON = eINSTANCE.getAnalogBlock_Description();

		/**
		 * The meta object literal for the '<em><b>Analogtosignals</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ANALOG_BLOCK__ANALOGTOSİGNALS = eINSTANCE.getAnalogBlock_Analogtosignals();

		/**
		 * The meta object literal for the '<em><b>Populatinginput</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ANALOG_BLOCK__POPULATİNGİNPUT = eINSTANCE.getAnalogBlock_Populatinginput();

		/**
		 * The meta object literal for the '<em><b>Populatingoutput</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ANALOG_BLOCK__POPULATİNGOUTPUT = eINSTANCE.getAnalogBlock_Populatingoutput();

		/**
		 * The meta object literal for the '<em><b>Block Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANALOG_BLOCK__BLOCK_ID = eINSTANCE.getAnalogBlock_BlockId();

		/**
		 * The meta object literal for the '<em><b>Signals In</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANALOG_BLOCK__SİGNALS_IN = eINSTANCE.getAnalogBlock_SignalsIn();

		/**
		 * The meta object literal for the '{@link secondModel.impl.PopulatingOutputImpl <em>Populating Output</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see secondModel.impl.PopulatingOutputImpl
		 * @see secondModel.impl.SecondModelPackageImpl#getPopulatingOutput()
		 * @generated
		 */
		EClass POPULATİNG_OUTPUT = eINSTANCE.getPopulatingOutput();

		/**
		 * The meta object literal for the '<em><b>Signal Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POPULATİNG_OUTPUT__SİGNAL_NAME = eINSTANCE.getPopulatingOutput_SignalName();

		/**
		 * The meta object literal for the '<em><b>Input Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POPULATİNG_OUTPUT__INPUT_NAME = eINSTANCE.getPopulatingOutput_InputName();

		/**
		 * The meta object literal for the '<em><b>İnputsignals</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference POPULATİNG_OUTPUT__İNPUTSİGNALS = eINSTANCE.getPopulatingOutput_İnputsignals();

		/**
		 * The meta object literal for the '<em><b>Id Nbr</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POPULATİNG_OUTPUT__ID_NBR = eINSTANCE.getPopulatingOutput_IdNbr();

		/**
		 * The meta object literal for the '{@link secondModel.impl.DigitalBlockImpl <em>Digital Block</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see secondModel.impl.DigitalBlockImpl
		 * @see secondModel.impl.SecondModelPackageImpl#getDigitalBlock()
		 * @generated
		 */
		EClass DİGİTAL_BLOCK = eINSTANCE.getDigitalBlock();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DİGİTAL_BLOCK__NAME = eINSTANCE.getDigitalBlock_Name();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DİGİTAL_BLOCK__DESCRİPTİON = eINSTANCE.getDigitalBlock_Description();

		/**
		 * The meta object literal for the '<em><b>Digitaltosignals</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DİGİTAL_BLOCK__DİGİTALTOSİGNALS = eINSTANCE.getDigitalBlock_Digitaltosignals();

		/**
		 * The meta object literal for the '<em><b>Populatinginput</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DİGİTAL_BLOCK__POPULATİNGİNPUT = eINSTANCE.getDigitalBlock_Populatinginput();

		/**
		 * The meta object literal for the '<em><b>Populatingoutput</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DİGİTAL_BLOCK__POPULATİNGOUTPUT = eINSTANCE.getDigitalBlock_Populatingoutput();

		/**
		 * The meta object literal for the '<em><b>Block Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DİGİTAL_BLOCK__BLOCK_ID = eINSTANCE.getDigitalBlock_BlockId();

	}

} //SecondModelPackage
