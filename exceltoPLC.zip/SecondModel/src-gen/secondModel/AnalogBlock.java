/**
 */
package secondModel;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Analog Block</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link secondModel.AnalogBlock#getName <em>Name</em>}</li>
 *   <li>{@link secondModel.AnalogBlock#getDescription <em>Description</em>}</li>
 *   <li>{@link secondModel.AnalogBlock#getAnalogtosignals <em>Analogtosignals</em>}</li>
 *   <li>{@link secondModel.AnalogBlock#getPopulatinginput <em>Populatinginput</em>}</li>
 *   <li>{@link secondModel.AnalogBlock#getPopulatingoutput <em>Populatingoutput</em>}</li>
 *   <li>{@link secondModel.AnalogBlock#getBlockId <em>Block Id</em>}</li>
 *   <li>{@link secondModel.AnalogBlock#getSignalsIn <em>Signals In</em>}</li>
 * </ul>
 *
 * @see secondModel.SecondModelPackage#getAnalogBlock()
 * @model
 * @generated
 */
public interface AnalogBlock extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see secondModel.SecondModelPackage#getAnalogBlock_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link secondModel.AnalogBlock#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Description</em>' attribute.
	 * @see #setDescription(String)
	 * @see secondModel.SecondModelPackage#getAnalogBlock_Description()
	 * @model
	 * @generated
	 */
	String getDescription();

	/**
	 * Sets the value of the '{@link secondModel.AnalogBlock#getDescription <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Description</em>' attribute.
	 * @see #getDescription()
	 * @generated
	 */
	void setDescription(String value);

	/**
	 * Returns the value of the '<em><b>Analogtosignals</b></em>' containment reference list.
	 * The list contents are of type {@link secondModel.Signals}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Analogtosignals</em>' containment reference list.
	 * @see secondModel.SecondModelPackage#getAnalogBlock_Analogtosignals()
	 * @model containment="true"
	 * @generated
	 */
	EList<Signals> getAnalogtosignals();

	/**
	 * Returns the value of the '<em><b>Populatinginput</b></em>' containment reference list.
	 * The list contents are of type {@link secondModel.PopulatingInput}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Populatinginput</em>' containment reference list.
	 * @see secondModel.SecondModelPackage#getAnalogBlock_Populatinginput()
	 * @model containment="true"
	 * @generated
	 */
	EList<PopulatingInput> getPopulatinginput();

	/**
	 * Returns the value of the '<em><b>Populatingoutput</b></em>' containment reference list.
	 * The list contents are of type {@link secondModel.PopulatingOutput}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Populatingoutput</em>' containment reference list.
	 * @see secondModel.SecondModelPackage#getAnalogBlock_Populatingoutput()
	 * @model containment="true"
	 * @generated
	 */
	EList<PopulatingOutput> getPopulatingoutput();

	/**
	 * Returns the value of the '<em><b>Block Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Block Id</em>' attribute.
	 * @see #setBlockId(String)
	 * @see secondModel.SecondModelPackage#getAnalogBlock_BlockId()
	 * @model
	 * @generated
	 */
	String getBlockId();

	/**
	 * Sets the value of the '{@link secondModel.AnalogBlock#getBlockId <em>Block Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Block Id</em>' attribute.
	 * @see #getBlockId()
	 * @generated
	 */
	void setBlockId(String value);

	/**
	 * Returns the value of the '<em><b>Signals In</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Signals In</em>' attribute list.
	 * @see secondModel.SecondModelPackage#getAnalogBlock_SignalsIn()
	 * @model
	 * @generated
	 */
	EList<String> getSignalsIn();

} // AnalogBlock
